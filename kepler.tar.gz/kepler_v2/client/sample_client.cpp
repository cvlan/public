// Sample Kepler Client
// Demonstrates how to interact with the Kepler routing engine

#include "kepler.grpc.pb.h"

#include <grpcpp/grpcpp.h>
#include <iostream>
#include <thread>
#include <chrono>
#include <algorithm>
#include <iterator>
#include <optional>

using namespace kepler;

class KeplerClient {
public:
    explicit KeplerClient(const std::string& target)
        : channel_(grpc::CreateChannel(target, grpc::InsecureChannelCredentials())),
          ingestion_stub_(RouteIngestion::NewStub(channel_)),
          lookup_stub_(RouteLookup::NewStub(channel_)),
          subscription_stub_(RouteSubscription::NewStub(channel_)) {}

    // Add a single route
    bool add_route(const Route& route) {
        grpc::ClientContext context;
        RouteResponse response;
        auto status = ingestion_stub_->AddRoute(&context, route, &response);
        return status.ok() && response.success();
    }

    // Lookup route by prefix
    std::optional<Route> get_route(uint32_t vpn, const Prefix& prefix) {
        grpc::ClientContext context;
        PrefixRequest request;
        request.set_vpn(vpn);
        *request.mutable_prefix() = prefix;
        Route response;

        auto status = lookup_stub_->GetRouteByPrefix(&context, request, &response);
        if (status.ok()) {
            return response;
        }
        return std::nullopt;
    }

    // Lookup routes by FQDN
    std::vector<Route> get_routes_by_fqdn(const std::string& fqdn) {
        grpc::ClientContext context;
        FqdnRequest request;
        request.set_discovered_fqdn(fqdn);
        RoutesResponse response;

        std::vector<Route> routes;
        auto status = lookup_stub_->GetRoutesByFqdn(&context, request, &response);
        if (status.ok()) {
            routes.reserve(response.routes_size());
            std::copy(response.routes().begin(), response.routes().end(),
                      std::back_inserter(routes));
        }
        return routes;
    }

    // Subscribe and stream changes
    void subscribe_and_stream(const std::string& fqdn, int duration_sec) {
        // Create subscription
        grpc::ClientContext sub_context;
        SubscribeRequest sub_request;
        sub_request.set_client_id("sample-client");

        auto* filter = sub_request.add_filters();
        filter->set_discovered_fqdn(fqdn);

        SubscribeResponse sub_response;
        auto status = subscription_stub_->Subscribe(&sub_context, sub_request, &sub_response);
        if (!status.ok()) {
            std::cerr << "Failed to subscribe: " << status.error_message() << std::endl;
            return;
        }

        std::cout << "Subscribed with ID: " << sub_response.subscription_id() << std::endl;

        // Stream changes
        grpc::ClientContext stream_context;
        StreamRequest stream_request;
        stream_request.set_subscription_id(sub_response.subscription_id());
        stream_request.set_last_sequence(0);
        stream_request.set_full_sync(true);

        auto reader = subscription_stub_->StreamChanges(&stream_context, stream_request);

        auto deadline = std::chrono::system_clock::now() + std::chrono::seconds(duration_sec);
        StreamResponse response;

        std::cout << "Streaming changes for " << duration_sec << " seconds..." << std::endl;

        while (std::chrono::system_clock::now() < deadline) {
            // Non-blocking read with timeout
            if (reader->Read(&response)) {
                if (response.has_change()) {
                    const auto& change = response.change();
                    std::cout << "[" << change.sequence() << "] "
                              << (change.type() == ADD ? "ADD" :
                                  change.type() == UPDATE ? "UPDATE" : "DELETE")
                              << " route " << change.route().route_id() << std::endl;
                } else if (response.has_full_sync_route()) {
                    std::cout << "[SYNC] route " << response.full_sync_route().route_id() << std::endl;
                }
                if (response.full_sync_complete()) {
                    std::cout << "[Full sync complete]" << std::endl;
                }
            }
        }

        stream_context.TryCancel();
    }

    // Get stats
    void print_stats() {
        grpc::ClientContext context;
        StatsRequest request;
        StatsResponse response;

        auto status = lookup_stub_->GetStats(&context, request, &response);
        if (status.ok()) {
            std::cout << "Server Statistics:" << std::endl;
            std::cout << "  Total routes: " << response.total_routes() << std::endl;
            std::cout << "  Total VPNs: " << response.total_vpns() << std::endl;
            std::cout << "  Total FQDNs: " << response.total_fqdns() << std::endl;
            std::cout << "  Current sequence: " << response.newest_sequence() << std::endl;
            std::cout << "  Oldest sequence: " << response.oldest_sequence() << std::endl;
            std::cout << "  Uptime: " << response.uptime_seconds() << " seconds" << std::endl;
        } else {
            std::cerr << "Failed to get stats: " << status.error_message() << std::endl;
        }
    }

private:
    std::shared_ptr<grpc::Channel> channel_;
    std::unique_ptr<RouteIngestion::Stub> ingestion_stub_;
    std::unique_ptr<RouteLookup::Stub> lookup_stub_;
    std::unique_ptr<RouteSubscription::Stub> subscription_stub_;
};

// Helper to create a sample route
Route create_sample_route(uint32_t vpn, const std::string& ip_prefix, int prefix_len,
                          const std::string& fqdn) {
    Route route;
    route.set_vpn(vpn);

    auto* prefix = route.mutable_prefix();
    prefix->set_family(AF_IPV4);

    // Parse IP
    std::string addr(4, 0);
    int a, b, c, d;
    sscanf(ip_prefix.c_str(), "%d.%d.%d.%d", &a, &b, &c, &d);
    addr[0] = a; addr[1] = b; addr[2] = c; addr[3] = d;
    prefix->set_address(addr);
    prefix->set_prefix_length(prefix_len);

    route.set_nexthop(std::string("\x0a\x00\x00\x01", 4));  // 10.0.0.1
    route.set_nexthop_vpn(vpn);

    route.set_discovered_fqdn(fqdn);
    route.set_virtual_ip(std::string("\x64\x40\x00\x01", 4));  // 100.64.0.1
    route.set_endpoint_ip(std::string("\xc0\xa8\x01\x01", 4)); // 192.168.1.1
    route.set_app_network_id("app-1");

    return route;
}

// cppcheck-suppress constParameter
int main(int argc, char** argv) {
    std::string target = "localhost:50051";
    if (argc > 1) {
        target = argv[1];
    }

    std::cout << "Kepler Sample Client\n";
    std::cout << "====================\n";
    std::cout << "Connecting to: " << target << "\n\n";

    KeplerClient client(target);

    // Print current stats
    std::cout << "1. Getting server statistics...\n";
    client.print_stats();
    std::cout << "\n";

    // Add a sample route
    std::cout << "2. Adding a sample route...\n";
    Route sample = create_sample_route(1, "192.168.100.0", 24, "sample.example.com");
    if (client.add_route(sample)) {
        std::cout << "   Route added successfully\n";
    } else {
        std::cout << "   Failed to add route\n";
    }
    std::cout << "\n";

    // Lookup by FQDN
    std::cout << "3. Looking up routes by FQDN 'sample.example.com'...\n";
    auto routes = client.get_routes_by_fqdn("sample.example.com");
    std::cout << "   Found " << routes.size() << " routes\n";
    for (const auto& r : routes) {
        std::cout << "   - Route ID: " << r.route_id() << " VPN: " << r.vpn() << "\n";
    }
    std::cout << "\n";

    // Subscribe to changes (run for 10 seconds)
    std::cout << "4. Subscribing to changes for 'sample.example.com' (10 seconds)...\n";
    client.subscribe_and_stream("sample.example.com", 10);
    std::cout << "\n";

    std::cout << "Sample client completed.\n";
    return 0;
}
