# Claude Code Project Instructions

## Critical Rules

### Never Run Commands on Host
**All build, test, and development commands MUST run inside the build container.**

The host machine does not have build tools installed (no cmake, gcc, etc.).

### Using the Build Container

Use `scripts/build-shell.sh` for all operations:

```bash
# Interactive shell inside container
./scripts/build-shell.sh

# Run a specific command inside container
./scripts/build-shell.sh "cmake --build build -j\$(nproc)"
./scripts/build-shell.sh "cd build && ctest"
./scripts/build-shell.sh "cppcheck --enable=all src/"
```

### Container Management

- **Image**: `kepler-build` (built from `Dockerfile.build`)
- **Container**: `kepler-build-env` (persistent, reused across invocations)
- **Rebuild image**: `./scripts/build-shell.sh --rebuild`

### Common Tasks Inside Container

```bash
# Configure and build
mkdir -p build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release -DKEPLER_BUILD_TESTS=ON
cmake --build . -j$(nproc)

# Run tests
cd build && ctest --output-on-failure

# Static analysis
cppcheck --enable=warning,style,performance,portability \
  --suppress=missingIncludeSystem --suppress=missingInclude \
  --suppress=unusedFunction --std=c++20 -I src \
  --inline-suppr --error-exitcode=1 src/ tools/ client/
```

## Project Structure

- `Dockerfile.build` - Build environment container
- `Dockerfile` - Production container
- `scripts/build-shell.sh` - Entry point for build container
- `Makefile` - Convenience targets (wraps build-shell.sh)

## Do NOT

- Run `cmake`, `make`, `ctest`, `cppcheck` directly on host
- Create new Docker containers - use the existing `kepler-build-env`
- Install tools via homebrew on host
