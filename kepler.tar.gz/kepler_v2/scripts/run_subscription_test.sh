#!/bin/bash
# Run subscription integration test
# Tests that updates are correctly delivered to subscribers and measures latency

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
BUILD_DIR="$PROJECT_ROOT/build"

# Test parameters
ROUTES=${ROUTES:-1000}
UPDATES=${UPDATES:-100}
DELETES=${DELETES:-50}

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo "========================================"
echo "Subscription Integration Test"
echo "========================================"

# Check for binaries
if [ ! -f "$BUILD_DIR/kepler" ] || [ ! -f "$BUILD_DIR/subscription_integration_test" ]; then
    echo -e "${RED}Error: Build the project first with ./scripts/docker-build.sh${NC}"
    exit 1
fi

# Create temp directory
TEST_DIR=$(mktemp -d)
trap "rm -rf $TEST_DIR" EXIT

echo "Using temp directory: $TEST_DIR"

# Start Kepler
echo -e "\n${YELLOW}Starting Kepler server...${NC}"
KEPLER_DB_PATH="$TEST_DIR/data" \
KEPLER_GRPC_ADDRESS="127.0.0.1:50051" \
KEPLER_ADMIN_ADDRESS="127.0.0.1:8080" \
"$BUILD_DIR/kepler" &
KEPLER_PID=$!

cleanup() {
    echo -e "\n${YELLOW}Stopping Kepler...${NC}"
    kill $KEPLER_PID 2>/dev/null || true
    wait $KEPLER_PID 2>/dev/null || true
    rm -rf "$TEST_DIR"
}
trap cleanup EXIT

# Wait for server
sleep 2
if ! kill -0 $KEPLER_PID 2>/dev/null; then
    echo -e "${RED}Kepler failed to start${NC}"
    exit 1
fi

# Check health
echo "Checking server health..."
if ! curl -s http://127.0.0.1:8080/health | grep -q healthy; then
    echo -e "${RED}Health check failed${NC}"
    exit 1
fi
echo -e "${GREEN}Server is healthy${NC}"

# Run the integration test
echo -e "\n${YELLOW}Running subscription integration test...${NC}"
echo "  Routes:  $ROUTES"
echo "  Updates: $UPDATES"
echo "  Deletes: $DELETES"
echo ""

"$BUILD_DIR/subscription_integration_test" \
    --target=127.0.0.1:50051 \
    --routes=$ROUTES \
    --updates=$UPDATES \
    --deletes=$DELETES

TEST_EXIT=$?

if [ $TEST_EXIT -eq 0 ]; then
    echo -e "\n${GREEN}Integration test PASSED${NC}"
else
    echo -e "\n${RED}Integration test FAILED${NC}"
fi

exit $TEST_EXIT
