#!/bin/bash
# Build shell utility - drops into a containerized build environment
# Uses a persistent container that's reused across invocations
#
# Usage:
#   ./scripts/build-shell.sh              # Interactive shell
#   ./scripts/build-shell.sh "cmake .."   # Run a specific command
#   ./scripts/build-shell.sh --rebuild    # Force rebuild of image

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
IMAGE_NAME="kepler-build"
CONTAINER_NAME="kepler-build-env"

# Build the image if it doesn't exist
build_image() {
    echo "Building build environment image..."
    docker build -t "$IMAGE_NAME" -f "$PROJECT_DIR/Dockerfile.build" "$PROJECT_DIR"
}

# Check if image exists
if ! docker image inspect "$IMAGE_NAME" &>/dev/null; then
    build_image
fi

# Handle --rebuild flag
if [[ "$1" == "--rebuild" ]]; then
    build_image
    shift
fi

# Check if container exists and is running
container_running() {
    docker ps --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"
}

container_exists() {
    docker ps -a --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"
}

# Start or attach to container
ensure_container_running() {
    if container_running; then
        return 0
    elif container_exists; then
        echo "Starting existing container..."
        docker start "$CONTAINER_NAME" >/dev/null
    else
        echo "Creating new persistent container..."
        docker run -d \
            --name "$CONTAINER_NAME" \
            --cpus="8" \
            --memory="12g" \
            -v "$PROJECT_DIR:/kepler" \
            -w /kepler \
            "$IMAGE_NAME" \
            tail -f /dev/null  # Keep container running
    fi
}

# Determine if we have a TTY
get_tty_flag() {
    if [ -t 0 ]; then
        echo "-it"
    else
        echo "-i"
    fi
}

# Main logic
ensure_container_running

if [[ $# -gt 0 ]]; then
    # Run specific command in container
    docker exec $(get_tty_flag) "$CONTAINER_NAME" bash -c "$*"
else
    # Interactive shell
    echo "Entering Kepler build environment..."
    echo "Project mounted at /kepler"
    echo ""
    echo "Quick start:"
    echo "  mkdir -p build && cd build"
    echo "  cmake .. -DCMAKE_BUILD_TYPE=Release"
    echo "  cmake --build . -j\$(nproc)"
    echo ""
    docker exec -it "$CONTAINER_NAME" bash
fi
