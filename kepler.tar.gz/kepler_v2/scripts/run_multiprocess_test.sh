#!/bin/bash
# Multi-process subscription latency test
# Spawns N separate subscriber processes, each with their own gRPC channel

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
BUILD_DIR="$PROJECT_ROOT/build"

# Test parameters
NUM_CLIENTS=${NUM_CLIENTS:-10}
PRELOAD=${PRELOAD:-1000000}
ROUTES=${ROUTES:-1000}
UPDATES=${UPDATES:-100}
DELETES=${DELETES:-50}
TARGET="127.0.0.1:50051"
FQDN="integration-test.example.com"

echo "========================================"
echo "Multi-Process Subscription Test"
echo "========================================"
echo "Clients:    $NUM_CLIENTS"
echo "Preload:    $PRELOAD routes"
echo "Routes:     $ROUTES"
echo "Updates:    $UPDATES"
echo "Deletes:    $DELETES"
echo "========================================"

# Check for binaries
if [ ! -f "$BUILD_DIR/kepler" ] || [ ! -f "$BUILD_DIR/subscriber_client" ]; then
    echo "Error: Build the project first"
    exit 1
fi

# Create temp directory
TEST_DIR=$(mktemp -d)
trap "rm -rf $TEST_DIR" EXIT

echo "Using temp directory: $TEST_DIR"

# Start Kepler
echo -e "\nStarting Kepler server..."
KEPLER_DB_PATH="$TEST_DIR/data" \
KEPLER_GRPC_ADDRESS="$TARGET" \
KEPLER_ADMIN_ADDRESS="127.0.0.1:8080" \
"$BUILD_DIR/kepler" 2>"$TEST_DIR/kepler.log" &
KEPLER_PID=$!

cleanup() {
    echo -e "\nCleaning up..."
    # Kill subscriber clients
    for pid in "${CLIENT_PIDS[@]}"; do
        kill $pid 2>/dev/null || true
    done
    # Kill kepler
    kill $KEPLER_PID 2>/dev/null || true
    wait $KEPLER_PID 2>/dev/null || true
    rm -rf "$TEST_DIR"
}
trap cleanup EXIT

sleep 2
if ! kill -0 $KEPLER_PID 2>/dev/null; then
    echo "Kepler failed to start"
    exit 1
fi

# Wait for health
for i in {1..10}; do
    if curl -s http://127.0.0.1:8080/health | grep -q healthy; then
        break
    fi
    sleep 1
done

# Preload routes (using parallel ingestion from the test binary)
if [ "$PRELOAD" -gt 0 ]; then
    echo -e "\nPreloading $PRELOAD routes..."
    "$BUILD_DIR/subscription_integration_test" \
        --target=$TARGET \
        --preload=$PRELOAD \
        --clients=1 \
        --routes=0 \
        --updates=0 \
        --deletes=0 2>&1 | grep -E "(Preload|routes)"
fi

# Calculate expected events per client
# Half of routes match filter (even-indexed), updates/deletes iterate by 2
EXPECTED_ADDS=$((ROUTES / 2))
EXPECTED_UPDATES=$((UPDATES / 2))
EXPECTED_DELETES=$((DELETES / 2))
EXPECTED_TOTAL=$((EXPECTED_ADDS + EXPECTED_UPDATES + EXPECTED_DELETES))

echo -e "\nStarting $NUM_CLIENTS subscriber clients..."
echo "Expected events per client: $EXPECTED_TOTAL"

# Start subscriber clients
declare -a CLIENT_PIDS
for i in $(seq 0 $((NUM_CLIENTS - 1))); do
    READY_FILE="$TEST_DIR/ready_$i"
    RESULTS_FILE="$TEST_DIR/results_$i"

    "$BUILD_DIR/subscriber_client" \
        --target=$TARGET \
        --fqdn="$FQDN" \
        --id=$i \
        --ready-file="$READY_FILE" \
        --results-file="$RESULTS_FILE" \
        --expected=$EXPECTED_TOTAL &
    CLIENT_PIDS+=($!)
done

# Wait for all clients to be ready
echo "Waiting for clients to connect..."
for i in $(seq 0 $((NUM_CLIENTS - 1))); do
    READY_FILE="$TEST_DIR/ready_$i"
    for j in {1..30}; do
        if [ -f "$READY_FILE" ]; then
            break
        fi
        sleep 0.1
    done
    if [ ! -f "$READY_FILE" ]; then
        echo "Client $i failed to become ready"
        exit 1
    fi
done
echo "All $NUM_CLIENTS clients connected"

# Wait for streams to be fully connected on server side
# (there's a race between client signaling ready and server calling connect_stream)
sleep 2

# Record start time
START_TIME=$(date +%s%N)

# Run ingestion (sending routes that match the filter) - no internal subscribers
echo -e "\nRunning ingestion test..."
"$BUILD_DIR/subscription_integration_test" \
    --target=$TARGET \
    --preload=0 \
    --clients=0 \
    --routes=$ROUTES \
    --updates=$UPDATES \
    --deletes=$DELETES 2>&1 | grep -E "(Phase|Added|Updated|Deleted|Ingestion|Sent)"

# Wait for all subscriber clients to finish
echo -e "\nWaiting for subscribers to receive all events..."
for pid in "${CLIENT_PIDS[@]}"; do
    wait $pid 2>/dev/null || true
done

END_TIME=$(date +%s%N)
DURATION_MS=$(( (END_TIME - START_TIME) / 1000000 ))

echo -e "\n========================================"
echo "Results (duration: ${DURATION_MS}ms)"
echo "========================================"

# Collect and analyze results
TOTAL_SAMPLES=0
ALL_LATENCIES=""
TOTAL_ADDS=0
TOTAL_UPDATES=0
TOTAL_DELETES=0
TOTAL_MISMATCHES=0

for i in $(seq 0 $((NUM_CLIENTS - 1))); do
    RESULTS_FILE="$TEST_DIR/results_$i"
    if [ -f "$RESULTS_FILE" ]; then
        ADDS=$(grep "^adds=" "$RESULTS_FILE" | cut -d= -f2)
        UPDATES_COUNT=$(grep "^updates=" "$RESULTS_FILE" | cut -d= -f2)
        DELETES_COUNT=$(grep "^deletes=" "$RESULTS_FILE" | cut -d= -f2)
        MISMATCHES=$(grep "^mismatches=" "$RESULTS_FILE" | cut -d= -f2)
        SAMPLES=$(grep "^samples=" "$RESULTS_FILE" | cut -d= -f2)

        echo "Client $i: $ADDS adds, $UPDATES_COUNT updates, $DELETES_COUNT deletes (samples: $SAMPLES)"

        TOTAL_ADDS=$((TOTAL_ADDS + ADDS))
        TOTAL_UPDATES=$((TOTAL_UPDATES + UPDATES_COUNT))
        TOTAL_DELETES=$((TOTAL_DELETES + DELETES_COUNT))
        TOTAL_MISMATCHES=$((TOTAL_MISMATCHES + MISMATCHES))
        TOTAL_SAMPLES=$((TOTAL_SAMPLES + SAMPLES))
    else
        echo "Client $i: NO RESULTS FILE"
    fi
done

echo "========================================"
echo "Total: $TOTAL_ADDS adds, $TOTAL_UPDATES updates, $TOTAL_DELETES deletes"
echo "Expected per client: $EXPECTED_ADDS adds, $EXPECTED_UPDATES updates, $EXPECTED_DELETES deletes"
echo "Total mismatches: $TOTAL_MISMATCHES"
echo "========================================"

# Verify
EXPECTED_TOTAL_ADDS=$((EXPECTED_ADDS * NUM_CLIENTS))
EXPECTED_TOTAL_UPDATES=$((EXPECTED_UPDATES * NUM_CLIENTS))
EXPECTED_TOTAL_DELETES=$((EXPECTED_DELETES * NUM_CLIENTS))

# Show server debug output
echo -e "\nServer debug log:"
cat "$TEST_DIR/kepler.log" | grep -E "\[notify\]" | head -10

if [ "$TOTAL_ADDS" -eq "$EXPECTED_TOTAL_ADDS" ] && \
   [ "$TOTAL_UPDATES" -eq "$EXPECTED_TOTAL_UPDATES" ] && \
   [ "$TOTAL_DELETES" -eq "$EXPECTED_TOTAL_DELETES" ] && \
   [ "$TOTAL_MISMATCHES" -eq 0 ]; then
    echo -e "\n*** ALL TESTS PASSED ***"
    exit 0
else
    echo -e "\n*** TESTS FAILED ***"
    exit 1
fi
