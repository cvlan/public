#!/bin/bash
# Run integration tests inside Docker container
# Usage: ./scripts/docker-test.sh [ROUTE_COUNT] [VPN_COUNT]

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROUTE_COUNT="${1:-100000}"
VPN_COUNT="${2:-1000}"

echo "Running Kepler integration tests inside Docker..."

"$SCRIPT_DIR/build-shell.sh" "
    set -e

    # Ensure build exists
    if [ ! -f build/kepler ]; then
        echo 'Building first...'
        mkdir -p build
        cd build
        cmake .. -DCMAKE_BUILD_TYPE=Release -GNinja
        cmake --build . -j\$(nproc)
        cd ..
    fi

    # Run integration test
    ROUTE_COUNT=$ROUTE_COUNT VPN_COUNT=$VPN_COUNT ./scripts/run_integration_test.sh
"
