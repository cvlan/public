#!/bin/bash
set -e

# Kepler Crash Recovery Test
# Tests that RocksDB correctly recovers data after a crash during ingestion

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
BUILD_DIR="$PROJECT_ROOT/build"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo "========================================"
echo "Kepler Crash Recovery Test"
echo "========================================"
echo ""

# Check binaries
if [ ! -f "$BUILD_DIR/kepler" ] || [ ! -f "$BUILD_DIR/crash_recovery_test" ]; then
    echo -e "${YELLOW}Building required binaries...${NC}"
    cd "$BUILD_DIR"
    cmake --build . --target kepler crash_recovery_test -j$(nproc 2>/dev/null || sysctl -n hw.ncpu 2>/dev/null || echo 4)
    cd "$PROJECT_ROOT"
fi

# Create temp directory
TEST_DIR=$(mktemp -d)
STATE_FILE="$TEST_DIR/crash_test_state"
DB_PATH="$TEST_DIR/data"

echo "Test directory: $TEST_DIR"
echo ""

cleanup() {
    echo ""
    echo -e "${YELLOW}Cleaning up...${NC}"
    # Kill any running kepler processes from this test
    if [ -n "$KEPLER_PID" ] && kill -0 $KEPLER_PID 2>/dev/null; then
        kill $KEPLER_PID 2>/dev/null || true
        wait $KEPLER_PID 2>/dev/null || true
    fi
    rm -rf "$TEST_DIR"
}
trap cleanup EXIT

start_kepler() {
    echo -e "${YELLOW}Starting Kepler server...${NC}"
    KEPLER_DB_PATH="$DB_PATH" \
    KEPLER_GRPC_ADDRESS="127.0.0.1:50052" \
    KEPLER_ADMIN_ADDRESS="127.0.0.1:8082" \
    KEPLER_BLOCK_CACHE_MB="256" \
    "$BUILD_DIR/kepler" &
    KEPLER_PID=$!

    # Wait for server to be ready
    for i in {1..30}; do
        if curl -s http://127.0.0.1:8082/health | grep -q "healthy"; then
            echo -e "${GREEN}Kepler started (PID: $KEPLER_PID)${NC}"
            return 0
        fi
        sleep 0.5
    done

    echo -e "${RED}Failed to start Kepler${NC}"
    return 1
}

# ==========================================
# Phase 1: Setup and populate data
# ==========================================
echo "=========================================="
echo "Phase 1: Setup"
echo "=========================================="
echo ""

start_kepler

echo "Running setup phase..."
"$BUILD_DIR/crash_recovery_test" \
    --target=127.0.0.1:50052 \
    --initial-routes=1000 \
    --additional-routes=500 \
    --state-file="$STATE_FILE" \
    --setup-only

echo ""
echo -e "${GREEN}Setup phase complete${NC}"

# ==========================================
# Phase 2: Simulate crash (SIGKILL)
# ==========================================
echo ""
echo "=========================================="
echo "Phase 2: Simulating Crash (SIGKILL)"
echo "=========================================="
echo ""

echo "Sending SIGKILL to Kepler (PID: $KEPLER_PID)..."
kill -9 $KEPLER_PID 2>/dev/null || true
wait $KEPLER_PID 2>/dev/null || true
KEPLER_PID=""

echo -e "${GREEN}Server killed${NC}"
sleep 1

# ==========================================
# Phase 3: Recovery and verification
# ==========================================
echo ""
echo "=========================================="
echo "Phase 3: Recovery and Verification"
echo "=========================================="
echo ""

start_kepler

echo "Running verification phase..."
if "$BUILD_DIR/crash_recovery_test" \
    --target=127.0.0.1:50052 \
    --state-file="$STATE_FILE" \
    --verify-only; then
    echo ""
    echo -e "${GREEN}=========================================="
    echo "CRASH RECOVERY TEST PASSED"
    echo -e "==========================================${NC}"
    exit 0
else
    echo ""
    echo -e "${RED}=========================================="
    echo "CRASH RECOVERY TEST FAILED"
    echo -e "==========================================${NC}"
    exit 1
fi
