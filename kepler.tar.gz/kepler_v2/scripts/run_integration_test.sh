#!/bin/bash
set -e

# Kepler Integration Test Script
# Runs the full integration test suite

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
BUILD_DIR="$PROJECT_ROOT/build"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo "=================================="
echo "Kepler Integration Test"
echo "=================================="
echo ""

# Check if build directory exists
if [ ! -d "$BUILD_DIR" ]; then
    echo -e "${YELLOW}Build directory not found. Building...${NC}"
    mkdir -p "$BUILD_DIR"
    cd "$BUILD_DIR"
    cmake .. -DCMAKE_BUILD_TYPE=Release -DKEPLER_BUILD_TESTS=ON
    cmake --build . -j$(nproc 2>/dev/null || sysctl -n hw.ncpu)
    cd "$PROJECT_ROOT"
fi

# Check if binaries exist
if [ ! -f "$BUILD_DIR/kepler" ] || [ ! -f "$BUILD_DIR/upstream_simulator" ]; then
    echo -e "${YELLOW}Binaries not found. Building...${NC}"
    cd "$BUILD_DIR"
    cmake --build . -j$(nproc 2>/dev/null || sysctl -n hw.ncpu)
    cd "$PROJECT_ROOT"
fi

# Create temp directory for test data
TEST_DATA_DIR=$(mktemp -d)
trap "rm -rf $TEST_DATA_DIR" EXIT

echo "Test data directory: $TEST_DATA_DIR"
echo ""

# Start Kepler server
echo -e "${YELLOW}Starting Kepler server...${NC}"
KEPLER_DB_PATH="$TEST_DATA_DIR/data" \
KEPLER_GRPC_ADDRESS="127.0.0.1:50051" \
KEPLER_ADMIN_ADDRESS="127.0.0.1:8080" \
KEPLER_BLOCK_CACHE_MB="512" \
"$BUILD_DIR/kepler" &
KEPLER_PID=$!

# Wait for server to start
sleep 3

# Check if server is running
if ! kill -0 $KEPLER_PID 2>/dev/null; then
    echo -e "${RED}Failed to start Kepler server${NC}"
    exit 1
fi

echo -e "${GREEN}Kepler server started (PID: $KEPLER_PID)${NC}"
echo ""

# Function to cleanup on exit
cleanup() {
    echo ""
    echo -e "${YELLOW}Cleaning up...${NC}"
    if kill -0 $KEPLER_PID 2>/dev/null; then
        kill $KEPLER_PID
        wait $KEPLER_PID 2>/dev/null || true
    fi
    rm -rf "$TEST_DATA_DIR"
}
trap cleanup EXIT

# Check health endpoint
echo "Checking health endpoint..."
HEALTH_RESPONSE=$(curl -s http://127.0.0.1:8080/health)
if [[ "$HEALTH_RESPONSE" == *"healthy"* ]]; then
    echo -e "${GREEN}Health check passed${NC}"
else
    echo -e "${RED}Health check failed${NC}"
    exit 1
fi
echo ""

# Run upstream simulator with small dataset for quick test
echo "=================================="
echo "Phase 1: Route Injection"
echo "=================================="
echo ""

ROUTE_COUNT=${ROUTE_COUNT:-100000}
VPN_COUNT=${VPN_COUNT:-1000}

echo "Injecting $ROUTE_COUNT routes across $VPN_COUNT VPNs..."
"$BUILD_DIR/upstream_simulator" \
    --target=127.0.0.1:50051 \
    --routes=$ROUTE_COUNT \
    --vpns=$VPN_COUNT \
    --rate=0 \
    --verify

echo ""
echo -e "${GREEN}Route injection completed${NC}"
echo ""

# Verify routes via API
echo "=================================="
echo "Phase 2: Verification"
echo "=================================="
echo ""

echo "Getting server stats..."
"$BUILD_DIR/keplerctl" --target=127.0.0.1:50051 status

echo ""
echo "Listing VPNs..."
"$BUILD_DIR/keplerctl" --target=127.0.0.1:50051 list vpns --limit=10

echo ""
echo "Listing FQDNs..."
"$BUILD_DIR/keplerctl" --target=127.0.0.1:50051 list fqdns --limit=10

echo ""

# Run subscriber test (brief)
echo "=================================="
echo "Phase 3: Subscription Test"
echo "=================================="
echo ""

echo "Running subscriber test for 5 seconds..."
timeout 10 "$BUILD_DIR/subscriber_test" \
    --target=127.0.0.1:50051 \
    --fqdns=10 \
    --duration=5 || true

echo ""

# Check metrics
echo "=================================="
echo "Phase 4: Metrics Check"
echo "=================================="
echo ""

echo "Fetching Prometheus metrics..."
curl -s http://127.0.0.1:8080/metrics | grep -E "^kepler_" | head -20

echo ""
echo ""
echo "=================================="
echo -e "${GREEN}Integration test completed successfully!${NC}"
echo "=================================="
