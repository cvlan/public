#!/bin/bash
# Build Kepler inside Docker container
# Usage: ./scripts/docker-build.sh [Debug|Release]

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_TYPE="${1:-Release}"

echo "Building Kepler ($BUILD_TYPE) inside Docker..."

"$SCRIPT_DIR/build-shell.sh" "
    set -e
    mkdir -p build
    cd build
    cmake .. -DCMAKE_BUILD_TYPE=$BUILD_TYPE -GNinja
    cmake --build . -j\$(nproc)
    echo ''
    echo 'Build complete! Binaries are in build/'
    ls -la kepler keplerctl 2>/dev/null || echo 'Note: Some targets may have failed'
"
