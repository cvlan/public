// Ingestion load test - placeholder for Google Benchmark
// To be implemented with benchmark framework

#include <benchmark/benchmark.h>
#include "storage/route_store.h"
#include "storage/change_log.h"
#include "core/route_manager.h"
#include <filesystem>

namespace kepler {
namespace bench {

class IngestionBenchmark : public benchmark::Fixture {
public:
    void SetUp(benchmark::State& state) override {
        test_dir_ = std::filesystem::temp_directory_path() / "kepler_bench";
        std::filesystem::create_directories(test_dir_);

        Config config;
        config.db_path = test_dir_.string();
        config.block_cache_size_mb = 512;

        store_ = std::make_unique<RouteStore>(config);
        store_->open();
        changelog_ = std::make_unique<ChangeLog>(*store_, config);
        manager_ = std::make_unique<RouteManager>(*store_, *changelog_);
    }

    void TearDown(benchmark::State& state) override {
        manager_.reset();
        changelog_.reset();
        store_->close();
        store_.reset();
        std::filesystem::remove_all(test_dir_);
    }

protected:
    Route create_route(uint32_t vpn, uint64_t id) {
        Route route;
        route.set_vpn(vpn);

        auto* prefix = route.mutable_prefix();
        prefix->set_family(AF_IPV4);
        uint32_t ip = static_cast<uint32_t>(id);
        std::string addr(4, 0);
        addr[0] = (ip >> 24) & 0xFF;
        addr[1] = (ip >> 16) & 0xFF;
        addr[2] = (ip >> 8) & 0xFF;
        addr[3] = 0;
        prefix->set_address(addr);
        prefix->set_prefix_length(24);

        route.set_nexthop(std::string("\x0a\x00\x00\x01", 4));
        route.set_nexthop_vpn(vpn);
        route.set_discovered_fqdn("bench-" + std::to_string(id) + ".example.com");

        return route;
    }

    std::filesystem::path test_dir_;
    std::unique_ptr<RouteStore> store_;
    std::unique_ptr<ChangeLog> changelog_;
    std::unique_ptr<RouteManager> manager_;
};

BENCHMARK_DEFINE_F(IngestionBenchmark, AddRoute)(benchmark::State& state) {
    uint64_t id = 0;
    for (auto _ : state) {
        Route route = create_route(1, id++);
        manager_->add_route(route);
    }
    state.SetItemsProcessed(state.iterations());
}

BENCHMARK_REGISTER_F(IngestionBenchmark, AddRoute)
    ->Unit(benchmark::kMicrosecond)
    ->Iterations(10000);

}  // namespace bench
}  // namespace kepler

BENCHMARK_MAIN();
