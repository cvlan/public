// Lookup load test - placeholder for Google Benchmark

#include <benchmark/benchmark.h>
#include "storage/route_store.h"
#include "storage/change_log.h"
#include "core/route_manager.h"
#include <filesystem>
#include <random>

namespace kepler {
namespace bench {

class LookupBenchmark : public benchmark::Fixture {
public:
    void SetUp(benchmark::State& state) override {
        test_dir_ = std::filesystem::temp_directory_path() / "kepler_lookup_bench";
        std::filesystem::create_directories(test_dir_);

        Config config;
        config.db_path = test_dir_.string();
        config.block_cache_size_mb = 512;

        store_ = std::make_unique<RouteStore>(config);
        store_->open();
        changelog_ = std::make_unique<ChangeLog>(*store_, config);
        manager_ = std::make_unique<RouteManager>(*store_, *changelog_);

        // Pre-populate with routes
        for (uint64_t i = 0; i < 10000; ++i) {
            Route route = create_route(1, i);
            manager_->add_route(route);
            fqdns_.push_back(route.discovered_fqdn());
        }
    }

    void TearDown(benchmark::State& state) override {
        manager_.reset();
        changelog_.reset();
        store_->close();
        store_.reset();
        std::filesystem::remove_all(test_dir_);
    }

protected:
    Route create_route(uint32_t vpn, uint64_t id) {
        Route route;
        route.set_vpn(vpn);

        auto* prefix = route.mutable_prefix();
        prefix->set_family(AF_IPV4);
        uint32_t ip = static_cast<uint32_t>(id);
        std::string addr(4, 0);
        addr[0] = 10;
        addr[1] = (ip >> 8) & 0xFF;
        addr[2] = ip & 0xFF;
        addr[3] = 0;
        prefix->set_address(addr);
        prefix->set_prefix_length(24);

        route.set_nexthop(std::string("\x0a\x00\x00\x01", 4));
        route.set_nexthop_vpn(vpn);
        route.set_discovered_fqdn("bench-" + std::to_string(id) + ".example.com");

        return route;
    }

    std::filesystem::path test_dir_;
    std::unique_ptr<RouteStore> store_;
    std::unique_ptr<ChangeLog> changelog_;
    std::unique_ptr<RouteManager> manager_;
    std::vector<std::string> fqdns_;
};

BENCHMARK_DEFINE_F(LookupBenchmark, LookupByFqdn)(benchmark::State& state) {
    std::mt19937 rng(42);
    std::uniform_int_distribution<size_t> dist(0, fqdns_.size() - 1);

    for (auto _ : state) {
        std::string fqdn = fqdns_[dist(rng)];
        auto routes = manager_->get_routes_by_fqdn(fqdn);
        benchmark::DoNotOptimize(routes);
    }
    state.SetItemsProcessed(state.iterations());
}

BENCHMARK_REGISTER_F(LookupBenchmark, LookupByFqdn)
    ->Unit(benchmark::kMicrosecond)
    ->Iterations(10000);

}  // namespace bench
}  // namespace kepler

BENCHMARK_MAIN();
