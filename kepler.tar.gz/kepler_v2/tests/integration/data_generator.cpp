#include "data_generator.h"
#include <sstream>
#include <iomanip>

namespace kepler {
namespace test {

const std::vector<std::string> DataGenerator::fqdn_templates_ = {
    "app-{id}.{region}.example.com",
    "svc-{uuid}.cluster.local",
    "db-{id}.{env}.internal",
    "cache-{id}.{region}.corp.net",
    "api.{service}.example.com"
};

const std::vector<std::string> DataGenerator::regions_ = {
    "us-east-1", "us-west-2", "eu-west-1", "ap-south-1", "ap-northeast-1"
};

const std::vector<std::string> DataGenerator::envs_ = {
    "prod", "staging", "dev", "test"
};

const std::vector<std::string> DataGenerator::services_ = {
    "auth", "users", "orders", "payments", "inventory", "notifications", "analytics"
};

DataGenerator::DataGenerator(uint32_t seed) : rng_(seed) {}

std::string DataGenerator::random_ipv4() {
    std::uniform_int_distribution<int> octet_dist(0, 255);

    // Use RFC1918 private addresses with some variety
    std::uniform_int_distribution<int> class_dist(0, 2);
    int net_class = class_dist(rng_);

    std::string result(4, 0);
    switch (net_class) {
        case 0:  // 10.x.x.x
            result[0] = 10;
            result[1] = static_cast<char>(octet_dist(rng_));
            result[2] = static_cast<char>(octet_dist(rng_));
            result[3] = static_cast<char>(octet_dist(rng_) % 254 + 1);
            break;
        case 1:  // 172.16-31.x.x
            result[0] = static_cast<char>(172);
            result[1] = static_cast<char>(16 + (octet_dist(rng_) % 16));
            result[2] = static_cast<char>(octet_dist(rng_));
            result[3] = static_cast<char>(octet_dist(rng_) % 254 + 1);
            break;
        case 2:  // 192.168.x.x
            result[0] = static_cast<char>(192);
            result[1] = static_cast<char>(168);
            result[2] = static_cast<char>(octet_dist(rng_));
            result[3] = static_cast<char>(octet_dist(rng_) % 254 + 1);
            break;
    }
    return result;
}

Prefix DataGenerator::random_prefix() {
    Prefix prefix;
    prefix.set_family(AF_IPV4);

    // Generate network address
    std::string ip = random_ipv4();

    // Choose a common prefix length
    std::uniform_int_distribution<int> prefix_dist(0, 4);
    int prefix_choice = prefix_dist(rng_);
    int prefix_len;
    switch (prefix_choice) {
        case 0: prefix_len = 24; break;  // /24 - most common
        case 1: prefix_len = 25; break;
        case 2: prefix_len = 26; break;
        case 3: prefix_len = 27; break;
        case 4: prefix_len = 28; break;
        default: prefix_len = 24;
    }

    // Mask the IP to be a valid network address
    uint32_t mask = 0xFFFFFFFF << (32 - prefix_len);
    uint32_t ip_val = (static_cast<uint8_t>(ip[0]) << 24) |
                      (static_cast<uint8_t>(ip[1]) << 16) |
                      (static_cast<uint8_t>(ip[2]) << 8) |
                      static_cast<uint8_t>(ip[3]);
    ip_val &= mask;

    ip[0] = static_cast<char>((ip_val >> 24) & 0xFF);
    ip[1] = static_cast<char>((ip_val >> 16) & 0xFF);
    ip[2] = static_cast<char>((ip_val >> 8) & 0xFF);
    ip[3] = static_cast<char>(ip_val & 0xFF);

    prefix.set_address(ip);
    prefix.set_prefix_length(prefix_len);

    return prefix;
}

std::string DataGenerator::random_fqdn() {
    std::uniform_int_distribution<size_t> template_dist(0, fqdn_templates_.size() - 1);
    std::uniform_int_distribution<size_t> region_dist(0, regions_.size() - 1);
    std::uniform_int_distribution<size_t> env_dist(0, envs_.size() - 1);
    std::uniform_int_distribution<size_t> service_dist(0, services_.size() - 1);
    std::uniform_int_distribution<int> id_dist(1, 9999);

    // Distribution matching the plan (40%, 30%, 15%, 10%, 5%)
    std::uniform_int_distribution<int> weighted(1, 100);
    int w = weighted(rng_);
    size_t template_idx;
    if (w <= 40) template_idx = 0;
    else if (w <= 70) template_idx = 1;
    else if (w <= 85) template_idx = 2;
    else if (w <= 95) template_idx = 3;
    else template_idx = 4;

    std::string fqdn = fqdn_templates_[template_idx];

    // Replace placeholders
    auto replace = [](std::string& str, const std::string& from, const std::string& to) {
        size_t pos = str.find(from);
        if (pos != std::string::npos) {
            str.replace(pos, from.length(), to);
        }
    };

    replace(fqdn, "{id}", std::to_string(id_dist(rng_)));
    replace(fqdn, "{region}", regions_[region_dist(rng_)]);
    replace(fqdn, "{env}", envs_[env_dist(rng_)]);
    replace(fqdn, "{service}", services_[service_dist(rng_)]);

    // Generate simple UUID for {uuid}
    if (fqdn.find("{uuid}") != std::string::npos) {
        std::ostringstream uuid;
        uuid << std::hex << std::setfill('0');
        std::uniform_int_distribution<uint64_t> uuid_dist;
        uuid << std::setw(8) << (uuid_dist(rng_) & 0xFFFFFFFF);
        replace(fqdn, "{uuid}", uuid.str());
    }

    return fqdn;
}

Route DataGenerator::generate_route(uint32_t vpn) {
    Route route;

    route.set_vpn(vpn);
    *route.mutable_prefix() = random_prefix();
    route.set_nexthop(random_ipv4());
    route.set_nexthop_vpn(vpn);  // Usually same VPN

    // Metadata
    route.set_virtual_ip(random_ipv4());  // CGN space: 100.64.x.x would be better
    route.set_endpoint_ip(random_ipv4());
    route.set_discovered_fqdn(random_fqdn());

    // App network ID
    std::uniform_int_distribution<int> app_dist(1, 1000);
    route.set_app_network_id("app-" + std::to_string(app_dist(rng_)));

    ++total_generated_;
    return route;
}

std::vector<Route> DataGenerator::generate_routes(uint64_t count, uint32_t num_vpns) {
    std::vector<Route> routes;
    routes.reserve(count);

    std::uniform_int_distribution<uint32_t> vpn_dist(1, num_vpns);

    for (uint64_t i = 0; i < count; ++i) {
        routes.push_back(generate_route(vpn_dist(rng_)));
    }

    return routes;
}

}  // namespace test
}  // namespace kepler
