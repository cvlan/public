// Subscription Integration Test
// Verifies that route changes are correctly delivered to subscribers
// and measures end-to-end latency

#include <grpcpp/grpcpp.h>
#include "kepler.grpc.pb.h"

#include <CLI/CLI.hpp>

#include <iostream>
#include <thread>
#include <atomic>
#include <chrono>
#include <vector>
#include <map>
#include <mutex>
#include <condition_variable>
#include <random>
#include <iomanip>
#include <cmath>

using namespace kepler;
using grpc::Channel;
using grpc::ClientContext;
using grpc::Status;

struct LatencyStats {
    std::vector<double> samples;
    std::mutex mutex;

    void add(double latency_us) {
        std::lock_guard<std::mutex> lock(mutex);
        samples.push_back(latency_us);
    }

    void merge(const LatencyStats& other) {
        std::lock_guard<std::mutex> lock(mutex);
        samples.insert(samples.end(), other.samples.begin(), other.samples.end());
    }

    void report(const std::string& title = "Latency Statistics") {
        std::lock_guard<std::mutex> lock(mutex);
        if (samples.empty()) {
            std::cout << "No latency samples collected\n";
            return;
        }

        std::sort(samples.begin(), samples.end());

        double sum = 0;
        for (double s : samples) sum += s;
        double mean = sum / samples.size();

        double variance = 0;
        for (double s : samples) variance += (s - mean) * (s - mean);
        double stddev = std::sqrt(variance / samples.size());

        auto percentile = [&](double p) {
            size_t idx = static_cast<size_t>(p * samples.size() / 100.0);
            if (idx >= samples.size()) idx = samples.size() - 1;
            return samples[idx];
        };

        std::cout << "\n========================================\n";
        std::cout << title << " (microseconds)\n";
        std::cout << "========================================\n";
        std::cout << "  Samples:    " << samples.size() << "\n";
        std::cout << "  Min:        " << std::fixed << std::setprecision(1) << samples.front() << " us\n";
        std::cout << "  Max:        " << samples.back() << " us\n";
        std::cout << "  Mean:       " << mean << " us\n";
        std::cout << "  Stddev:     " << stddev << " us\n";
        std::cout << "  P50:        " << percentile(50) << " us\n";
        std::cout << "  P90:        " << percentile(90) << " us\n";
        std::cout << "  P99:        " << percentile(99) << " us\n";
        std::cout << "  P99.9:      " << percentile(99.9) << " us\n";
        std::cout << "========================================\n";
    }
};

struct TestResult {
    std::atomic<uint64_t> routes_sent{0};
    std::atomic<uint64_t> updates_received{0};
    std::atomic<uint64_t> add_count{0};
    std::atomic<uint64_t> update_count{0};
    std::atomic<uint64_t> delete_count{0};
    std::atomic<uint64_t> mismatches{0};
    std::atomic<bool> subscriber_ready{false};
    std::atomic<bool> test_complete{false};

    // Track which routes we've sent with timestamps
    std::map<std::string, std::chrono::steady_clock::time_point> sent_timestamps;
    std::mutex sent_mutex;

    LatencyStats latency;

    void record_sent(const std::string& route_key) {
        std::lock_guard<std::mutex> lock(sent_mutex);
        sent_timestamps[route_key] = std::chrono::steady_clock::now();
    }

    void record_received(const std::string& route_key) {
        auto recv_time = std::chrono::steady_clock::now();
        std::lock_guard<std::mutex> lock(sent_mutex);
        auto it = sent_timestamps.find(route_key);
        if (it != sent_timestamps.end()) {
            auto latency_us = std::chrono::duration_cast<std::chrono::microseconds>(
                recv_time - it->second).count();
            latency.add(static_cast<double>(latency_us));
            sent_timestamps.erase(it);
        }
    }
};

std::string make_route_key(uint32_t vpn, const Prefix& prefix) {
    std::string key;
    key.reserve(8 + prefix.address().size());

    // VPN in big-endian
    key.push_back((vpn >> 24) & 0xFF);
    key.push_back((vpn >> 16) & 0xFF);
    key.push_back((vpn >> 8) & 0xFF);
    key.push_back(vpn & 0xFF);

    key.append(prefix.address());
    key.push_back(static_cast<char>(prefix.prefix_length()));

    return key;
}

Route create_test_route(uint32_t vpn, uint32_t id, const std::string& fqdn) {
    Route route;
    route.set_vpn(vpn);

    auto* prefix = route.mutable_prefix();
    prefix->set_family(AF_IPV4);

    std::string addr(4, 0);
    addr[0] = 10;
    addr[1] = (id >> 16) & 0xFF;
    addr[2] = (id >> 8) & 0xFF;
    addr[3] = id & 0xFF;
    prefix->set_address(addr);
    prefix->set_prefix_length(24);

    route.set_nexthop(std::string("\x0a\x00\x00\x01", 4));
    route.set_nexthop_vpn(vpn);
    route.set_discovered_fqdn(fqdn);

    // Set endpoint_ip for additional filtering tests
    std::string endpoint(4, 0);
    endpoint[0] = 192;
    endpoint[1] = 168;
    endpoint[2] = (id >> 8) & 0xFF;
    endpoint[3] = id & 0xFF;
    route.set_endpoint_ip(endpoint);

    return route;
}

// Preload routes into the database (with a different FQDN so they don't match the test filter)
// Uses batch API with batch sizes varying between 2-5
void preload_routes(
    std::shared_ptr<Channel> channel,
    uint32_t count,
    uint32_t num_threads = 8) {

    std::cout << "Preloading " << count << " routes with " << num_threads << " threads (batch API)..." << std::flush;
    auto start = std::chrono::steady_clock::now();

    std::atomic<uint32_t> loaded{0};
    std::atomic<uint32_t> errors{0};
    uint32_t routes_per_thread = count / num_threads;

    std::vector<std::thread> threads;
    for (uint32_t t = 0; t < num_threads; ++t) {
        threads.emplace_back([&, t]() {
            auto stub = RouteIngestion::NewStub(channel);
            uint32_t start_idx = t * routes_per_thread;
            uint32_t end_idx = (t == num_threads - 1) ? count : start_idx + routes_per_thread;

            // Random batch size between 2-5
            std::mt19937 rng(t);
            std::uniform_int_distribution<uint32_t> batch_dist(2, 5);

            uint32_t i = start_idx;
            while (i < end_idx) {
                uint32_t batch_size = std::min(batch_dist(rng), end_idx - i);

                BatchRouteUpdate batch;
                for (uint32_t j = 0; j < batch_size && i + j < end_idx; ++j) {
                    uint32_t idx = i + j;
                    uint32_t vpn = 100 + (idx / 1000);
                    uint32_t route_id = idx % 1000;
                    Route route = create_test_route(vpn, route_id,
                        "preload-" + std::to_string(vpn) + ".example.com");

                    auto* update = batch.add_updates();
                    *update->mutable_route() = route;
                    update->set_operation(ChangeType::ADD);
                }

                ClientContext ctx;
                IngestResponse resp;
                Status status = stub->BatchIngestRoutes(&ctx, batch, &resp);

                if (!status.ok()) {
                    errors += batch.updates_size();
                }
                loaded += batch.updates_size();
                i += batch.updates_size();
            }
        });
    }

    // Progress reporting thread
    std::thread progress([&]() {
        while (loaded < count) {
            std::this_thread::sleep_for(std::chrono::seconds(5));
            auto elapsed = std::chrono::steady_clock::now() - start;
            auto secs = std::chrono::duration<double>(elapsed).count();
            uint32_t current = loaded.load();
            if (current < count) {
                std::cout << "\n  " << current << " routes loaded ("
                          << std::fixed << std::setprecision(0) << current / secs
                          << " routes/sec)..." << std::flush;
            }
        }
    });

    for (auto& t : threads) {
        t.join();
    }
    progress.join();

    auto elapsed = std::chrono::steady_clock::now() - start;
    auto secs = std::chrono::duration<double>(elapsed).count();
    std::cout << "\nPreloaded " << count << " routes in " << std::fixed << std::setprecision(1)
              << secs << " seconds (" << std::setprecision(0) << count / secs << " routes/sec)";
    if (errors > 0) {
        std::cout << " [" << errors << " errors]";
    }
    std::cout << "\n\n";
}

// Per-client result for multi-client tests
struct ClientResult {
    int client_id;
    std::atomic<uint64_t> updates_received{0};
    std::atomic<uint64_t> add_count{0};
    std::atomic<uint64_t> update_count{0};
    std::atomic<uint64_t> delete_count{0};
    std::atomic<uint64_t> mismatches{0};
    LatencyStats latency;
};

void run_subscriber(
    std::shared_ptr<Channel> channel,
    const std::string& fqdn,
    uint32_t expected_events,
    TestResult& result) {

    auto stub = RouteSubscription::NewStub(channel);

    // Create subscription
    SubscribeRequest sub_req;
    sub_req.set_client_id("integration-test-client");
    auto* filter = sub_req.add_filters();
    filter->set_discovered_fqdn(fqdn);

    ClientContext sub_ctx;
    SubscribeResponse sub_resp;
    Status status = stub->Subscribe(&sub_ctx, sub_req, &sub_resp);

    if (!status.ok()) {
        std::cerr << "Failed to subscribe: " << status.error_message() << "\n";
        result.subscriber_ready = true;  // Unblock ingestion
        return;
    }

    std::string subscription_id = sub_resp.subscription_id();

    StreamRequest stream_req;
    stream_req.set_subscription_id(subscription_id);
    stream_req.set_last_sequence(0);

    ClientContext stream_ctx;
    // Set a short deadline - we'll extend it as we receive data
    stream_ctx.set_deadline(std::chrono::system_clock::now() + std::chrono::seconds(10));

    auto reader = stub->StreamChanges(&stream_ctx, stream_req);

    result.subscriber_ready = true;

    StreamResponse response;
    while (!result.test_complete && reader->Read(&response)) {
        if (result.test_complete) {
            break;
        }

        if (response.has_change()) {
            const auto& change = response.change();
            result.updates_received++;

            switch (change.type()) {
                case ChangeType::ADD:
                    result.add_count++;
                    break;
                case ChangeType::UPDATE:
                    result.update_count++;
                    break;
                case ChangeType::DELETE:
                    result.delete_count++;
                    break;
                default:
                    break;
            }

            // Record latency from DB injection time (change.timestamp() in microseconds) to now
            auto now_us = std::chrono::duration_cast<std::chrono::microseconds>(
                std::chrono::system_clock::now().time_since_epoch()).count();
            int64_t latency_us = now_us - change.timestamp();
            if (latency_us > 0) {
                result.latency.add(static_cast<double>(latency_us));
            }

            // Verify the route matches our filter
            if (change.route().discovered_fqdn() != fqdn) {
                result.mismatches++;
            }

            // Exit when we've received all expected events
            if (result.updates_received >= expected_events) {
                break;
            }
        }
    }

    reader->Finish();

    // Cleanup subscription
    ClientContext unsub_ctx;
    UnsubscribeRequest unsub_req;
    unsub_req.set_subscription_id(subscription_id);
    UnsubscribeResponse unsub_resp;
    stub->Unsubscribe(&unsub_ctx, unsub_req, &unsub_resp);
}

// Multi-client subscriber variant that uses shared timestamp tracking
void run_multi_subscriber(
    std::shared_ptr<Channel> channel,
    const std::string& fqdn,
    uint32_t expected_events,
    ClientResult& client_result,
    TestResult& shared_result) {

    auto stub = RouteSubscription::NewStub(channel);

    // Create subscription
    SubscribeRequest sub_req;
    sub_req.set_client_id("client-" + std::to_string(client_result.client_id));
    auto* filter = sub_req.add_filters();
    filter->set_discovered_fqdn(fqdn);

    ClientContext sub_ctx;
    SubscribeResponse sub_resp;
    Status status = stub->Subscribe(&sub_ctx, sub_req, &sub_resp);

    if (!status.ok()) {
        std::cerr << "Client " << client_result.client_id << " failed to subscribe: "
                  << status.error_message() << "\n";
        shared_result.subscriber_ready = true;
        return;
    }

    std::string subscription_id = sub_resp.subscription_id();

    StreamRequest stream_req;
    stream_req.set_subscription_id(subscription_id);
    stream_req.set_last_sequence(0);

    ClientContext stream_ctx;
    stream_ctx.set_deadline(std::chrono::system_clock::now() + std::chrono::seconds(30));

    auto reader = stub->StreamChanges(&stream_ctx, stream_req);

    // Signal ready (only first client should trigger ingestion start)
    shared_result.subscriber_ready = true;

    StreamResponse response;
    while (!shared_result.test_complete && reader->Read(&response)) {
        if (shared_result.test_complete) break;

        if (response.has_change()) {
            const auto& change = response.change();
            client_result.updates_received++;

            switch (change.type()) {
                case ChangeType::ADD:
                    client_result.add_count++;
                    break;
                case ChangeType::UPDATE:
                    client_result.update_count++;
                    break;
                case ChangeType::DELETE:
                    client_result.delete_count++;
                    break;
                default:
                    break;
            }

            // Record latency from DB injection time (change.timestamp() in microseconds) to now
            auto now_us = std::chrono::duration_cast<std::chrono::microseconds>(
                std::chrono::system_clock::now().time_since_epoch()).count();
            int64_t latency_us = now_us - change.timestamp();
            if (latency_us > 0) {
                client_result.latency.add(static_cast<double>(latency_us));
            }

            if (change.route().discovered_fqdn() != fqdn) {
                client_result.mismatches++;
            }

            if (client_result.updates_received >= expected_events) {
                break;
            }
        }
    }

    reader->Finish();

    ClientContext unsub_ctx;
    UnsubscribeRequest unsub_req;
    unsub_req.set_subscription_id(subscription_id);
    UnsubscribeResponse unsub_resp;
    stub->Unsubscribe(&unsub_ctx, unsub_req, &unsub_resp);
}

void run_ingestion(
    std::shared_ptr<Channel> channel,
    const std::string& target_fqdn,
    const std::string& other_fqdn,
    uint32_t route_count,
    uint32_t update_count,
    uint32_t delete_count,
    TestResult& result) {

    auto stub = RouteIngestion::NewStub(channel);

    // Wait for subscriber to be ready
    while (!result.subscriber_ready) {
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(100));  // Brief pause for stream setup

    // Random batch size between 2-5
    std::mt19937 rng(42);
    std::uniform_int_distribution<uint32_t> batch_dist(2, 5);

    std::cout << "Phase 1: Adding " << route_count << " routes...\n";

    // Add routes in batches - half with target FQDN, half with other FQDN
    uint32_t i = 0;
    while (i < route_count) {
        uint32_t batch_size = std::min(batch_dist(rng), route_count - i);

        BatchRouteUpdate batch;
        for (uint32_t j = 0; j < batch_size && i + j < route_count; ++j) {
            uint32_t idx = i + j;
            bool matches_filter = (idx % 2 == 0);
            std::string fqdn = matches_filter ? target_fqdn : other_fqdn;

            Route route = create_test_route(1, idx, fqdn);

            if (matches_filter) {
                std::string route_key = make_route_key(route.vpn(), route.prefix());
                result.record_sent(route_key);
            }

            auto* update = batch.add_updates();
            *update->mutable_route() = route;
            update->set_operation(ChangeType::ADD);
        }

        ClientContext ctx;
        IngestResponse resp;
        Status status = stub->BatchIngestRoutes(&ctx, batch, &resp);
        if (!status.ok()) {
            std::cerr << "BatchIngestRoutes (ADD) failed: " << status.error_message() << "\n";
        }
        result.routes_sent += batch.updates_size();
        i += batch.updates_size();
    }

    std::cout << "Added " << route_count << " routes\n";
    std::this_thread::sleep_for(std::chrono::milliseconds(500));

    std::cout << "\nPhase 2: Updating " << update_count << " routes...\n";

    // Update routes in batches - only update half (even indices match filter)
    i = 0;
    uint32_t update_limit = update_count / 2;  // Half because we target even indices
    while (i < update_limit) {
        uint32_t batch_size = std::min(batch_dist(rng), update_limit - i);

        BatchRouteUpdate batch;
        for (uint32_t j = 0; j < batch_size; ++j) {
            uint32_t idx = (i + j) * 2;  // Even indices only (matching filter)
            if (idx >= route_count) break;

            Route route = create_test_route(1, idx, target_fqdn);
            route.set_app_network_id("updated-network-" + std::to_string(idx));

            std::string route_key = make_route_key(route.vpn(), route.prefix());
            result.record_sent(route_key);

            auto* update = batch.add_updates();
            *update->mutable_route() = route;
            update->set_operation(ChangeType::UPDATE);
        }

        if (batch.updates_size() == 0) break;

        ClientContext ctx;
        IngestResponse resp;
        Status status = stub->BatchIngestRoutes(&ctx, batch, &resp);
        if (!status.ok()) {
            std::cerr << "BatchIngestRoutes (UPDATE) failed: " << status.error_message() << "\n";
        }
        result.routes_sent += batch.updates_size();
        i += batch.updates_size();
    }

    std::cout << "Updated " << update_count << " routes\n";
    std::this_thread::sleep_for(std::chrono::milliseconds(500));

    std::cout << "\nPhase 3: Deleting " << delete_count << " routes...\n";

    // Delete routes in batches - only delete half (even indices match filter)
    i = 0;
    uint32_t delete_limit = delete_count / 2;  // Half because we target even indices
    while (i < delete_limit) {
        uint32_t batch_size = std::min(batch_dist(rng), delete_limit - i);

        BatchRouteUpdate batch;
        for (uint32_t j = 0; j < batch_size; ++j) {
            uint32_t idx = (i + j) * 2;  // Even indices only (matching filter)
            if (idx >= route_count) break;

            Route route = create_test_route(1, idx, target_fqdn);

            std::string route_key = make_route_key(route.vpn(), route.prefix());
            result.record_sent(route_key);

            auto* update = batch.add_updates();
            *update->mutable_route() = route;
            update->set_operation(ChangeType::DELETE);
        }

        if (batch.updates_size() == 0) break;

        ClientContext ctx;
        IngestResponse resp;
        Status status = stub->BatchIngestRoutes(&ctx, batch, &resp);
        if (!status.ok()) {
            std::cerr << "BatchIngestRoutes (DELETE) failed: " << status.error_message() << "\n";
        }
        result.routes_sent += batch.updates_size();
        i += batch.updates_size();
    }

    std::cout << "Deleted " << delete_count << " routes\n";

    // Wait for all updates to be received
    std::cout << "\nWaiting for updates to propagate...\n";
    std::this_thread::sleep_for(std::chrono::seconds(2));

    result.test_complete = true;
}

int main(int argc, char** argv) {
    CLI::App app{"Subscription Integration Test"};

    std::string target = "localhost:50051";
    uint32_t route_count = 1000;
    uint32_t update_count = 100;
    uint32_t delete_count = 50;
    uint32_t preload_count = 0;
    uint32_t client_count = 1;

    app.add_option("-t,--target", target, "Kepler server address");
    app.add_option("-r,--routes", route_count, "Number of routes to add during test");
    app.add_option("-u,--updates", update_count, "Number of routes to update");
    app.add_option("-d,--deletes", delete_count, "Number of routes to delete");
    app.add_option("-p,--preload", preload_count, "Number of routes to preload before test");
    app.add_option("-c,--clients", client_count, "Number of subscriber clients");

    CLI11_PARSE(app, argc, argv);

    std::cout << "========================================\n";
    std::cout << "Subscription Integration Test\n";
    std::cout << "========================================\n";
    std::cout << "Target:     " << target << "\n";
    std::cout << "Preload:    " << preload_count << " routes\n";
    std::cout << "Clients:    " << client_count << "\n";
    std::cout << "Routes:     " << route_count << "\n";
    std::cout << "Updates:    " << update_count << "\n";
    std::cout << "Deletes:    " << delete_count << "\n";
    std::cout << "========================================\n\n";

    auto channel = grpc::CreateChannel(target, grpc::InsecureChannelCredentials());

    // Wait for connection
    if (!channel->WaitForConnected(std::chrono::system_clock::now() + std::chrono::seconds(5))) {
        std::cerr << "Failed to connect to " << target << "\n";
        return 1;
    }

    // Preload routes if requested
    if (preload_count > 0) {
        preload_routes(channel, preload_count);
    }

    TestResult result;
    std::string target_fqdn = "integration-test.example.com";
    std::string other_fqdn = "other-service.example.com";

    // Calculate expected counts upfront
    // Half the routes match the filter (even-indexed routes have target_fqdn)
    uint32_t expected_adds = route_count / 2;
    // Update/delete loops iterate half the count, targeting even indices
    uint32_t expected_updates = update_count / 2;
    uint32_t expected_deletes = delete_count / 2;
    uint32_t expected_total = expected_adds + expected_updates + expected_deletes;

    // Multi-client test
    if (client_count > 1) {
        std::vector<std::unique_ptr<ClientResult>> client_results;
        std::vector<std::thread> subscriber_threads;

        // Create client results
        for (uint32_t i = 0; i < client_count; ++i) {
            auto cr = std::make_unique<ClientResult>();
            cr->client_id = i;
            client_results.push_back(std::move(cr));
        }

        // Start all subscriber threads
        for (uint32_t i = 0; i < client_count; ++i) {
            subscriber_threads.emplace_back([&, i] {
                run_multi_subscriber(channel, target_fqdn, expected_total,
                                    *client_results[i], result);
            });
        }

        // Wait for all subscribers to be ready
        while (!result.subscriber_ready) {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
        // Give all clients time to connect
        std::this_thread::sleep_for(std::chrono::milliseconds(200));

        // Run ingestion
        run_ingestion(channel, target_fqdn, other_fqdn,
                      route_count, update_count, delete_count, result);

        // Wait for all subscribers to finish
        for (auto& t : subscriber_threads) {
            t.join();
        }

        // Report per-client results
        std::cout << "\n========================================\n";
        std::cout << "Per-Client Results (" << client_count << " clients)\n";
        std::cout << "========================================\n";

        LatencyStats aggregate_latency;
        LatencyStats worst_case_latency;
        uint64_t total_mismatches = 0;
        bool all_clients_ok = true;

        for (uint32_t i = 0; i < client_count; ++i) {
            auto& cr = *client_results[i];
            std::cout << "Client " << i << ": "
                      << cr.updates_received << " updates ("
                      << cr.add_count << " adds, "
                      << cr.update_count << " updates, "
                      << cr.delete_count << " deletes)\n";

            if (cr.add_count != expected_adds ||
                cr.update_count != expected_updates ||
                cr.delete_count != expected_deletes) {
                all_clients_ok = false;
            }

            total_mismatches += cr.mismatches;
            aggregate_latency.merge(cr.latency);

            // Track worst-case (max latency per event across all clients)
            for (double sample : cr.latency.samples) {
                worst_case_latency.add(sample);
            }
        }

        std::cout << "========================================\n";
        std::cout << "Total mismatches: " << total_mismatches << "\n";

        aggregate_latency.report("Aggregate Latency (all clients)");
        worst_case_latency.report("Per-Event Latency Distribution");

        if (!all_clients_ok || total_mismatches > 0) {
            std::cout << "\n*** TESTS FAILED ***\n";
            return 1;
        }

        std::cout << "\n*** ALL TESTS PASSED ***\n";
        return 0;
    }

    // Ingestion-only mode (for external subscribers)
    if (client_count == 0) {
        if (route_count > 0 || update_count > 0 || delete_count > 0) {
            std::cout << "Ingestion-only mode (no internal subscribers)\n";
            result.subscriber_ready = true;  // No subscriber to wait for
            run_ingestion(channel, target_fqdn, other_fqdn,
                          route_count, update_count, delete_count, result);
            std::cout << "\nIngestion complete. Sent " << result.routes_sent << " route operations.\n";
        }
        std::cout << "\n*** ALL TESTS PASSED ***\n";
        return 0;
    }

    // Single-client test (original behavior)
    std::thread subscriber_thread([&] {
        run_subscriber(channel, target_fqdn, expected_total, result);
    });

    // Run ingestion
    run_ingestion(channel, target_fqdn, other_fqdn,
                  route_count, update_count, delete_count, result);

    // Wait for subscriber to finish
    subscriber_thread.join();

    std::cout << "\n========================================\n";
    std::cout << "Test Results\n";
    std::cout << "========================================\n";
    std::cout << "Routes sent:       " << result.routes_sent << "\n";
    std::cout << "Updates received:  " << result.updates_received << "\n";
    std::cout << "  - Adds:          " << result.add_count << " (expected: " << expected_adds << ")\n";
    std::cout << "  - Updates:       " << result.update_count << " (expected: " << expected_updates << ")\n";
    std::cout << "  - Deletes:       " << result.delete_count << " (expected: " << expected_deletes << ")\n";
    std::cout << "Filter mismatches: " << result.mismatches << "\n";
    std::cout << "========================================\n";

    result.latency.report();

    // Verify results
    bool success = true;

    if (result.mismatches > 0) {
        std::cerr << "\nFAIL: Received " << result.mismatches << " updates that didn't match filter\n";
        success = false;
    }

    if (result.add_count != expected_adds) {
        std::cerr << "\nFAIL: Expected " << expected_adds << " adds, got " << result.add_count << "\n";
        success = false;
    }

    if (result.update_count != expected_updates) {
        std::cerr << "\nFAIL: Expected " << expected_updates << " updates, got " << result.update_count << "\n";
        success = false;
    }

    if (result.delete_count != expected_deletes) {
        std::cerr << "\nFAIL: Expected " << expected_deletes << " deletes, got " << result.delete_count << "\n";
        success = false;
    }

    if (success) {
        std::cout << "\n*** ALL TESTS PASSED ***\n";
        return 0;
    } else {
        std::cout << "\n*** TESTS FAILED ***\n";
        return 1;
    }
}
