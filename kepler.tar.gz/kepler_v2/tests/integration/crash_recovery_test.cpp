// Crash Recovery Test
// Verifies that Kepler correctly recovers from crashes during ingestion
// with active subscriptions
//
// Test flow:
// 1. Connect to Kepler, create subscription, get initial sequence
// 2. Ingest routes and track sequence numbers
// 3. Disconnect (simulating crash from client perspective)
// 4. Reconnect and verify:
//    - Route count matches expected
//    - Subscription can resume from last known sequence
//    - All changes after last sequence are received

#include <grpcpp/grpcpp.h>
#include "kepler.grpc.pb.h"

#include <CLI/CLI.hpp>

#include <iostream>
#include <thread>
#include <atomic>
#include <chrono>
#include <vector>
#include <set>
#include <random>
#include <fstream>

using namespace kepler;
using grpc::Channel;
using grpc::ClientContext;
using grpc::Status;

// Test configuration
struct TestConfig {
    std::string target = "127.0.0.1:50051";
    uint32_t initial_routes = 1000;
    uint32_t additional_routes = 500;
    std::string state_file = "/tmp/kepler_crash_test_state";
    bool verify_only = false;
    bool setup_only = false;
};

// Persistent state saved between crash and recovery
struct TestState {
    uint64_t last_sequence = 0;
    uint64_t expected_route_count = 0;
    std::string subscription_id;
    std::set<std::string> route_ids;

    void save(const std::string& path) {
        std::ofstream f(path);
        f << last_sequence << "\n";
        f << expected_route_count << "\n";
        f << subscription_id << "\n";
        f << route_ids.size() << "\n";
        for (const auto& id : route_ids) {
            f << id << "\n";
        }
    }

    bool load(const std::string& path) {
        std::ifstream f(path);
        if (!f) return false;

        size_t count;
        f >> last_sequence >> expected_route_count >> subscription_id >> count;
        f.ignore(); // skip newline

        route_ids.clear();
        std::string id;
        for (size_t i = 0; i < count && std::getline(f, id); ++i) {
            if (!id.empty()) route_ids.insert(id);
        }
        return true;
    }
};

// Helper to create a route
Route create_route(uint32_t vpn, uint32_t index, const std::string& fqdn_prefix) {
    Route route;
    route.set_vpn(vpn);

    auto* prefix = route.mutable_prefix();
    prefix->set_family(AF_IPV4);
    std::string addr(4, 0);
    addr[0] = 10;
    addr[1] = (index >> 16) & 0xFF;
    addr[2] = (index >> 8) & 0xFF;
    addr[3] = index & 0xFF;
    prefix->set_address(addr);
    prefix->set_prefix_length(24);

    route.set_nexthop(std::string("\x0a\x00\x00\x01", 4));
    route.set_nexthop_vpn(vpn);
    route.set_discovered_fqdn(fqdn_prefix + "-" + std::to_string(index) + ".test.local");
    route.set_endpoint_ip(std::string("\xc0\xa8\x01\x01", 4));
    route.set_virtual_ip(std::string("\x64\x40\x00\x01", 4));

    return route;
}

// Phase 1: Setup - ingest initial routes, create subscription
bool setup_phase(const TestConfig& config, TestState& state) {
    std::cout << "=== Phase 1: Setup ===\n";

    auto channel = grpc::CreateChannel(config.target, grpc::InsecureChannelCredentials());
    auto ingestion = RouteIngestion::NewStub(channel);
    auto lookup = RouteLookup::NewStub(channel);
    auto subscription = RouteSubscription::NewStub(channel);

    // Get initial stats
    {
        ClientContext ctx;
        StatsRequest req;
        StatsResponse resp;
        auto status = lookup->GetStats(&ctx, req, &resp);
        if (!status.ok()) {
            std::cerr << "Failed to get stats: " << status.error_message() << "\n";
            return false;
        }
        std::cout << "Initial route count: " << resp.total_routes() << "\n";
        std::cout << "Initial sequence: " << resp.newest_sequence() << "\n";
        state.last_sequence = resp.newest_sequence();
    }

    // Ingest initial routes
    std::cout << "Ingesting " << config.initial_routes << " initial routes...\n";
    {
        ClientContext ctx;
        BatchRouteUpdate req;
        IngestResponse resp;

        for (uint32_t i = 0; i < config.initial_routes; ++i) {
            auto* update = req.add_updates();
            *update->mutable_route() = create_route(1, i, "initial");
            update->set_operation(ADD);
        }

        auto status = ingestion->BatchIngestRoutes(&ctx, req, &resp);
        if (!status.ok()) {
            std::cerr << "Batch ingest failed: " << status.error_message() << "\n";
            return false;
        }
        std::cout << "Ingested: " << resp.added() << " routes\n";
    }

    // Create subscription
    std::cout << "Creating subscription...\n";
    {
        ClientContext ctx;
        SubscribeRequest req;
        req.set_client_id("crash-test-client");
        // Subscribe to VPN 1
        auto* filter = req.add_filters();
        filter->set_vpn(1);

        SubscribeResponse resp;
        auto status = subscription->Subscribe(&ctx, req, &resp);
        if (!status.ok()) {
            std::cerr << "Subscribe failed: " << status.error_message() << "\n";
            return false;
        }
        state.subscription_id = resp.subscription_id();
        std::cout << "Subscription ID: " << state.subscription_id << "\n";
    }

    // Get current sequence after setup
    {
        ClientContext ctx;
        StatsRequest req;
        StatsResponse resp;
        auto status = lookup->GetStats(&ctx, req, &resp);
        if (status.ok()) {
            state.last_sequence = resp.newest_sequence();
            state.expected_route_count = resp.total_routes();
            std::cout << "Sequence after setup: " << state.last_sequence << "\n";
            std::cout << "Route count after setup: " << state.expected_route_count << "\n";
        }
    }

    // Ingest additional routes (these are the ones we'll verify after crash)
    std::cout << "Ingesting " << config.additional_routes << " additional routes...\n";
    {
        ClientContext ctx;
        BatchRouteUpdate req;
        IngestResponse resp;

        for (uint32_t i = 0; i < config.additional_routes; ++i) {
            auto* update = req.add_updates();
            auto route = create_route(1, config.initial_routes + i, "additional");
            state.route_ids.insert(route.discovered_fqdn());
            *update->mutable_route() = route;
            update->set_operation(ADD);
        }

        auto status = ingestion->BatchIngestRoutes(&ctx, req, &resp);
        if (!status.ok()) {
            std::cerr << "Batch ingest failed: " << status.error_message() << "\n";
            return false;
        }
        std::cout << "Ingested: " << resp.added() << " additional routes\n";
        state.expected_route_count += resp.added();
    }

    // Save state before "crash"
    state.save(config.state_file);
    std::cout << "State saved to: " << config.state_file << "\n";
    std::cout << "Expected route count: " << state.expected_route_count << "\n";
    std::cout << "Last sequence before crash: " << state.last_sequence << "\n";

    return true;
}

// Phase 2: Verify - check data after recovery
bool verify_phase(const TestConfig& config, TestState& state) {
    std::cout << "\n=== Phase 2: Verify Recovery ===\n";

    // Load saved state
    if (!state.load(config.state_file)) {
        std::cerr << "Failed to load state file: " << config.state_file << "\n";
        return false;
    }
    std::cout << "Loaded state from: " << config.state_file << "\n";
    std::cout << "Expected route count: " << state.expected_route_count << "\n";
    std::cout << "Last known sequence: " << state.last_sequence << "\n";
    std::cout << "Subscription ID: " << state.subscription_id << "\n";

    auto channel = grpc::CreateChannel(config.target, grpc::InsecureChannelCredentials());
    auto lookup = RouteLookup::NewStub(channel);
    auto subscription = RouteSubscription::NewStub(channel);

    bool all_passed = true;

    // Test 1: Verify route count matches
    std::cout << "\n--- Test 1: Route Count ---\n";
    {
        ClientContext ctx;
        StatsRequest req;
        StatsResponse resp;
        auto status = lookup->GetStats(&ctx, req, &resp);
        if (!status.ok()) {
            std::cerr << "FAIL: Cannot get stats: " << status.error_message() << "\n";
            return false;
        }
        uint64_t actual_count = resp.total_routes();

        if (actual_count == state.expected_route_count) {
            std::cout << "PASS: Route count matches (" << actual_count << ")\n";
        } else {
            std::cerr << "FAIL: Route count mismatch. Expected: " << state.expected_route_count
                      << ", Got: " << actual_count << "\n";
            all_passed = false;
        }
    }

    // Test 2: Verify subscription still exists
    std::cout << "\n--- Test 2: Subscription Exists ---\n";
    {
        ClientContext ctx;
        GetSubscriptionRequest req;
        req.set_subscription_id(state.subscription_id);
        SubscribeResponse resp;
        auto status = subscription->GetSubscription(&ctx, req, &resp);
        if (status.ok() && resp.subscription_id() == state.subscription_id) {
            std::cout << "PASS: Subscription recovered\n";
        } else {
            std::cerr << "FAIL: Subscription not found after recovery\n";
            all_passed = false;
        }
    }

    // Test 3: Verify we can resume streaming from last sequence
    std::cout << "\n--- Test 3: Stream Resume ---\n";
    {
        ClientContext ctx;
        ctx.set_deadline(std::chrono::system_clock::now() + std::chrono::seconds(5));

        StreamRequest req;
        req.set_subscription_id(state.subscription_id);
        req.set_last_sequence(state.last_sequence);
        req.set_full_sync(false);

        auto reader = subscription->StreamChanges(&ctx, req);

        uint64_t changes_received = 0;
        std::set<std::string> received_fqdns;
        StreamResponse resp;

        while (reader->Read(&resp)) {
            if (resp.has_change()) {
                changes_received++;
                received_fqdns.insert(resp.change().route().discovered_fqdn());
            }
        }

        auto status = reader->Finish();

        // We should receive changes for the additional routes
        std::cout << "Changes received: " << changes_received << "\n";
        std::cout << "Expected (additional routes): " << config.additional_routes << "\n";

        if (changes_received >= config.additional_routes) {
            std::cout << "PASS: Received all changes for additional routes\n";
        } else {
            std::cerr << "FAIL: Missing changes. Expected at least " << config.additional_routes
                      << ", got " << changes_received << "\n";
            all_passed = false;
        }
    }

    // Test 4: Verify specific routes exist
    std::cout << "\n--- Test 4: Route Data Integrity ---\n";
    {
        int verified = 0;
        int missing = 0;

        // Check a sample of the additional routes
        for (const auto& fqdn : state.route_ids) {
            ClientContext ctx;
            FqdnRequest req;
            req.set_discovered_fqdn(fqdn);
            RoutesResponse resp;

            auto status = lookup->GetRoutesByFqdn(&ctx, req, &resp);
            if (status.ok() && resp.routes_size() > 0) {
                verified++;
            } else {
                missing++;
                if (missing <= 5) {
                    std::cerr << "  Missing route: " << fqdn << "\n";
                }
            }

            // Only check first 100 to keep test fast
            if (verified + missing >= 100) break;
        }

        if (missing == 0) {
            std::cout << "PASS: All sampled routes found (" << verified << " verified)\n";
        } else {
            std::cerr << "FAIL: " << missing << " routes missing out of " << (verified + missing) << " checked\n";
            all_passed = false;
        }
    }

    // Cleanup state file
    std::remove(config.state_file.c_str());

    return all_passed;
}

int main(int argc, char** argv) {
    TestConfig config;

    CLI::App app{"Kepler Crash Recovery Test"};
    app.add_option("--target", config.target, "Kepler server address");
    app.add_option("--initial-routes", config.initial_routes, "Initial routes to ingest");
    app.add_option("--additional-routes", config.additional_routes, "Additional routes before crash");
    app.add_option("--state-file", config.state_file, "State file path");
    app.add_flag("--setup-only", config.setup_only, "Only run setup phase");
    app.add_flag("--verify-only", config.verify_only, "Only run verify phase");

    CLI11_PARSE(app, argc, argv);

    std::cout << "========================================\n";
    std::cout << "Kepler Crash Recovery Test\n";
    std::cout << "========================================\n";
    std::cout << "Target: " << config.target << "\n";
    std::cout << "State file: " << config.state_file << "\n\n";

    TestState state;
    bool success = true;

    if (!config.verify_only) {
        success = setup_phase(config, state);
        if (!success) {
            std::cerr << "\nSetup phase failed!\n";
            return 1;
        }

        if (config.setup_only) {
            std::cout << "\nSetup complete. Kill the server and restart, then run with --verify-only\n";
            return 0;
        }
    }

    if (!config.setup_only) {
        success = verify_phase(config, state);
    }

    std::cout << "\n========================================\n";
    if (success) {
        std::cout << "RESULT: ALL TESTS PASSED\n";
    } else {
        std::cout << "RESULT: SOME TESTS FAILED\n";
    }
    std::cout << "========================================\n";

    return success ? 0 : 1;
}
