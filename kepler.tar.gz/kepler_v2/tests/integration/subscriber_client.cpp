// Standalone subscriber client for multi-process latency testing
// Usage: subscriber_client --target=host:port --fqdn=filter --id=N --ready-file=path --results-file=path

#include <grpcpp/grpcpp.h>
#include "kepler.grpc.pb.h"

#include <CLI/CLI.hpp>

#include <iostream>
#include <fstream>
#include <chrono>
#include <vector>
#include <atomic>
#include <csignal>

using namespace kepler;
using grpc::Channel;
using grpc::ClientContext;
using grpc::Status;

static std::atomic<bool> g_shutdown{false};

void signal_handler(int) {
    g_shutdown = true;
}

struct LatencyStats {
    std::vector<double> samples;
    uint64_t add_count = 0;
    uint64_t update_count = 0;
    uint64_t delete_count = 0;
    uint64_t mismatches = 0;

    void write_to_file(const std::string& path) {
        std::ofstream out(path);
        out << "adds=" << add_count << "\n";
        out << "updates=" << update_count << "\n";
        out << "deletes=" << delete_count << "\n";
        out << "mismatches=" << mismatches << "\n";
        out << "samples=" << samples.size() << "\n";
        for (double s : samples) {
            out << s << "\n";
        }
    }
};

int main(int argc, char** argv) {
    CLI::App app{"Subscriber Client"};

    std::string target = "localhost:50051";
    std::string fqdn;
    int client_id = 0;
    std::string ready_file;
    std::string results_file;
    uint32_t expected_events = 0;

    app.add_option("-t,--target", target, "Kepler server address")->required();
    app.add_option("-f,--fqdn", fqdn, "FQDN to subscribe to")->required();
    app.add_option("-i,--id", client_id, "Client ID");
    app.add_option("-r,--ready-file", ready_file, "File to create when ready");
    app.add_option("-o,--results-file", results_file, "File to write results to")->required();
    app.add_option("-e,--expected", expected_events, "Expected number of events (0 = unlimited)");

    CLI11_PARSE(app, argc, argv);

    signal(SIGTERM, signal_handler);
    signal(SIGINT, signal_handler);

    auto channel = grpc::CreateChannel(target, grpc::InsecureChannelCredentials());

    if (!channel->WaitForConnected(std::chrono::system_clock::now() + std::chrono::seconds(10))) {
        std::cerr << "Client " << client_id << ": Failed to connect to " << target << "\n";
        return 1;
    }

    auto stub = RouteSubscription::NewStub(channel);

    // Create subscription
    SubscribeRequest sub_req;
    sub_req.set_client_id("subscriber-client-" + std::to_string(client_id));
    auto* filter = sub_req.add_filters();
    filter->set_discovered_fqdn(fqdn);

    ClientContext sub_ctx;
    SubscribeResponse sub_resp;
    Status status = stub->Subscribe(&sub_ctx, sub_req, &sub_resp);

    if (!status.ok()) {
        std::cerr << "Client " << client_id << ": Failed to subscribe: " << status.error_message() << "\n";
        return 1;
    }

    std::string subscription_id = sub_resp.subscription_id();

    // Start streaming
    StreamRequest stream_req;
    stream_req.set_subscription_id(subscription_id);
    stream_req.set_last_sequence(0);

    ClientContext stream_ctx;
    stream_ctx.set_deadline(std::chrono::system_clock::now() + std::chrono::seconds(120));

    auto reader = stub->StreamChanges(&stream_ctx, stream_req);

    // Signal ready
    if (!ready_file.empty()) {
        std::ofstream ready(ready_file);
        ready << "ready\n";
    }

    LatencyStats stats;
    auto start_time = std::chrono::steady_clock::now();

    StreamResponse response;
    while (!g_shutdown && reader->Read(&response)) {
        if (g_shutdown) break;

        if (response.has_change()) {
            auto recv_time = std::chrono::steady_clock::now();
            const auto& change = response.change();

            // Record latency from start of streaming
            auto latency_us = std::chrono::duration_cast<std::chrono::microseconds>(
                recv_time - start_time).count();
            stats.samples.push_back(static_cast<double>(latency_us));

            switch (change.type()) {
                case ChangeType::ADD:
                    stats.add_count++;
                    break;
                case ChangeType::UPDATE:
                    stats.update_count++;
                    break;
                case ChangeType::DELETE:
                    stats.delete_count++;
                    break;
                default:
                    break;
            }

            if (change.route().discovered_fqdn() != fqdn) {
                stats.mismatches++;
            }

            // Exit when expected events received
            if (expected_events > 0 &&
                (stats.add_count + stats.update_count + stats.delete_count) >= expected_events) {
                break;
            }
        }
    }

    reader->Finish();

    // Cleanup
    ClientContext unsub_ctx;
    UnsubscribeRequest unsub_req;
    unsub_req.set_subscription_id(subscription_id);
    UnsubscribeResponse unsub_resp;
    stub->Unsubscribe(&unsub_ctx, unsub_req, &unsub_resp);

    // Write results
    stats.write_to_file(results_file);

    std::cout << "Client " << client_id << ": "
              << stats.add_count << " adds, "
              << stats.update_count << " updates, "
              << stats.delete_count << " deletes\n";

    return 0;
}
