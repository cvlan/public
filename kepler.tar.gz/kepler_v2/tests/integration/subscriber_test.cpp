#include "kepler.grpc.pb.h"

#include <CLI/CLI.hpp>
#include <grpcpp/grpcpp.h>

#include <iostream>
#include <chrono>
#include <thread>
#include <atomic>
#include <vector>
#include <random>

using namespace kepler;

std::atomic<uint64_t> total_changes{0};
std::atomic<bool> running{true};

void subscriber_thread(const std::string& target, const std::string& fqdn, int thread_id) {
    auto channel = grpc::CreateChannel(target, grpc::InsecureChannelCredentials());
    auto sub_stub = RouteSubscription::NewStub(channel);

    // Create subscription
    grpc::ClientContext sub_context;
    SubscribeRequest sub_request;
    sub_request.set_client_id("subscriber-test-" + std::to_string(thread_id));

    auto* filter = sub_request.add_filters();
    filter->set_discovered_fqdn(fqdn);

    SubscribeResponse sub_response;
    auto status = sub_stub->Subscribe(&sub_context, sub_request, &sub_response);
    if (!status.ok()) {
        std::cerr << "Thread " << thread_id << ": Failed to subscribe: " << status.error_message() << std::endl;
        return;
    }

    std::cout << "Thread " << thread_id << ": Subscribed to " << fqdn << " (ID: " << sub_response.subscription_id() << ")\n";

    // Stream changes
    grpc::ClientContext stream_context;
    StreamRequest stream_request;
    stream_request.set_subscription_id(sub_response.subscription_id());
    stream_request.set_last_sequence(0);
    stream_request.set_full_sync(true);

    auto reader = sub_stub->StreamChanges(&stream_context, stream_request);
    StreamResponse response;

    uint64_t local_changes = 0;

    while (running && reader->Read(&response)) {
        if (response.has_change() || response.has_full_sync_route()) {
            ++local_changes;
            ++total_changes;
        }
    }

    std::cout << "Thread " << thread_id << ": Received " << local_changes << " changes\n";
}

int main(int argc, char** argv) {
    CLI::App app{"Kepler Subscriber Test - Test subscription streaming"};

    std::string target = "localhost:50051";
    uint32_t num_fqdns = 100;
    uint32_t duration_sec = 60;

    app.add_option("-t,--target", target, "Kepler server address")->default_val("localhost:50051");
    app.add_option("-f,--fqdns", num_fqdns, "Number of FQDNs to subscribe to")->default_val(100);
    app.add_option("-d,--duration", duration_sec, "Test duration in seconds")->default_val(60);

    CLI11_PARSE(app, argc, argv);

    std::cout << "Kepler Subscriber Test\n";
    std::cout << "======================\n";
    std::cout << "Target: " << target << "\n";
    std::cout << "Subscribers: " << num_fqdns << "\n";
    std::cout << "Duration: " << duration_sec << " seconds\n\n";

    // Get list of FQDNs from server
    auto channel = grpc::CreateChannel(target, grpc::InsecureChannelCredentials());
    auto lookup_stub = RouteLookup::NewStub(channel);

    grpc::ClientContext list_context;
    ListFqdnsRequest list_request;
    list_request.set_limit(num_fqdns);
    ListFqdnsResponse list_response;

    auto status = lookup_stub->ListFqdns(&list_context, list_request, &list_response);
    if (!status.ok()) {
        std::cerr << "Failed to list FQDNs: " << status.error_message() << std::endl;
        return 1;
    }

    if (list_response.fqdns_size() == 0) {
        std::cerr << "No FQDNs found in the system. Run upstream_simulator first.\n";
        return 1;
    }

    std::cout << "Found " << list_response.fqdns_size() << " FQDNs\n\n";

    // Start subscriber threads
    std::vector<std::thread> threads;
    auto start_time = std::chrono::steady_clock::now();

    for (int i = 0; i < std::min(static_cast<int>(num_fqdns), list_response.fqdns_size()); ++i) {
        threads.emplace_back(subscriber_thread, target, list_response.fqdns(i), i);
    }

    std::cout << "Started " << threads.size() << " subscriber threads\n";
    std::cout << "Running for " << duration_sec << " seconds...\n\n";

    // Wait for duration
    std::this_thread::sleep_for(std::chrono::seconds(duration_sec));

    running = false;

    // Wait for threads
    for (auto& t : threads) {
        if (t.joinable()) {
            t.join();
        }
    }

    auto end_time = std::chrono::steady_clock::now();
    auto total_duration = std::chrono::duration_cast<std::chrono::seconds>(end_time - start_time);

    std::cout << "\nResults\n";
    std::cout << "=======\n";
    std::cout << "Total changes received: " << total_changes.load() << "\n";
    std::cout << "Duration: " << total_duration.count() << " seconds\n";
    std::cout << "Average rate: " << (total_duration.count() > 0 ? total_changes.load() / total_duration.count() : 0) << " changes/sec\n";

    return 0;
}
