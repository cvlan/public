#pragma once

#include "kepler.pb.h"
#include <random>
#include <string>
#include <vector>

namespace kepler {
namespace test {

class DataGenerator {
public:
    explicit DataGenerator(uint32_t seed = 42);

    // Generate a random route
    Route generate_route(uint32_t vpn);

    // Generate multiple routes distributed across VPNs
    std::vector<Route> generate_routes(uint64_t count, uint32_t num_vpns);

    // Generate a random IPv4 address as bytes
    std::string random_ipv4();

    // Generate a random prefix
    Prefix random_prefix();

    // Generate a random FQDN
    std::string random_fqdn();

    // Get statistics about generated data
    uint64_t get_total_generated() const { return total_generated_; }

private:
    std::mt19937_64 rng_;
    uint64_t total_generated_ = 0;

    // Templates for FQDN generation
    static const std::vector<std::string> fqdn_templates_;
    static const std::vector<std::string> regions_;
    static const std::vector<std::string> envs_;
    static const std::vector<std::string> services_;
};

}  // namespace test
}  // namespace kepler
