#include "data_generator.h"
#include "kepler.grpc.pb.h"

#include <CLI/CLI.hpp>
#include <grpcpp/grpcpp.h>

#include <iostream>
#include <chrono>
#include <thread>
#include <atomic>
#include <iomanip>

using namespace kepler;
using namespace kepler::test;

int main(int argc, char** argv) {
    CLI::App app{"Kepler Upstream Simulator - Generate and inject routes"};

    std::string target = "localhost:50051";
    uint64_t num_routes = 1000000;
    uint32_t num_vpns = 10000;
    uint32_t rate = 20000;  // routes per second
    uint32_t batch_size = 1000;
    bool verify = false;
    bool use_sync = true;
    uint32_t seed = 42;

    app.add_option("-t,--target", target, "Kepler server address")->default_val("localhost:50051");
    app.add_option("-n,--routes", num_routes, "Number of routes to generate")->default_val(1000000);
    app.add_option("-v,--vpns", num_vpns, "Number of VPNs to distribute routes across")->default_val(10000);
    app.add_option("-r,--rate", rate, "Routes per second (0 = unlimited)")->default_val(20000);
    app.add_option("-b,--batch", batch_size, "Batch size for streaming")->default_val(1000);
    app.add_flag("--verify", verify, "Verify routes after injection");
    app.add_flag("--no-sync", [&](size_t) { use_sync = false; }, "Don't use sync protocol");
    app.add_option("--seed", seed, "Random seed for reproducibility")->default_val(42);

    CLI11_PARSE(app, argc, argv);

    std::cout << "Kepler Upstream Simulator\n";
    std::cout << "=========================\n";
    std::cout << "Target: " << target << "\n";
    std::cout << "Routes: " << num_routes << "\n";
    std::cout << "VPNs: " << num_vpns << "\n";
    std::cout << "Rate: " << (rate > 0 ? std::to_string(rate) + "/sec" : "unlimited") << "\n";
    std::cout << "Batch size: " << batch_size << "\n";
    std::cout << "Sync protocol: " << (use_sync ? "enabled" : "disabled") << "\n";
    std::cout << "\n";

    // Create gRPC channel
    grpc::ChannelArguments args;
    args.SetMaxReceiveMessageSize(64 * 1024 * 1024);
    args.SetMaxSendMessageSize(64 * 1024 * 1024);

    auto channel = grpc::CreateCustomChannel(target, grpc::InsecureChannelCredentials(), args);
    auto stub = RouteIngestion::NewStub(channel);

    // Initialize data generator
    DataGenerator generator(seed);

    auto start_time = std::chrono::steady_clock::now();
    uint64_t routes_sent = 0;
    uint64_t errors = 0;

    std::string sync_id;

    // Start sync if using sync protocol
    if (use_sync) {
        grpc::ClientContext context;
        SyncRequest request;
        SyncResponse response;

        auto status = stub->StartSync(&context, request, &response);
        if (!status.ok()) {
            std::cerr << "Failed to start sync: " << status.error_message() << std::endl;
            return 1;
        }
        sync_id = response.sync_id();
        std::cout << "Started sync session: " << sync_id << "\n\n";
    }

    // Send routes in batches
    std::cout << "Sending routes...\n";

    grpc::ClientContext stream_context;
    IngestResponse ingest_response;
    auto writer = stub->IngestRoutes(&stream_context, &ingest_response);

    auto batch_start = std::chrono::steady_clock::now();
    uint64_t batch_count = 0;

    for (uint64_t i = 0; i < num_routes; ++i) {
        // Generate and send route
        uint32_t vpn = (i % num_vpns) + 1;
        Route route = generator.generate_route(vpn);

        RouteUpdate update;
        *update.mutable_route() = route;
        update.set_operation(ChangeType::ADD);

        if (!writer->Write(update)) {
            ++errors;
            continue;
        }

        ++routes_sent;
        ++batch_count;

        // Rate limiting
        if (rate > 0 && batch_count >= batch_size) {
            auto batch_end = std::chrono::steady_clock::now();
            auto batch_duration = std::chrono::duration_cast<std::chrono::microseconds>(batch_end - batch_start);
            auto expected_duration = std::chrono::microseconds(batch_count * 1000000 / rate);

            if (batch_duration < expected_duration) {
                std::this_thread::sleep_for(expected_duration - batch_duration);
            }

            batch_start = std::chrono::steady_clock::now();
            batch_count = 0;
        }

        // Progress report
        if (routes_sent % 100000 == 0) {
            auto now = std::chrono::steady_clock::now();
            auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - start_time);
            double actual_rate = elapsed.count() > 0 ? static_cast<double>(routes_sent) / elapsed.count() : 0;

            std::cout << "\r  Progress: " << routes_sent << "/" << num_routes
                      << " (" << std::fixed << std::setprecision(1)
                      << (100.0 * routes_sent / num_routes) << "%)"
                      << " Rate: " << static_cast<int>(actual_rate) << "/sec"
                      << std::flush;
        }
    }

    writer->WritesDone();
    auto status = writer->Finish();

    auto end_time = std::chrono::steady_clock::now();
    auto total_duration = std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time);

    std::cout << "\n\n";

    if (!status.ok()) {
        std::cerr << "Stream error: " << status.error_message() << std::endl;
    }

    // Complete sync if using sync protocol
    if (use_sync) {
        grpc::ClientContext context;
        SyncComplete request;
        request.set_sync_id(sync_id);
        request.set_delete_missing(false);  // Don't delete during initial load
        SyncResponse response;

        auto status = stub->CompleteSync(&context, request, &response);
        if (!status.ok()) {
            std::cerr << "Failed to complete sync: " << status.error_message() << std::endl;
        } else {
            std::cout << "Sync completed: " << response.message() << "\n";
        }
    }

    // Print summary
    std::cout << "\nSummary\n";
    std::cout << "=======\n";
    std::cout << "Routes sent: " << routes_sent << "\n";
    std::cout << "Server processed: " << ingest_response.processed() << "\n";
    std::cout << "  Added: " << ingest_response.added() << "\n";
    std::cout << "  Updated: " << ingest_response.updated() << "\n";
    std::cout << "  Errors: " << ingest_response.errors_size() << "\n";
    std::cout << "Total time: " << total_duration.count() << " ms\n";
    std::cout << "Average rate: " << (total_duration.count() > 0 ? routes_sent * 1000 / total_duration.count() : 0) << " routes/sec\n";

    // Verify if requested
    if (verify) {
        std::cout << "\nVerifying...\n";

        auto lookup_stub = RouteLookup::NewStub(channel);
        grpc::ClientContext stats_context;
        StatsRequest stats_request;
        StatsResponse stats_response;

        auto stats_status = lookup_stub->GetStats(&stats_context, stats_request, &stats_response);
        if (stats_status.ok()) {
            std::cout << "Server reports " << stats_response.total_routes() << " routes\n";
            std::cout << "Server reports " << stats_response.total_vpns() << " VPNs\n";
            std::cout << "Server reports " << stats_response.total_fqdns() << " FQDNs\n";
        }
    }

    return 0;
}
