#include <gtest/gtest.h>
#include "storage/route_store.h"
#include <filesystem>

namespace kepler {
namespace test {

class RouteStoreTest : public ::testing::Test {
protected:
    void SetUp() override {
        // Create temp directory for test DB
        test_dir_ = std::filesystem::temp_directory_path() / "kepler_test";
        std::filesystem::create_directories(test_dir_);

        Config config;
        config.db_path = test_dir_.string();
        config.block_cache_size_mb = 64;

        store_ = std::make_unique<RouteStore>(config);
        ASSERT_TRUE(store_->open());
    }

    void TearDown() override {
        if (store_) {
            store_->close();
            store_.reset();
        }
        std::filesystem::remove_all(test_dir_);
    }

    Route create_test_route(uint32_t vpn, const std::string& fqdn) {
        Route route;
        route.set_vpn(vpn);

        auto* prefix = route.mutable_prefix();
        prefix->set_family(AF_IPV4);
        prefix->set_address(std::string("\x0a\x00\x00\x00", 4));  // 10.0.0.0
        prefix->set_prefix_length(24);

        route.set_nexthop(std::string("\x0a\x00\x00\x01", 4));
        route.set_nexthop_vpn(vpn);
        route.set_discovered_fqdn(fqdn);
        route.set_endpoint_ip(std::string("\xc0\xa8\x01\x01", 4));
        route.set_virtual_ip(std::string("\x64\x40\x00\x01", 4));

        return route;
    }

    std::filesystem::path test_dir_;
    std::unique_ptr<RouteStore> store_;
};

TEST_F(RouteStoreTest, AddAndGetRoute) {
    Route route = create_test_route(1, "test.example.com");

    uint64_t seq;
    ASSERT_TRUE(store_->add_route(route, &seq));
    EXPECT_GT(seq, 0u);

    auto retrieved = store_->get_route_by_prefix(1, route.prefix());
    ASSERT_TRUE(retrieved.has_value());
    EXPECT_EQ(retrieved->vpn(), 1u);
    EXPECT_EQ(retrieved->discovered_fqdn(), "test.example.com");
}

TEST_F(RouteStoreTest, UpdateRoute) {
    Route route = create_test_route(1, "original.example.com");
    ASSERT_TRUE(store_->add_route(route));

    route.set_discovered_fqdn("updated.example.com");
    ASSERT_TRUE(store_->update_route(route));

    auto retrieved = store_->get_route_by_prefix(1, route.prefix());
    ASSERT_TRUE(retrieved.has_value());
    EXPECT_EQ(retrieved->discovered_fqdn(), "updated.example.com");
}

TEST_F(RouteStoreTest, DeleteRoute) {
    Route route = create_test_route(1, "delete.example.com");
    ASSERT_TRUE(store_->add_route(route));

    auto retrieved = store_->get_route_by_prefix(1, route.prefix());
    ASSERT_TRUE(retrieved.has_value());

    ASSERT_TRUE(store_->delete_route_by_prefix(1, route.prefix()));

    retrieved = store_->get_route_by_prefix(1, route.prefix());
    EXPECT_FALSE(retrieved.has_value());
}

TEST_F(RouteStoreTest, GetRoutesByFqdn) {
    Route route1 = create_test_route(1, "shared.example.com");
    Route route2 = create_test_route(2, "shared.example.com");

    // Modify route2 to have different prefix
    route2.mutable_prefix()->set_address(std::string("\x0a\x00\x01\x00", 4));

    ASSERT_TRUE(store_->add_route(route1));
    ASSERT_TRUE(store_->add_route(route2));

    auto routes = store_->get_routes_by_fqdn("shared.example.com");
    EXPECT_EQ(routes.size(), 2u);
}

TEST_F(RouteStoreTest, ListVpns) {
    for (uint32_t vpn = 1; vpn <= 5; ++vpn) {
        Route route = create_test_route(vpn, "test" + std::to_string(vpn) + ".example.com");
        route.mutable_prefix()->set_address(std::string(1, static_cast<char>(10 + vpn)) + "\x00\x00\x00");
        ASSERT_TRUE(store_->add_route(route));
    }

    auto vpns = store_->list_vpns(10);
    EXPECT_EQ(vpns.size(), 5u);
}

TEST_F(RouteStoreTest, ChangelogWorks) {
    Route route = create_test_route(1, "changelog.example.com");

    uint64_t seq;
    ASSERT_TRUE(store_->add_route(route, &seq));

    auto changes = store_->get_changes_since(seq - 1, 10);
    ASSERT_EQ(changes.size(), 1u);
    EXPECT_EQ(changes[0].type(), ChangeType::ADD);
    EXPECT_EQ(changes[0].sequence(), seq);
}

}  // namespace test
}  // namespace kepler
