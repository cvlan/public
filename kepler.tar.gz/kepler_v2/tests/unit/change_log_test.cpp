#include <gtest/gtest.h>
#include "storage/route_store.h"
#include "storage/change_log.h"
#include <filesystem>

namespace kepler {
namespace test {

class ChangeLogTest : public ::testing::Test {
protected:
    void SetUp() override {
        test_dir_ = std::filesystem::temp_directory_path() / "kepler_changelog_test";
        std::filesystem::create_directories(test_dir_);

        Config config;
        config.db_path = test_dir_.string();
        config.block_cache_size_mb = 64;
        config.changelog_retention_hours = 24;
        config.changelog_prune_interval_seconds = 3600;

        config_ = config;
        store_ = std::make_unique<RouteStore>(config);
        ASSERT_TRUE(store_->open());

        changelog_ = std::make_unique<ChangeLog>(*store_, config);
    }

    void TearDown() override {
        changelog_.reset();
        if (store_) {
            store_->close();
            store_.reset();
        }
        std::filesystem::remove_all(test_dir_);
    }

    std::filesystem::path test_dir_;
    Config config_;
    std::unique_ptr<RouteStore> store_;
    std::unique_ptr<ChangeLog> changelog_;
};

TEST_F(ChangeLogTest, GetChangesAfterAdd) {
    Route route;
    route.set_vpn(1);
    auto* prefix = route.mutable_prefix();
    prefix->set_family(AF_IPV4);
    prefix->set_address(std::string("\x0a\x00\x00\x00", 4));
    prefix->set_prefix_length(24);
    route.set_discovered_fqdn("test.example.com");

    uint64_t seq;
    ASSERT_TRUE(store_->add_route(route, &seq));

    auto changes = changelog_->get_changes_since(seq - 1, 10);
    ASSERT_EQ(changes.size(), 1u);
    EXPECT_EQ(changes[0].type(), ChangeType::ADD);
}

TEST_F(ChangeLogTest, SequenceValidity) {
    // Sequence 0 should be valid (means start from current)
    EXPECT_TRUE(changelog_->is_sequence_valid(0));

    // A sequence in the future should be valid (we'll catch up)
    uint64_t current = changelog_->get_current_sequence();
    EXPECT_TRUE(changelog_->is_sequence_valid(current));
}

}  // namespace test
}  // namespace kepler
