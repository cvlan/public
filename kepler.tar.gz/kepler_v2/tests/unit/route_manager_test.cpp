#include <gtest/gtest.h>
#include "core/route_manager.h"
#include "storage/route_store.h"
#include "storage/change_log.h"
#include <filesystem>

namespace kepler {
namespace test {

class RouteManagerTest : public ::testing::Test {
protected:
    void SetUp() override {
        test_dir_ = std::filesystem::temp_directory_path() / "kepler_manager_test";
        std::filesystem::create_directories(test_dir_);

        Config config;
        config.db_path = test_dir_.string();
        config.block_cache_size_mb = 64;

        store_ = std::make_unique<RouteStore>(config);
        ASSERT_TRUE(store_->open());

        changelog_ = std::make_unique<ChangeLog>(*store_, config);
        manager_ = std::make_unique<RouteManager>(*store_, *changelog_);
    }

    void TearDown() override {
        manager_.reset();
        changelog_.reset();
        if (store_) {
            store_->close();
            store_.reset();
        }
        std::filesystem::remove_all(test_dir_);
    }

    Route create_route(uint32_t vpn, uint8_t subnet) {
        Route route;
        route.set_vpn(vpn);

        auto* prefix = route.mutable_prefix();
        prefix->set_family(AF_IPV4);
        prefix->set_address(std::string(1, static_cast<char>(10)) +
                           std::string(1, static_cast<char>(subnet)) +
                           "\x00\x00");
        prefix->set_prefix_length(24);

        route.set_nexthop(std::string("\x0a\x00\x00\x01", 4));
        route.set_nexthop_vpn(vpn);
        route.set_discovered_fqdn("test-" + std::to_string(subnet) + ".example.com");

        return route;
    }

    std::filesystem::path test_dir_;
    std::unique_ptr<RouteStore> store_;
    std::unique_ptr<ChangeLog> changelog_;
    std::unique_ptr<RouteManager> manager_;
};

TEST_F(RouteManagerTest, AddAndRetrieve) {
    Route route = create_route(1, 1);

    uint64_t seq;
    ASSERT_TRUE(manager_->add_route(route, &seq));
    EXPECT_GT(seq, 0u);

    auto retrieved = manager_->get_route_by_prefix(1, route.prefix());
    ASSERT_TRUE(retrieved.has_value());
    EXPECT_EQ(retrieved->vpn(), 1u);
}

TEST_F(RouteManagerTest, UpsertNewRoute) {
    Route route = create_route(1, 2);

    bool was_added;
    ASSERT_TRUE(manager_->upsert_route(route, &was_added));
    EXPECT_TRUE(was_added);
}

TEST_F(RouteManagerTest, UpsertExistingRoute) {
    Route route = create_route(1, 3);
    ASSERT_TRUE(manager_->add_route(route));

    route.set_discovered_fqdn("updated.example.com");
    bool was_added;
    ASSERT_TRUE(manager_->upsert_route(route, &was_added));
    EXPECT_FALSE(was_added);

    auto retrieved = manager_->get_route_by_prefix(1, route.prefix());
    EXPECT_EQ(retrieved->discovered_fqdn(), "updated.example.com");
}

TEST_F(RouteManagerTest, ListFqdns) {
    for (int i = 0; i < 5; ++i) {
        Route route = create_route(1, i + 10);
        ASSERT_TRUE(manager_->add_route(route));
    }

    auto fqdns = manager_->list_fqdns("test-", 10);
    EXPECT_EQ(fqdns.size(), 5u);
}

TEST_F(RouteManagerTest, SyncSession) {
    // Add some initial routes
    for (int i = 0; i < 3; ++i) {
        Route route = create_route(1, i + 20);
        ASSERT_TRUE(manager_->add_route(route));
    }

    EXPECT_EQ(manager_->get_route_count(), 3u);

    // Start sync and add routes (including one new one)
    std::string sync_id = manager_->start_sync();

    for (int i = 0; i < 2; ++i) {
        Route route = create_route(1, i + 20);  // Same as before
        ASSERT_TRUE(manager_->add_route_to_sync(sync_id, route));
    }

    // Complete sync with delete_missing = true should remove the third route
    ASSERT_TRUE(manager_->complete_sync(sync_id, true));

    EXPECT_EQ(manager_->get_route_count(), 2u);
}

}  // namespace test
}  // namespace kepler
