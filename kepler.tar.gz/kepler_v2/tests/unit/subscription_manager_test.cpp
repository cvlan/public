#include <gtest/gtest.h>
#include "core/subscription_manager.h"
#include "core/route_manager.h"
#include "storage/route_store.h"
#include "storage/change_log.h"
#include <filesystem>

namespace kepler {
namespace test {

class SubscriptionManagerTest : public ::testing::Test {
protected:
    void SetUp() override {
        test_dir_ = std::filesystem::temp_directory_path() / "kepler_sub_test";
        std::filesystem::create_directories(test_dir_);

        Config config;
        config.db_path = test_dir_.string();
        config.block_cache_size_mb = 64;

        store_ = std::make_unique<RouteStore>(config);
        ASSERT_TRUE(store_->open());

        changelog_ = std::make_unique<ChangeLog>(*store_, config);
        route_manager_ = std::make_unique<RouteManager>(*store_, *changelog_);
        sub_manager_ = std::make_unique<SubscriptionManager>(*store_, *changelog_);

        route_manager_->set_subscription_manager(sub_manager_.get());
        sub_manager_->set_route_manager(route_manager_.get());
        sub_manager_->start();
    }

    void TearDown() override {
        sub_manager_->stop();
        sub_manager_.reset();
        route_manager_.reset();
        changelog_.reset();
        if (store_) {
            store_->close();
            store_.reset();
        }
        std::filesystem::remove_all(test_dir_);
    }

    std::filesystem::path test_dir_;
    std::unique_ptr<RouteStore> store_;
    std::unique_ptr<ChangeLog> changelog_;
    std::unique_ptr<RouteManager> route_manager_;
    std::unique_ptr<SubscriptionManager> sub_manager_;
};

TEST_F(SubscriptionManagerTest, CreateSubscription) {
    std::vector<SubscriptionFilter> filters;
    SubscriptionFilter filter;
    filter.set_discovered_fqdn("test.example.com");
    filters.push_back(filter);

    std::string sub_id = sub_manager_->subscribe("client-1", filters);
    EXPECT_FALSE(sub_id.empty());

    auto sub = sub_manager_->get_subscription(sub_id);
    ASSERT_NE(sub, nullptr);
    EXPECT_EQ(sub->client_id, "client-1");
    EXPECT_EQ(sub->filters.size(), 1u);
}

TEST_F(SubscriptionManagerTest, Unsubscribe) {
    std::vector<SubscriptionFilter> filters;
    SubscriptionFilter filter;
    filter.set_discovered_fqdn("test.example.com");
    filters.push_back(filter);

    std::string sub_id = sub_manager_->subscribe("client-1", filters);

    EXPECT_TRUE(sub_manager_->unsubscribe(sub_id));

    auto sub = sub_manager_->get_subscription(sub_id);
    EXPECT_EQ(sub, nullptr);
}

TEST_F(SubscriptionManagerTest, ListSubscriptions) {
    std::vector<SubscriptionFilter> filters;
    SubscriptionFilter filter;
    filter.set_discovered_fqdn("test.example.com");
    filters.push_back(filter);

    sub_manager_->subscribe("client-1", filters);
    sub_manager_->subscribe("client-2", filters);

    auto ids = sub_manager_->list_subscription_ids();
    EXPECT_EQ(ids.size(), 2u);
}

TEST_F(SubscriptionManagerTest, SequenceValidity) {
    // Current sequence should be valid
    EXPECT_TRUE(sub_manager_->is_sequence_valid(0));
}

}  // namespace test
}  // namespace kepler
