#pragma once

#include <string>
#include <cstdint>

namespace kepler {

struct Config {
    // gRPC settings
    std::string grpc_address = "0.0.0.0:50051";
    uint32_t grpc_threads = 4;

    // Admin HTTP settings
    std::string admin_address = "0.0.0.0:8080";

    // RocksDB settings
    std::string db_path = "/var/lib/kepler/data";
    uint64_t block_cache_size_mb = 4096;  // 4GB
    uint64_t write_buffer_size_mb = 128;
    int max_write_buffer_number = 4;
    bool enable_compression = true;

    // Changelog settings
    uint64_t changelog_retention_hours = 24;
    uint64_t changelog_prune_interval_seconds = 3600;  // 1 hour

    // Performance settings
    uint32_t batch_size = 1000;
    uint32_t max_concurrent_syncs = 4;

    // Load from environment variables
    static Config from_env();

    // Load from config file
    static Config from_file(const std::string& path);
};

}  // namespace kepler
