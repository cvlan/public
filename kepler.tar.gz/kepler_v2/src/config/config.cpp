#include "config/config.h"
#include <cstdlib>
#include <fstream>
#include <sstream>

namespace kepler {

namespace {

std::string get_env(const char* name, const std::string& default_value) {
    const char* value = std::getenv(name);
    return value ? std::string(value) : default_value;
}

uint64_t get_env_uint64(const char* name, uint64_t default_value) {
    const char* value = std::getenv(name);
    if (!value) return default_value;
    try {
        return std::stoull(value);
    } catch (...) {
        return default_value;
    }
}

uint32_t get_env_uint32(const char* name, uint32_t default_value) {
    return static_cast<uint32_t>(get_env_uint64(name, default_value));
}

bool get_env_bool(const char* name, bool default_value) {
    const char* value = std::getenv(name);
    if (!value) return default_value;
    std::string s(value);
    return s == "1" || s == "true" || s == "yes" || s == "on";
}

}  // namespace

Config Config::from_env() {
    Config config;

    config.grpc_address = get_env("KEPLER_GRPC_ADDRESS", config.grpc_address);
    config.grpc_threads = get_env_uint32("KEPLER_GRPC_THREADS", config.grpc_threads);

    config.admin_address = get_env("KEPLER_ADMIN_ADDRESS", config.admin_address);

    config.db_path = get_env("KEPLER_DB_PATH", config.db_path);
    config.block_cache_size_mb = get_env_uint64("KEPLER_BLOCK_CACHE_MB", config.block_cache_size_mb);
    config.write_buffer_size_mb = get_env_uint64("KEPLER_WRITE_BUFFER_MB", config.write_buffer_size_mb);
    config.max_write_buffer_number = static_cast<int>(get_env_uint32("KEPLER_MAX_WRITE_BUFFERS", config.max_write_buffer_number));
    config.enable_compression = get_env_bool("KEPLER_ENABLE_COMPRESSION", config.enable_compression);

    config.changelog_retention_hours = get_env_uint64("KEPLER_CHANGELOG_RETENTION_HOURS", config.changelog_retention_hours);
    config.changelog_prune_interval_seconds = get_env_uint64("KEPLER_CHANGELOG_PRUNE_INTERVAL", config.changelog_prune_interval_seconds);

    config.batch_size = get_env_uint32("KEPLER_BATCH_SIZE", config.batch_size);
    config.max_concurrent_syncs = get_env_uint32("KEPLER_MAX_CONCURRENT_SYNCS", config.max_concurrent_syncs);

    return config;
}

Config Config::from_file(const std::string& path) {
    Config config = from_env();  // Start with env defaults

    std::ifstream file(path);
    if (!file.is_open()) {
        return config;
    }

    std::string line;
    while (std::getline(file, line)) {
        // Skip comments and empty lines
        if (line.empty() || line[0] == '#') continue;

        auto pos = line.find('=');
        if (pos == std::string::npos) continue;

        std::string key = line.substr(0, pos);
        std::string value = line.substr(pos + 1);

        // Trim whitespace
        while (!key.empty() && (key.back() == ' ' || key.back() == '\t')) key.pop_back();
        while (!value.empty() && (value.front() == ' ' || value.front() == '\t')) value.erase(0, 1);

        if (key == "grpc_address") config.grpc_address = value;
        else if (key == "grpc_threads") config.grpc_threads = std::stoul(value);
        else if (key == "admin_address") config.admin_address = value;
        else if (key == "db_path") config.db_path = value;
        else if (key == "block_cache_size_mb") config.block_cache_size_mb = std::stoull(value);
        else if (key == "write_buffer_size_mb") config.write_buffer_size_mb = std::stoull(value);
        else if (key == "max_write_buffer_number") config.max_write_buffer_number = std::stoi(value);
        else if (key == "enable_compression") config.enable_compression = (value == "true" || value == "1");
        else if (key == "changelog_retention_hours") config.changelog_retention_hours = std::stoull(value);
        else if (key == "batch_size") config.batch_size = std::stoul(value);
        else if (key == "max_concurrent_syncs") config.max_concurrent_syncs = std::stoul(value);
    }

    return config;
}

}  // namespace kepler
