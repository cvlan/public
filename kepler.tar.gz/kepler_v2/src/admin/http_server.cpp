#include "admin/http_server.h"
#include <sstream>

namespace kepler {

AdminHttpServer::AdminHttpServer(const Config& config, RouteManager& route_manager,
                                 Metrics& metrics, std::chrono::steady_clock::time_point start_time)
    : config_(config), route_manager_(route_manager), metrics_(metrics), start_time_(start_time) {
    setup_routes();
}

AdminHttpServer::~AdminHttpServer() {
    stop();
}

void AdminHttpServer::setup_routes() {
    // Health check
    server_.Get("/health", [](const httplib::Request&, httplib::Response& res) {
        res.set_content(R"({"status":"healthy"})", "application/json");
    });

    // Readiness check
    server_.Get("/ready", [this](const httplib::Request&, httplib::Response& res) {
        // Check if we can read from the store
        try {
            route_manager_.get_route_count();
            res.set_content(R"({"status":"ready"})", "application/json");
        } catch (...) {
            res.status = 503;
            res.set_content(R"({"status":"not_ready"})", "application/json");
        }
    });

    // Prometheus metrics
    server_.Get("/metrics", [this](const httplib::Request&, httplib::Response& res) {
        std::ostringstream ss;

        // Uptime
        auto now = std::chrono::steady_clock::now();
        auto uptime = std::chrono::duration_cast<std::chrono::seconds>(now - start_time_);
        ss << "# HELP kepler_uptime_seconds Time since service started\n";
        ss << "# TYPE kepler_uptime_seconds gauge\n";
        ss << "kepler_uptime_seconds " << uptime.count() << "\n\n";

        // Route counts
        ss << "# HELP kepler_routes_total Total number of routes\n";
        ss << "# TYPE kepler_routes_total gauge\n";
        ss << "kepler_routes_total " << route_manager_.get_route_count() << "\n\n";

        ss << "# HELP kepler_vpns_total Total number of distinct VPNs\n";
        ss << "# TYPE kepler_vpns_total gauge\n";
        ss << "kepler_vpns_total " << route_manager_.get_vpn_count() << "\n\n";

        ss << "# HELP kepler_fqdns_total Total number of distinct FQDNs\n";
        ss << "# TYPE kepler_fqdns_total gauge\n";
        ss << "kepler_fqdns_total " << route_manager_.get_fqdn_count() << "\n\n";

        // Changelog
        ss << "# HELP kepler_changelog_sequence Current changelog sequence\n";
        ss << "# TYPE kepler_changelog_sequence gauge\n";
        ss << "kepler_changelog_sequence " << route_manager_.get_current_sequence() << "\n\n";

        ss << "# HELP kepler_changelog_oldest_sequence Oldest sequence in changelog\n";
        ss << "# TYPE kepler_changelog_oldest_sequence gauge\n";
        ss << "kepler_changelog_oldest_sequence " << route_manager_.get_oldest_sequence() << "\n\n";

        // Add custom metrics from Metrics class
        ss << metrics_.get_prometheus_metrics();

        res.set_content(ss.str(), "text/plain; version=0.0.4");
    });

    // Stats endpoint (JSON)
    server_.Get("/stats", [this](const httplib::Request&, httplib::Response& res) {
        auto now = std::chrono::steady_clock::now();
        auto uptime = std::chrono::duration_cast<std::chrono::seconds>(now - start_time_);

        std::ostringstream ss;
        ss << "{\n";
        ss << "  \"uptime_seconds\": " << uptime.count() << ",\n";
        ss << "  \"total_routes\": " << route_manager_.get_route_count() << ",\n";
        ss << "  \"total_vpns\": " << route_manager_.get_vpn_count() << ",\n";
        ss << "  \"total_fqdns\": " << route_manager_.get_fqdn_count() << ",\n";
        ss << "  \"changelog_sequence\": " << route_manager_.get_current_sequence() << ",\n";
        ss << "  \"changelog_oldest\": " << route_manager_.get_oldest_sequence() << "\n";
        ss << "}\n";

        res.set_content(ss.str(), "application/json");
    });
}

void AdminHttpServer::start() {
    if (running_.exchange(true)) return;

    // Parse address and port
    std::string host = "0.0.0.0";
    int port = 8080;

    auto colon_pos = config_.admin_address.find(':');
    if (colon_pos != std::string::npos) {
        host = config_.admin_address.substr(0, colon_pos);
        port = std::stoi(config_.admin_address.substr(colon_pos + 1));
    }

    server_thread_ = std::thread([this, host, port] {
        server_.listen(host.c_str(), port);
    });
}

void AdminHttpServer::stop() {
    if (!running_.exchange(false)) return;

    server_.stop();
    if (server_thread_.joinable()) {
        server_thread_.join();
    }
}

}  // namespace kepler
