#pragma once

#include "config/config.h"
#include "core/route_manager.h"
#include "utils/metrics.h"

#include <httplib.h>
#include <thread>
#include <atomic>
#include <chrono>

namespace kepler {

class AdminHttpServer {
public:
    AdminHttpServer(const Config& config, RouteManager& route_manager, Metrics& metrics,
                    std::chrono::steady_clock::time_point start_time);
    ~AdminHttpServer();

    void start();
    void stop();

private:
    void setup_routes();

    Config config_;
    RouteManager& route_manager_;
    Metrics& metrics_;
    std::chrono::steady_clock::time_point start_time_;

    httplib::Server server_;
    std::thread server_thread_;
    std::atomic<bool> running_{false};
};

}  // namespace kepler
