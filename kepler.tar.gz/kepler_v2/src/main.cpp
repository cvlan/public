#include "config/config.h"
#include "storage/route_store.h"
#include "storage/change_log.h"
#include "core/route_manager.h"
#include "core/subscription_manager.h"
#include "services/ingestion_service.h"
#include "services/lookup_service.h"
#include "services/subscription_service.h"
#include "admin/http_server.h"
#include "utils/metrics.h"

#include <grpcpp/grpcpp.h>
#include <grpcpp/health_check_service_interface.h>

#include <iostream>
#include <csignal>
#include <atomic>
#include <memory>

namespace {
std::atomic<bool> g_shutdown_requested{false};

void signal_handler(int signal) {
    std::cout << "\nReceived signal " << signal << ", shutting down..." << std::endl;
    g_shutdown_requested = true;
}
}  // namespace

// cppcheck-suppress constParameter
int main(int argc, char** argv) {
    // Parse command line arguments
    std::string config_file;
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg.starts_with("--config=")) {
            config_file = arg.substr(9);
        } else if (arg == "--help" || arg == "-h") {
            std::cout << "Usage: kepler [options]\n"
                      << "Options:\n"
                      << "  --config=FILE    Load configuration from file\n"
                      << "  --help, -h       Show this help message\n"
                      << "\nEnvironment variables:\n"
                      << "  KEPLER_GRPC_ADDRESS       gRPC listen address (default: 0.0.0.0:50051)\n"
                      << "  KEPLER_ADMIN_ADDRESS      Admin HTTP listen address (default: 0.0.0.0:8080)\n"
                      << "  KEPLER_DB_PATH            RocksDB data directory (default: /var/lib/kepler/data)\n"
                      << "  KEPLER_BLOCK_CACHE_MB     Block cache size in MB (default: 4096)\n"
                      << "  KEPLER_CHANGELOG_RETENTION_HOURS  Changelog retention (default: 24)\n";
            return 0;
        }
    }

    // Load configuration
    kepler::Config config;
    if (!config_file.empty()) {
        config = kepler::Config::from_file(config_file);
    } else {
        config = kepler::Config::from_env();
    }

    std::cout << "Starting Kepler Routing Engine..." << std::endl;
    std::cout << "  gRPC address: " << config.grpc_address << std::endl;
    std::cout << "  Admin address: " << config.admin_address << std::endl;
    std::cout << "  Database path: " << config.db_path << std::endl;

    // Set up signal handlers
    std::signal(SIGINT, signal_handler);
    std::signal(SIGTERM, signal_handler);

    // Record start time
    auto start_time = std::chrono::steady_clock::now();

    // Initialize components
    kepler::Metrics metrics;

    // Open database
    kepler::RouteStore store(config);
    if (!store.open()) {
        std::cerr << "Failed to open database at " << config.db_path << std::endl;
        return 1;
    }
    std::cout << "Database opened successfully" << std::endl;

    // Create changelog manager
    kepler::ChangeLog changelog(store, config);
    changelog.start();

    // Create route manager
    kepler::RouteManager route_manager(store, changelog);

    // Create subscription manager
    kepler::SubscriptionManager subscription_manager(store, changelog);
    subscription_manager.set_route_manager(&route_manager);
    subscription_manager.start();

    // Link route manager to subscription manager
    route_manager.set_subscription_manager(&subscription_manager);

    // Create gRPC services
    kepler::IngestionServiceImpl ingestion_service(route_manager);
    kepler::LookupServiceImpl lookup_service(route_manager, start_time);
    kepler::SubscriptionServiceImpl subscription_service(subscription_manager);

    // Build and start gRPC server
    grpc::EnableDefaultHealthCheckService(true);

    grpc::ServerBuilder builder;
    builder.AddListeningPort(config.grpc_address, grpc::InsecureServerCredentials());
    builder.RegisterService(&ingestion_service);
    builder.RegisterService(&lookup_service);
    builder.RegisterService(&subscription_service);

    // Set resource limits
    builder.SetMaxReceiveMessageSize(64 * 1024 * 1024);  // 64MB
    builder.SetMaxSendMessageSize(64 * 1024 * 1024);      // 64MB

    // Configure thread pool for sync server
    // - Low MIN_POLLERS keeps idle CPU low
    // - Higher MAX_POLLERS allows scaling under load (need at least 1 per streaming client)
    builder.SetSyncServerOption(grpc::ServerBuilder::SyncServerOption::NUM_CQS, 8);
    builder.SetSyncServerOption(grpc::ServerBuilder::SyncServerOption::MIN_POLLERS, 2);
    builder.SetSyncServerOption(grpc::ServerBuilder::SyncServerOption::MAX_POLLERS, 32);
    builder.SetSyncServerOption(grpc::ServerBuilder::SyncServerOption::CQ_TIMEOUT_MSEC, 1000);

    std::unique_ptr<grpc::Server> grpc_server(builder.BuildAndStart());
    if (!grpc_server) {
        std::cerr << "Failed to start gRPC server on " << config.grpc_address << std::endl;
        return 1;
    }
    std::cout << "gRPC server listening on " << config.grpc_address << std::endl;

    // Start admin HTTP server
    kepler::AdminHttpServer admin_server(config, route_manager, metrics, start_time);
    admin_server.start();
    std::cout << "Admin HTTP server listening on " << config.admin_address << std::endl;

    std::cout << "Kepler is ready to accept connections" << std::endl;

    // Wait for shutdown signal
    while (!g_shutdown_requested) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }

    std::cout << "Shutting down..." << std::endl;

    // Graceful shutdown
    admin_server.stop();
    grpc_server->Shutdown();
    subscription_manager.stop();
    changelog.stop();
    store.close();

    std::cout << "Shutdown complete" << std::endl;
    return 0;
}
