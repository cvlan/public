#pragma once

#include "storage/route_store.h"
#include "storage/change_log.h"
#include "kepler.pb.h"

#include <thread>

#include <array>
#include <functional>
#include <mutex>
#include <shared_mutex>
#include <unordered_map>
#include <unordered_set>
#include <atomic>
#include <condition_variable>
#include <queue>
#include <memory>

namespace kepler {

class RouteManager;

// Pre-serialized change for efficient multi-subscriber delivery
struct SerializedChange {
    RouteChange change;           // Original for filtering
    std::string serialized_data;  // Pre-serialized StreamResponse bytes
};

// Subscription info
struct Subscription {
    std::string subscription_id;
    std::string client_id;
    std::vector<SubscriptionFilter> filters;
    std::atomic<bool> active{true};

    // Stream state
    std::mutex stream_mutex;
    std::condition_variable stream_cv;
    std::queue<std::shared_ptr<SerializedChange>> pending_changes;
    bool stream_connected{false};
};

// Manages subscriptions and routes changes to subscribers
class SubscriptionManager {
public:
    SubscriptionManager(RouteStore& store, ChangeLog& changelog);
    ~SubscriptionManager();

    void set_route_manager(RouteManager* mgr) { route_manager_ = mgr; }

    // Start/stop background threads
    void start();
    void stop();

    // Subscription management
    std::string subscribe(const std::string& client_id, const std::vector<SubscriptionFilter>& filters);
    bool unsubscribe(const std::string& subscription_id);
    std::shared_ptr<Subscription> get_subscription(const std::string& subscription_id);
    std::vector<std::string> list_subscription_ids();

    // Called by RouteManager when routes change
    void notify_change(const RouteChange& change);

    // Stream operations (called by gRPC service)
    bool connect_stream(const std::string& subscription_id);
    void disconnect_stream(const std::string& subscription_id);

    // Get next change for a subscription (blocks if none available)
    // Returns nullptr if subscription was cancelled or timeout
    std::shared_ptr<SerializedChange> wait_for_change(
        const std::string& subscription_id,
        std::chrono::milliseconds timeout = std::chrono::milliseconds(1000));

    // Full sync support
    void start_full_sync(const std::string& subscription_id,
                         std::function<bool(const Route&)> route_callback);

    // Check if sequence is valid for resumption
    bool is_sequence_valid(uint64_t sequence);

    // Get changes since sequence for a subscription
    std::vector<RouteChange> get_filtered_changes_since(
        const std::string& subscription_id,
        uint64_t sequence,
        uint32_t limit = 1000);

private:
    // Check if a route matches subscription filters
    bool matches_filters(const Route& route, const std::vector<SubscriptionFilter>& filters);

    // Generate subscription ID
    static std::string generate_id();

    // Load subscriptions from persistent storage
    void load_subscriptions();

    RouteStore& store_;
    ChangeLog& changelog_;
    RouteManager* route_manager_ = nullptr;

    mutable std::shared_mutex subscriptions_mutex_;
    std::unordered_map<std::string, std::shared_ptr<Subscription>> subscriptions_;

    std::atomic<bool> running_{false};
    std::atomic<size_t> connected_count_{0};  // Fast check for skip optimization

    // 2 worker threads with hash-based subscriber distribution
    static constexpr size_t NUM_WORKERS = 2;

    struct WorkerQueue {
        std::mutex mutex;
        std::condition_variable cv;
        std::queue<std::pair<std::shared_ptr<Subscription>, std::shared_ptr<SerializedChange>>> items;
    };

    std::array<WorkerQueue, NUM_WORKERS> worker_queues_;
    std::array<std::thread, NUM_WORKERS> worker_threads_;

    void notification_worker(size_t worker_id);
    size_t get_worker_for_sub(const std::string& subscription_id);
};

}  // namespace kepler
