#pragma once

#include "storage/route_store.h"
#include "storage/change_log.h"
#include <functional>
#include <mutex>
#include <vector>

namespace kepler {

class SubscriptionManager;

// Route manager - business logic layer
class RouteManager {
public:
    RouteManager(RouteStore& store, ChangeLog& changelog);

    void set_subscription_manager(SubscriptionManager* sub_mgr) { subscription_manager_ = sub_mgr; }

    // Route operations
    bool add_route(const Route& route, uint64_t* sequence = nullptr);
    bool update_route(const Route& route, uint64_t* sequence = nullptr);
    bool delete_route(const std::string& route_id, uint64_t* sequence = nullptr);
    bool delete_route_by_prefix(uint32_t vpn, const Prefix& prefix, uint64_t* sequence = nullptr);

    // Batch operations - uses RocksDB WriteBatch for efficiency
    struct BatchResult {
        uint64_t added = 0;
        uint64_t updated = 0;
        uint64_t deleted = 0;
        uint64_t failed = 0;
    };
    BatchResult batch_ingest(const std::vector<std::pair<Route, ChangeType>>& updates);

    // Upsert for sync operations
    bool upsert_route(const Route& route, bool* was_added = nullptr, uint64_t* sequence = nullptr);

    // Sync session management
    std::string start_sync(const std::string& sync_id = "");
    bool add_route_to_sync(const std::string& sync_id, const Route& route);
    bool complete_sync(const std::string& sync_id, bool delete_missing);

    // Lookup operations
    std::optional<Route> get_route(const std::string& route_id);
    std::optional<Route> get_route_by_prefix(uint32_t vpn, const Prefix& prefix);
    std::vector<Route> get_routes_by_fqdn(const std::string& fqdn, uint32_t limit = 0);
    std::vector<Route> get_routes_by_endpoint(const std::string& endpoint_ip, uint32_t limit = 0);
    std::vector<Route> get_routes_by_virtual_ip(const std::string& virtual_ip, uint32_t limit = 0);
    std::vector<Route> get_routes_by_vpn(uint32_t vpn, uint32_t limit = 0);

    // List operations
    std::vector<std::string> list_fqdns(const std::string& prefix = "", uint32_t limit = 1000, uint32_t offset = 0);
    std::vector<uint32_t> list_vpns(uint32_t limit = 1000, uint32_t offset = 0);

    // Statistics
    uint64_t get_route_count();
    uint64_t get_fqdn_count();
    uint64_t get_vpn_count();
    uint64_t get_current_sequence();
    uint64_t get_oldest_sequence();

    // Iterate routes (for full sync to client)
    void iterate_routes(std::function<bool(const Route&)> callback);
    void iterate_routes_by_filter(const SubscriptionFilter& filter, std::function<bool(const Route&)> callback);

private:
    void notify_change(const RouteChange& change);

    RouteStore& store_;
    ChangeLog& changelog_;
    SubscriptionManager* subscription_manager_ = nullptr;

    std::mutex sync_mutex_;
    std::unordered_map<std::string, std::shared_ptr<RouteStore::SyncSession>> sync_sessions_;
};

}  // namespace kepler
