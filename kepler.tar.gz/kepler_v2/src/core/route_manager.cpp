#include "core/route_manager.h"
#include "core/subscription_manager.h"

namespace kepler {

RouteManager::RouteManager(RouteStore& store, ChangeLog& changelog)
    : store_(store), changelog_(changelog) {}

bool RouteManager::add_route(const Route& route, uint64_t* sequence) {
    uint64_t seq;
    bool ok = store_.add_route(route, &seq);
    if (ok) {
        if (sequence) *sequence = seq;
        // Notify subscribers
        auto changes = changelog_.get_changes_since(seq - 1, 1);
        if (!changes.empty()) {
            notify_change(changes[0]);
        }
    }
    return ok;
}

bool RouteManager::update_route(const Route& route, uint64_t* sequence) {
    uint64_t seq;
    bool ok = store_.update_route(route, &seq);
    if (ok) {
        if (sequence) *sequence = seq;
        auto changes = changelog_.get_changes_since(seq - 1, 1);
        if (!changes.empty()) {
            notify_change(changes[0]);
        }
    }
    return ok;
}

bool RouteManager::delete_route(const std::string& route_id, uint64_t* sequence) {
    uint64_t seq;
    bool ok = store_.delete_route(route_id, &seq);
    if (ok) {
        if (sequence) *sequence = seq;
        auto changes = changelog_.get_changes_since(seq - 1, 1);
        if (!changes.empty()) {
            notify_change(changes[0]);
        }
    }
    return ok;
}

bool RouteManager::delete_route_by_prefix(uint32_t vpn, const Prefix& prefix, uint64_t* sequence) {
    uint64_t seq;
    bool ok = store_.delete_route_by_prefix(vpn, prefix, &seq);
    if (ok) {
        if (sequence) *sequence = seq;
        auto changes = changelog_.get_changes_since(seq - 1, 1);
        if (!changes.empty()) {
            notify_change(changes[0]);
        }
    }
    return ok;
}

RouteManager::BatchResult RouteManager::batch_ingest(const std::vector<std::pair<Route, ChangeType>>& updates) {
    BatchResult result;
    if (updates.empty()) return result;

    // Use efficient batch upsert in RouteStore
    auto store_result = store_.batch_upsert(updates);

    result.added = store_result.added;
    result.updated = store_result.updated;
    result.deleted = store_result.deleted;
    result.failed = store_result.failed;

    // Notify subscribers of all changes (using changes returned directly, no DB re-read)
    if (subscription_manager_) {
        for (const auto& change : store_result.changes) {
            notify_change(change);
        }
    }

    return result;
}

bool RouteManager::upsert_route(const Route& route, bool* was_added, uint64_t* sequence) {
    uint64_t seq;
    bool added;
    bool ok = store_.upsert_route(route, &added, &seq);
    if (ok) {
        if (was_added) *was_added = added;
        if (sequence) *sequence = seq;
        auto changes = changelog_.get_changes_since(seq - 1, 1);
        if (!changes.empty()) {
            notify_change(changes[0]);
        }
    }
    return ok;
}

std::string RouteManager::start_sync(const std::string& sync_id) {
    auto session = store_.start_sync(sync_id);
    std::lock_guard<std::mutex> lock(sync_mutex_);
    sync_sessions_[session->sync_id] = session;
    return session->sync_id;
}

bool RouteManager::add_route_to_sync(const std::string& sync_id, const Route& route) {
    std::shared_ptr<RouteStore::SyncSession> session;
    {
        std::lock_guard<std::mutex> lock(sync_mutex_);
        auto it = sync_sessions_.find(sync_id);
        if (it == sync_sessions_.end()) return false;
        session = it->second;
    }

    // Upsert the route
    bool was_added;
    uint64_t seq;
    bool ok = store_.upsert_route(route, &was_added, &seq);

    if (ok) {
        // Track that we've seen this route
        auto existing = store_.get_route_by_prefix(route.vpn(), route.prefix());
        if (existing) {
            session->seen_route_ids.insert(existing->route_id());
        }
        session->routes_processed++;

        // Only notify if there was an actual change
        if (was_added) {
            auto changes = changelog_.get_changes_since(seq - 1, 1);
            if (!changes.empty()) {
                notify_change(changes[0]);
            }
        } else {
            // Check if update actually changed anything
            auto changes = changelog_.get_changes_since(seq - 1, 1);
            if (!changes.empty() && changes[0].type() == ChangeType::UPDATE) {
                notify_change(changes[0]);
            }
        }
    }

    return ok;
}

bool RouteManager::complete_sync(const std::string& sync_id, bool delete_missing) {
    std::shared_ptr<RouteStore::SyncSession> session;
    {
        std::lock_guard<std::mutex> lock(sync_mutex_);
        auto it = sync_sessions_.find(sync_id);
        if (it == sync_sessions_.end()) return false;
        session = it->second;
        sync_sessions_.erase(it);
    }

    if (delete_missing) {
        // Find routes not seen during sync and delete them
        std::vector<Route> to_delete;
        store_.iterate_routes([&](const Route& route) {
            if (session->seen_route_ids.find(route.route_id()) == session->seen_route_ids.end()) {
                to_delete.push_back(route);
            }
            return true;
        });

        for (const auto& route : to_delete) {
            uint64_t seq;
            if (store_.delete_route(route.route_id(), &seq)) {
                auto changes = changelog_.get_changes_since(seq - 1, 1);
                if (!changes.empty()) {
                    notify_change(changes[0]);
                }
            }
        }
    }

    return store_.complete_sync(session, false);  // We already handled deletes
}

std::optional<Route> RouteManager::get_route(const std::string& route_id) {
    return store_.get_route(route_id);
}

std::optional<Route> RouteManager::get_route_by_prefix(uint32_t vpn, const Prefix& prefix) {
    return store_.get_route_by_prefix(vpn, prefix);
}

std::vector<Route> RouteManager::get_routes_by_fqdn(const std::string& fqdn, uint32_t limit) {
    return store_.get_routes_by_fqdn(fqdn, limit);
}

std::vector<Route> RouteManager::get_routes_by_endpoint(const std::string& endpoint_ip, uint32_t limit) {
    return store_.get_routes_by_endpoint(endpoint_ip, limit);
}

std::vector<Route> RouteManager::get_routes_by_virtual_ip(const std::string& virtual_ip, uint32_t limit) {
    return store_.get_routes_by_virtual_ip(virtual_ip, limit);
}

std::vector<Route> RouteManager::get_routes_by_vpn(uint32_t vpn, uint32_t limit) {
    return store_.get_routes_by_vpn(vpn, limit);
}

std::vector<std::string> RouteManager::list_fqdns(const std::string& prefix, uint32_t limit, uint32_t offset) {
    return store_.list_fqdns(prefix, limit, offset);
}

std::vector<uint32_t> RouteManager::list_vpns(uint32_t limit, uint32_t offset) {
    return store_.list_vpns(limit, offset);
}

uint64_t RouteManager::get_route_count() {
    return store_.get_route_count();
}

uint64_t RouteManager::get_fqdn_count() {
    return store_.get_fqdn_count();
}

uint64_t RouteManager::get_vpn_count() {
    return store_.get_vpn_count();
}

uint64_t RouteManager::get_current_sequence() {
    return changelog_.get_current_sequence();
}

uint64_t RouteManager::get_oldest_sequence() {
    return changelog_.get_oldest_sequence();
}

void RouteManager::iterate_routes(std::function<bool(const Route&)> callback) {
    store_.iterate_routes(callback);
}

void RouteManager::iterate_routes_by_filter(const SubscriptionFilter& filter, std::function<bool(const Route&)> callback) {
    store_.iterate_routes_by_filter(filter, callback);
}

void RouteManager::notify_change(const RouteChange& change) {
    if (subscription_manager_) {
        subscription_manager_->notify_change(change);
    }
}

}  // namespace kepler
