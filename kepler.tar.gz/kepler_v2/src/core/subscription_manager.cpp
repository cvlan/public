#include "core/subscription_manager.h"
#include "core/route_manager.h"

#include <random>
#include <sstream>
#include <iomanip>
#include <chrono>

namespace kepler {

namespace {

std::string generate_uuid() {
    static thread_local std::mt19937_64 gen(
        std::chrono::high_resolution_clock::now().time_since_epoch().count() ^
        reinterpret_cast<uint64_t>(&gen)
    );

    std::uniform_int_distribution<uint64_t> dist;
    uint64_t a = dist(gen);
    uint64_t b = dist(gen);

    a = (a & 0xFFFFFFFFFFFF0FFFULL) | 0x0000000000004000ULL;
    b = (b & 0x3FFFFFFFFFFFFFFFULL) | 0x8000000000000000ULL;

    std::ostringstream ss;
    ss << std::hex << std::setfill('0');
    ss << std::setw(8) << (a >> 32);
    ss << '-';
    ss << std::setw(4) << ((a >> 16) & 0xFFFF);
    ss << '-';
    ss << std::setw(4) << (a & 0xFFFF);
    ss << '-';
    ss << std::setw(4) << (b >> 48);
    ss << '-';
    ss << std::setw(12) << (b & 0xFFFFFFFFFFFFULL);

    return ss.str();
}

std::string bytes_to_hex(const std::string& bytes) {
    std::ostringstream ss;
    ss << std::hex << std::setfill('0');
    for (unsigned char c : bytes) {
        ss << std::setw(2) << static_cast<int>(c);
    }
    return ss.str();
}

}  // namespace

SubscriptionManager::SubscriptionManager(RouteStore& store, ChangeLog& changelog)
    : store_(store), changelog_(changelog) {}

SubscriptionManager::~SubscriptionManager() {
    stop();
}

void SubscriptionManager::start() {
    if (running_.exchange(true)) return;
    load_subscriptions();

    // Start worker threads
    for (size_t i = 0; i < NUM_WORKERS; ++i) {
        worker_threads_[i] = std::thread(&SubscriptionManager::notification_worker, this, i);
    }
}

void SubscriptionManager::stop() {
    if (!running_.exchange(false)) return;

    // Wake up worker threads
    for (auto& wq : worker_queues_) {
        wq.cv.notify_all();
    }

    // Join worker threads
    for (auto& t : worker_threads_) {
        if (t.joinable()) {
            t.join();
        }
    }

    // Wake up all waiting streams
    std::shared_lock<std::shared_mutex> lock(subscriptions_mutex_);
    // cppcheck-suppress unusedVariable
    for (auto& [_, sub] : subscriptions_) {
        sub->active = false;
        sub->stream_cv.notify_all();
    }
}

void SubscriptionManager::load_subscriptions() {
    auto subs = store_.list_subscriptions();
    std::unique_lock<std::shared_mutex> lock(subscriptions_mutex_);

    // cppcheck-suppress unassignedVariable
    for (auto& [id, request] : subs) {
        auto sub = std::make_shared<Subscription>();
        sub->subscription_id = id;
        sub->client_id = request.client_id();
        for (const auto& f : request.filters()) {
            sub->filters.push_back(f);
        }
        subscriptions_[id] = sub;
    }
}

std::string SubscriptionManager::generate_id() {
    return "sub-" + generate_uuid();
}

std::string SubscriptionManager::subscribe(const std::string& client_id,
                                           const std::vector<SubscriptionFilter>& filters) {
    auto sub = std::make_shared<Subscription>();
    sub->subscription_id = generate_id();
    sub->client_id = client_id;
    sub->filters = filters;

    // Persist subscription
    SubscribeRequest request;
    request.set_client_id(client_id);
    for (const auto& f : filters) {
        *request.add_filters() = f;
    }
    store_.save_subscription(sub->subscription_id, request);

    // Add to in-memory map
    {
        std::unique_lock<std::shared_mutex> lock(subscriptions_mutex_);
        subscriptions_[sub->subscription_id] = sub;
    }

    return sub->subscription_id;
}

bool SubscriptionManager::unsubscribe(const std::string& subscription_id) {
    std::shared_ptr<Subscription> sub;

    {
        std::unique_lock<std::shared_mutex> lock(subscriptions_mutex_);
        auto it = subscriptions_.find(subscription_id);
        if (it == subscriptions_.end()) return false;
        sub = it->second;
        subscriptions_.erase(it);
    }

    // Mark as inactive and wake up any waiting threads
    sub->active = false;
    sub->stream_cv.notify_all();

    // Remove from persistent storage
    store_.delete_subscription(subscription_id);

    return true;
}

std::shared_ptr<Subscription> SubscriptionManager::get_subscription(const std::string& subscription_id) {
    std::shared_lock<std::shared_mutex> lock(subscriptions_mutex_);
    auto it = subscriptions_.find(subscription_id);
    if (it == subscriptions_.end()) return nullptr;
    return it->second;
}

std::vector<std::string> SubscriptionManager::list_subscription_ids() {
    std::shared_lock<std::shared_mutex> lock(subscriptions_mutex_);
    std::vector<std::string> ids;
    ids.reserve(subscriptions_.size());
    for (const auto& [id, _] : subscriptions_) {
        ids.push_back(id);
    }
    return ids;
}

bool SubscriptionManager::matches_filters(const Route& route,
                                          const std::vector<SubscriptionFilter>& filters) {
    if (filters.empty()) return true;

    for (const auto& filter : filters) {
        switch (filter.filter_case()) {
            case SubscriptionFilter::kDiscoveredFqdn:
                if (route.discovered_fqdn() == filter.discovered_fqdn()) return true;
                break;
            case SubscriptionFilter::kEndpointIp:
                if (route.endpoint_ip() == filter.endpoint_ip()) return true;
                break;
            case SubscriptionFilter::kVirtualIp:
                if (route.virtual_ip() == filter.virtual_ip()) return true;
                break;
            case SubscriptionFilter::kVpn:
                if (route.vpn() == filter.vpn()) return true;
                break;
            default:
                break;
        }
    }

    return false;
}

size_t SubscriptionManager::get_worker_for_sub(const std::string& subscription_id) {
    return std::hash<std::string>{}(subscription_id) % NUM_WORKERS;
}

void SubscriptionManager::notify_change(const RouteChange& change) {
    // Fast path: skip if no connected subscribers (e.g., during preload)
    if (connected_count_.load(std::memory_order_relaxed) == 0) {
        return;
    }

    // Create shared change once
    auto sc = std::make_shared<SerializedChange>();
    sc->change = change;

    // Get connected matching subscribers
    std::shared_lock<std::shared_mutex> lock(subscriptions_mutex_);
    std::vector<std::shared_ptr<Subscription>> matching_subs;

    // cppcheck-suppress unusedVariable
    for (auto& [_, sub] : subscriptions_) {
        if (!sub->active || !sub->stream_connected) continue;
        if (matches_filters(change.route(), sub->filters)) {
            matching_subs.push_back(sub);
        }
    }
    lock.unlock();

    // Dispatch to worker queues based on subscription hash
    for (auto& sub : matching_subs) {
        size_t worker_id = get_worker_for_sub(sub->subscription_id);
        auto& wq = worker_queues_[worker_id];

        {
            std::lock_guard<std::mutex> lk(wq.mutex);
            wq.items.emplace(sub, sc);
        }
        wq.cv.notify_one();
    }
}

void SubscriptionManager::notification_worker(size_t worker_id) {
    auto& wq = worker_queues_[worker_id];

    while (running_) {
        std::vector<std::pair<std::shared_ptr<Subscription>, std::shared_ptr<SerializedChange>>> batch;

        // Drain queue
        {
            std::unique_lock<std::mutex> lock(wq.mutex);
            wq.cv.wait(lock, [&] {
                return !wq.items.empty() || !running_;
            });

            if (!running_ && wq.items.empty()) {
                break;
            }

            // Drain all available items
            while (!wq.items.empty()) {
                batch.push_back(std::move(wq.items.front()));
                wq.items.pop();
            }
        }

        // Push to subscriber queues
        for (auto& [sub, sc] : batch) {
            if (!sub->active) continue;
            std::lock_guard<std::mutex> stream_lock(sub->stream_mutex);
            sub->pending_changes.push(sc);
            sub->stream_cv.notify_one();
        }
    }
}

bool SubscriptionManager::connect_stream(const std::string& subscription_id) {
    auto sub = get_subscription(subscription_id);
    if (!sub) return false;

    std::lock_guard<std::mutex> lock(sub->stream_mutex);
    if (!sub->stream_connected) {
        sub->stream_connected = true;
        connected_count_.fetch_add(1, std::memory_order_relaxed);
    }
    return true;
}

void SubscriptionManager::disconnect_stream(const std::string& subscription_id) {
    auto sub = get_subscription(subscription_id);
    if (!sub) return;

    std::lock_guard<std::mutex> lock(sub->stream_mutex);
    if (sub->stream_connected) {
        sub->stream_connected = false;
        connected_count_.fetch_sub(1, std::memory_order_relaxed);
    }
}

std::shared_ptr<SerializedChange> SubscriptionManager::wait_for_change(
    const std::string& subscription_id,
    std::chrono::milliseconds timeout) {

    auto sub = get_subscription(subscription_id);
    if (!sub || !sub->active) return nullptr;

    std::unique_lock<std::mutex> lock(sub->stream_mutex);

    if (sub->pending_changes.empty()) {
        sub->stream_cv.wait_for(lock, timeout, [&] {
            return !sub->pending_changes.empty() || !sub->active;
        });
    }

    if (!sub->active) return nullptr;

    if (!sub->pending_changes.empty()) {
        auto sc = sub->pending_changes.front();
        sub->pending_changes.pop();
        return sc;
    }

    return nullptr;  // Timeout
}

void SubscriptionManager::start_full_sync(const std::string& subscription_id,
                                          std::function<bool(const Route&)> route_callback) {
    auto sub = get_subscription(subscription_id);
    if (!sub || !route_manager_) return;

    // Iterate routes matching filters
    for (const auto& filter : sub->filters) {
        route_manager_->iterate_routes_by_filter(filter, [&](const Route& route) {
            if (!sub->active) return false;
            return route_callback(route);
        });
    }

    // If no filters, send all routes
    if (sub->filters.empty()) {
        route_manager_->iterate_routes([&](const Route& route) {
            if (!sub->active) return false;
            return route_callback(route);
        });
    }
}

bool SubscriptionManager::is_sequence_valid(uint64_t sequence) {
    return changelog_.is_sequence_valid(sequence);
}

std::vector<RouteChange> SubscriptionManager::get_filtered_changes_since(
    const std::string& subscription_id,
    uint64_t sequence,
    uint32_t limit) {

    auto sub = get_subscription(subscription_id);
    if (!sub) return {};

    auto all_changes = changelog_.get_changes_since(sequence, 0);  // Get all
    std::vector<RouteChange> filtered;

    for (const auto& change : all_changes) {
        if (matches_filters(change.route(), sub->filters)) {
            filtered.push_back(change);
            if (limit > 0 && filtered.size() >= limit) break;
        }
    }

    return filtered;
}

}  // namespace kepler
