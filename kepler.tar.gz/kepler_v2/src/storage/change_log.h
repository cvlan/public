#pragma once

#include "storage/route_store.h"
#include <functional>
#include <atomic>
#include <thread>
#include <mutex>
#include <condition_variable>

namespace kepler {

// Change log manager - wraps RouteStore changelog operations
// and provides background pruning
class ChangeLog {
public:
    explicit ChangeLog(RouteStore& store, const Config& config);
    ~ChangeLog();

    // Start background pruning thread
    void start();
    void stop();

    // Get changes since sequence
    std::vector<RouteChange> get_changes_since(uint64_t sequence, uint32_t limit = 1000);

    // Check if sequence is within retention window
    bool is_sequence_valid(uint64_t sequence);

    // Get sequence info
    uint64_t get_current_sequence() const { return store_.get_current_sequence(); }
    uint64_t get_oldest_sequence() { return store_.get_oldest_sequence(); }

    // Manual prune
    void prune_now();

private:
    void prune_loop();

    RouteStore& store_;
    Config config_;

    std::atomic<bool> running_{false};
    std::thread prune_thread_;
    std::mutex mutex_;
    std::condition_variable cv_;
};

}  // namespace kepler
