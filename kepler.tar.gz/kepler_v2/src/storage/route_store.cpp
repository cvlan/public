#include "storage/route_store.h"

#include <rocksdb/table.h>
#include <rocksdb/filter_policy.h>
#include <rocksdb/cache.h>
#include <rocksdb/slice_transform.h>

#include <chrono>
#include <iomanip>
#include <sstream>
#include <algorithm>
#include <random>

namespace kepler {

namespace {

// Generate UUID v4
std::string generate_uuid() {
    static thread_local std::mt19937_64 gen(
        std::chrono::high_resolution_clock::now().time_since_epoch().count() ^
        reinterpret_cast<uint64_t>(&gen)
    );

    std::uniform_int_distribution<uint64_t> dist;
    uint64_t a = dist(gen);
    uint64_t b = dist(gen);

    // Set version (4) and variant bits
    a = (a & 0xFFFFFFFFFFFF0FFFULL) | 0x0000000000004000ULL;
    b = (b & 0x3FFFFFFFFFFFFFFFULL) | 0x8000000000000000ULL;

    std::ostringstream ss;
    ss << std::hex << std::setfill('0');
    ss << std::setw(8) << (a >> 32);
    ss << '-';
    ss << std::setw(4) << ((a >> 16) & 0xFFFF);
    ss << '-';
    ss << std::setw(4) << (a & 0xFFFF);
    ss << '-';
    ss << std::setw(4) << (b >> 48);
    ss << '-';
    ss << std::setw(12) << (b & 0xFFFFFFFFFFFFULL);

    return ss.str();
}

int64_t now_micros() {
    return std::chrono::duration_cast<std::chrono::microseconds>(
        std::chrono::system_clock::now().time_since_epoch()
    ).count();
}

}  // namespace

RouteStore::RouteStore(const Config& config) : config_(config) {}

RouteStore::~RouteStore() {
    close();
}

bool RouteStore::open() {
    rocksdb::Options options;
    options.create_if_missing = true;
    options.create_missing_column_families = true;

    // Performance tuning
    options.write_buffer_size = config_.write_buffer_size_mb * 1024 * 1024;
    options.max_write_buffer_number = config_.max_write_buffer_number;
    options.target_file_size_base = 64 * 1024 * 1024;  // 64MB
    options.max_background_jobs = 2;  // Limit CPU usage

    // Block cache
    auto cache = rocksdb::NewLRUCache(config_.block_cache_size_mb * 1024 * 1024);

    rocksdb::BlockBasedTableOptions table_options;
    table_options.block_cache = cache;
    table_options.filter_policy.reset(rocksdb::NewBloomFilterPolicy(10, false));
    table_options.block_size = 16 * 1024;  // 16KB blocks
    options.table_factory.reset(rocksdb::NewBlockBasedTableFactory(table_options));

    // Compression
    if (config_.enable_compression) {
        options.compression = rocksdb::kLZ4Compression;
    }

    // Column family options
    rocksdb::ColumnFamilyOptions cf_options(options);
    cf_options.write_buffer_size = options.write_buffer_size;

    // Define column families
    std::vector<rocksdb::ColumnFamilyDescriptor> cf_descriptors = {
        rocksdb::ColumnFamilyDescriptor(rocksdb::kDefaultColumnFamilyName, cf_options),
        rocksdb::ColumnFamilyDescriptor(CF_ROUTES, cf_options),
        rocksdb::ColumnFamilyDescriptor(CF_BY_FQDN, cf_options),
        rocksdb::ColumnFamilyDescriptor(CF_BY_ENDPOINT, cf_options),
        rocksdb::ColumnFamilyDescriptor(CF_BY_VIRTUAL_IP, cf_options),
        rocksdb::ColumnFamilyDescriptor(CF_BY_VPN, cf_options),
        rocksdb::ColumnFamilyDescriptor(CF_CHANGELOG, cf_options),
        rocksdb::ColumnFamilyDescriptor(CF_SUBSCRIPTIONS, cf_options),
        rocksdb::ColumnFamilyDescriptor(CF_METADATA, cf_options),
    };

    rocksdb::DB* db_raw;
    auto status = rocksdb::DB::Open(options, config_.db_path, cf_descriptors, &cf_handles_, &db_raw);

    if (!status.ok()) {
        // Try creating the DB if it doesn't exist
        if (status.IsInvalidArgument()) {
            // DB exists but column families don't match - try opening with default only
            std::vector<rocksdb::ColumnFamilyDescriptor> default_cf = {
                rocksdb::ColumnFamilyDescriptor(rocksdb::kDefaultColumnFamilyName, cf_options)
            };
            std::vector<rocksdb::ColumnFamilyHandle*> handles;
            status = rocksdb::DB::Open(options, config_.db_path, default_cf, &handles, &db_raw);
            if (status.ok()) {
                db_.reset(db_raw);
                // Create missing column families
                for (const auto& cf : cf_descriptors) {
                    if (cf.name != rocksdb::kDefaultColumnFamilyName) {
                        rocksdb::ColumnFamilyHandle* handle;
                        auto s = db_->CreateColumnFamily(cf_options, cf.name, &handle);
                        if (s.ok()) {
                            cf_handles_.push_back(handle);
                        }
                    }
                }
                // Re-assign handle for default CF
                cf_handles_.insert(cf_handles_.begin(), handles[0]);
            }
        }
        if (!status.ok()) {
            return false;
        }
    } else {
        db_.reset(db_raw);
    }

    // Assign column family handles (order matches cf_descriptors)
    if (cf_handles_.size() >= 9) {
        cf_routes_ = cf_handles_[1];
        cf_by_fqdn_ = cf_handles_[2];
        cf_by_endpoint_ = cf_handles_[3];
        cf_by_virtual_ip_ = cf_handles_[4];
        cf_by_vpn_ = cf_handles_[5];
        cf_changelog_ = cf_handles_[6];
        cf_subscriptions_ = cf_handles_[7];
        cf_metadata_ = cf_handles_[8];
    }

    // Load current sequence from metadata
    std::string seq_str;
    status = db_->Get(rocksdb::ReadOptions(), cf_metadata_, "current_sequence", &seq_str);
    if (status.ok() && seq_str.size() == 8) {
        uint64_t seq = 0;
        for (int i = 0; i < 8; ++i) {
            seq = (seq << 8) | static_cast<uint8_t>(seq_str[i]);
        }
        current_sequence_.store(seq);
    }

    return true;
}

void RouteStore::close() {
    if (db_) {
        // Save current sequence
        std::string seq_str(8, 0);
        uint64_t seq = current_sequence_.load();
        for (int i = 7; i >= 0; --i) {
            seq_str[i] = static_cast<char>(seq & 0xFF);
            seq >>= 8;
        }
        db_->Put(rocksdb::WriteOptions(), cf_metadata_, "current_sequence", seq_str);

        for (auto* handle : cf_handles_) {
            if (handle) {
                db_->DestroyColumnFamilyHandle(handle);
            }
        }
        cf_handles_.clear();
        db_.reset();
    }
}

std::string RouteStore::encode_route_key(uint32_t vpn, const Prefix& prefix) {
    std::string key;
    key.reserve(32);

    // VPN as big-endian 4 bytes
    key.push_back(static_cast<char>((vpn >> 24) & 0xFF));
    key.push_back(static_cast<char>((vpn >> 16) & 0xFF));
    key.push_back(static_cast<char>((vpn >> 8) & 0xFF));
    key.push_back(static_cast<char>(vpn & 0xFF));

    key.push_back('|');

    // Address family
    key.push_back(static_cast<char>(prefix.family()));

    // Address bytes
    key.append(prefix.address());

    // Prefix length
    key.push_back(static_cast<char>(prefix.prefix_length()));

    return key;
}

std::string RouteStore::encode_index_key(const std::string& value, const std::string& route_id) {
    return value + "|" + route_id;
}

std::string RouteStore::encode_vpn_key(uint32_t vpn) {
    std::string key(4, 0);
    key[0] = static_cast<char>((vpn >> 24) & 0xFF);
    key[1] = static_cast<char>((vpn >> 16) & 0xFF);
    key[2] = static_cast<char>((vpn >> 8) & 0xFF);
    key[3] = static_cast<char>(vpn & 0xFF);
    return key;
}

std::string RouteStore::encode_sequence_key(uint64_t sequence) {
    std::string key(8, 0);
    for (int i = 7; i >= 0; --i) {
        key[i] = static_cast<char>(sequence & 0xFF);
        sequence >>= 8;
    }
    return key;
}

std::string RouteStore::bytes_to_hex(const std::string& bytes) {
    std::ostringstream ss;
    ss << std::hex << std::setfill('0');
    for (unsigned char c : bytes) {
        ss << std::setw(2) << static_cast<int>(c);
    }
    return ss.str();
}

std::string RouteStore::hex_to_bytes(const std::string& hex) {
    std::string bytes;
    bytes.reserve(hex.size() / 2);
    for (size_t i = 0; i + 1 < hex.size(); i += 2) {
        int byte = std::stoi(hex.substr(i, 2), nullptr, 16);
        bytes.push_back(static_cast<char>(byte));
    }
    return bytes;
}

uint64_t RouteStore::next_sequence() {
    return ++current_sequence_;
}

void RouteStore::write_changelog(rocksdb::WriteBatch& batch, uint64_t seq, ChangeType type, const Route& route) {
    RouteChange change;
    change.set_sequence(seq);
    change.set_type(type);
    *change.mutable_route() = route;
    change.set_timestamp(now_micros());

    std::string key = encode_sequence_key(seq);
    std::string value;
    change.SerializeToString(&value);

    batch.Put(cf_changelog_, key, value);
}

void RouteStore::update_indexes(rocksdb::WriteBatch& batch, const Route* old_route, const Route* new_route) {
    // Remove old index entries
    if (old_route) {
        if (!old_route->discovered_fqdn().empty()) {
            batch.Delete(cf_by_fqdn_, encode_index_key(old_route->discovered_fqdn(), old_route->route_id()));
        }
        if (!old_route->endpoint_ip().empty()) {
            batch.Delete(cf_by_endpoint_, encode_index_key(bytes_to_hex(old_route->endpoint_ip()), old_route->route_id()));
        }
        if (!old_route->virtual_ip().empty()) {
            batch.Delete(cf_by_virtual_ip_, encode_index_key(bytes_to_hex(old_route->virtual_ip()), old_route->route_id()));
        }
        batch.Delete(cf_by_vpn_, encode_index_key(encode_vpn_key(old_route->vpn()), old_route->route_id()));
    }

    // Add new index entries
    if (new_route) {
        if (!new_route->discovered_fqdn().empty()) {
            batch.Put(cf_by_fqdn_, encode_index_key(new_route->discovered_fqdn(), new_route->route_id()), "");
        }
        if (!new_route->endpoint_ip().empty()) {
            batch.Put(cf_by_endpoint_, encode_index_key(bytes_to_hex(new_route->endpoint_ip()), new_route->route_id()), "");
        }
        if (!new_route->virtual_ip().empty()) {
            batch.Put(cf_by_virtual_ip_, encode_index_key(bytes_to_hex(new_route->virtual_ip()), new_route->route_id()), "");
        }
        batch.Put(cf_by_vpn_, encode_index_key(encode_vpn_key(new_route->vpn()), new_route->route_id()), "");
    }
}

bool RouteStore::put_route_internal(const Route& route, ChangeType change_type, uint64_t* sequence) {
    if (!db_) return false;

    Route route_copy = route;
    int64_t now = now_micros();

    // Generate route_id if not set
    if (route_copy.route_id().empty()) {
        route_copy.set_route_id(generate_uuid());
    }

    // Set timestamps
    if (change_type == ChangeType::ADD) {
        route_copy.set_created_at(now);
    }
    route_copy.set_updated_at(now);

    // Get existing route for index updates
    std::optional<Route> existing;
    if (change_type == ChangeType::UPDATE) {
        existing = get_route_by_prefix(route_copy.vpn(), route_copy.prefix());
        if (!existing) {
            // Route doesn't exist, treat as add
            change_type = ChangeType::ADD;
            route_copy.set_created_at(now);
        } else {
            // Preserve created_at
            route_copy.set_created_at(existing->created_at());
            route_copy.set_route_id(existing->route_id());
        }
    }

    rocksdb::WriteBatch batch;

    // Write route
    std::string route_key = encode_route_key(route_copy.vpn(), route_copy.prefix());
    std::string route_value;
    route_copy.SerializeToString(&route_value);
    batch.Put(cf_routes_, route_key, route_value);

    // Update indexes
    update_indexes(batch, existing ? &*existing : nullptr, &route_copy);

    // Write to changelog
    uint64_t seq = next_sequence();
    write_changelog(batch, seq, change_type, route_copy);

    auto status = db_->Write(rocksdb::WriteOptions(), &batch);
    if (status.ok() && sequence) {
        *sequence = seq;
    }

    return status.ok();
}

bool RouteStore::delete_route_internal(const Route& route, uint64_t* sequence) {
    if (!db_) return false;

    rocksdb::WriteBatch batch;

    // Delete route
    std::string route_key = encode_route_key(route.vpn(), route.prefix());
    batch.Delete(cf_routes_, route_key);

    // Remove indexes
    update_indexes(batch, &route, nullptr);

    // Write to changelog
    uint64_t seq = next_sequence();
    write_changelog(batch, seq, ChangeType::DELETE, route);

    auto status = db_->Write(rocksdb::WriteOptions(), &batch);
    if (status.ok() && sequence) {
        *sequence = seq;
    }

    return status.ok();
}

bool RouteStore::add_route(const Route& route, uint64_t* sequence) {
    return put_route_internal(route, ChangeType::ADD, sequence);
}

bool RouteStore::update_route(const Route& route, uint64_t* sequence) {
    return put_route_internal(route, ChangeType::UPDATE, sequence);
}

bool RouteStore::delete_route(const std::string& route_id, uint64_t* sequence) {
    auto route = get_route(route_id);
    if (!route) return false;
    return delete_route_internal(*route, sequence);
}

bool RouteStore::delete_route_by_prefix(uint32_t vpn, const Prefix& prefix, uint64_t* sequence) {
    auto route = get_route_by_prefix(vpn, prefix);
    if (!route) return false;
    return delete_route_internal(*route, sequence);
}

bool RouteStore::upsert_route(const Route& route, bool* was_added, uint64_t* sequence) {
    auto existing = get_route_by_prefix(route.vpn(), route.prefix());
    if (was_added) {
        *was_added = !existing.has_value();
    }

    ChangeType type = existing ? ChangeType::UPDATE : ChangeType::ADD;
    return put_route_internal(route, type, sequence);
}

std::optional<Route> RouteStore::get_route(const std::string& route_id) {
    if (!db_) return std::nullopt;

    // We need to scan by_vpn index to find the route
    // This is O(n) but route_id lookups should be rare
    std::unique_ptr<rocksdb::Iterator> it(db_->NewIterator(rocksdb::ReadOptions(), cf_routes_));
    for (it->SeekToFirst(); it->Valid(); it->Next()) {
        Route route;
        if (route.ParseFromString(it->value().ToString())) {
            if (route.route_id() == route_id) {
                return route;
            }
        }
    }
    return std::nullopt;
}

std::optional<Route> RouteStore::get_route_by_prefix(uint32_t vpn, const Prefix& prefix) {
    if (!db_) return std::nullopt;

    std::string key = encode_route_key(vpn, prefix);
    std::string value;

    auto status = db_->Get(rocksdb::ReadOptions(), cf_routes_, key, &value);
    if (!status.ok()) return std::nullopt;

    Route route;
    if (!route.ParseFromString(value)) return std::nullopt;

    return route;
}

std::vector<Route> RouteStore::get_routes_by_fqdn(const std::string& fqdn, uint32_t limit) {
    std::vector<Route> routes;
    if (!db_) return routes;

    std::string prefix = fqdn + "|";
    std::unique_ptr<rocksdb::Iterator> it(db_->NewIterator(rocksdb::ReadOptions(), cf_by_fqdn_));

    for (it->Seek(prefix); it->Valid() && it->key().starts_with(prefix); it->Next()) {
        // Extract route_id from key
        std::string key = it->key().ToString();
        std::string route_id = key.substr(prefix.size());

        auto route = get_route(route_id);
        if (route) {
            routes.push_back(*route);
            if (limit > 0 && routes.size() >= limit) break;
        }
    }

    return routes;
}

std::vector<Route> RouteStore::get_routes_by_endpoint(const std::string& endpoint_ip_hex, uint32_t limit) {
    std::vector<Route> routes;
    if (!db_) return routes;

    std::string prefix = endpoint_ip_hex + "|";
    std::unique_ptr<rocksdb::Iterator> it(db_->NewIterator(rocksdb::ReadOptions(), cf_by_endpoint_));

    for (it->Seek(prefix); it->Valid() && it->key().starts_with(prefix); it->Next()) {
        std::string key = it->key().ToString();
        std::string route_id = key.substr(prefix.size());

        auto route = get_route(route_id);
        if (route) {
            routes.push_back(*route);
            if (limit > 0 && routes.size() >= limit) break;
        }
    }

    return routes;
}

std::vector<Route> RouteStore::get_routes_by_virtual_ip(const std::string& virtual_ip_hex, uint32_t limit) {
    std::vector<Route> routes;
    if (!db_) return routes;

    std::string prefix = virtual_ip_hex + "|";
    std::unique_ptr<rocksdb::Iterator> it(db_->NewIterator(rocksdb::ReadOptions(), cf_by_virtual_ip_));

    for (it->Seek(prefix); it->Valid() && it->key().starts_with(prefix); it->Next()) {
        std::string key = it->key().ToString();
        std::string route_id = key.substr(prefix.size());

        auto route = get_route(route_id);
        if (route) {
            routes.push_back(*route);
            if (limit > 0 && routes.size() >= limit) break;
        }
    }

    return routes;
}

std::vector<Route> RouteStore::get_routes_by_vpn(uint32_t vpn, uint32_t limit) {
    std::vector<Route> routes;
    if (!db_) return routes;

    std::string vpn_prefix = encode_vpn_key(vpn);
    std::unique_ptr<rocksdb::Iterator> it(db_->NewIterator(rocksdb::ReadOptions(), cf_routes_));

    for (it->Seek(vpn_prefix); it->Valid() && it->key().starts_with(vpn_prefix); it->Next()) {
        Route route;
        if (route.ParseFromString(it->value().ToString())) {
            routes.push_back(route);
            if (limit > 0 && routes.size() >= limit) break;
        }
    }

    return routes;
}

std::vector<std::string> RouteStore::list_fqdns(const std::string& prefix, uint32_t limit, uint32_t offset) {
    std::vector<std::string> fqdns;
    if (!db_) return fqdns;

    std::unordered_set<std::string> seen;
    std::unique_ptr<rocksdb::Iterator> it(db_->NewIterator(rocksdb::ReadOptions(), cf_by_fqdn_));

    uint32_t skipped = 0;
    for (it->Seek(prefix); it->Valid(); it->Next()) {
        std::string key = it->key().ToString();
        size_t pipe_pos = key.find('|');
        if (pipe_pos == std::string::npos) continue;

        std::string fqdn = key.substr(0, pipe_pos);
        if (!prefix.empty() && !fqdn.starts_with(prefix)) break;

        if (seen.insert(fqdn).second) {
            if (skipped < offset) {
                ++skipped;
                continue;
            }
            fqdns.push_back(fqdn);
            if (fqdns.size() >= limit) break;
        }
    }

    return fqdns;
}

std::vector<uint32_t> RouteStore::list_vpns(uint32_t limit, uint32_t offset) {
    std::vector<uint32_t> vpns;
    if (!db_) return vpns;

    std::unordered_set<uint32_t> seen;
    std::unique_ptr<rocksdb::Iterator> it(db_->NewIterator(rocksdb::ReadOptions(), cf_by_vpn_));

    uint32_t skipped = 0;
    for (it->SeekToFirst(); it->Valid(); it->Next()) {
        std::string key = it->key().ToString();
        if (key.size() < 4) continue;

        uint32_t vpn = (static_cast<uint8_t>(key[0]) << 24) |
                       (static_cast<uint8_t>(key[1]) << 16) |
                       (static_cast<uint8_t>(key[2]) << 8) |
                       static_cast<uint8_t>(key[3]);

        if (seen.insert(vpn).second) {
            if (skipped < offset) {
                ++skipped;
                continue;
            }
            vpns.push_back(vpn);
            if (vpns.size() >= limit) break;
        }
    }

    return vpns;
}

uint64_t RouteStore::get_route_count() {
    if (!db_) return 0;

    uint64_t count = 0;
    std::unique_ptr<rocksdb::Iterator> it(db_->NewIterator(rocksdb::ReadOptions(), cf_routes_));
    for (it->SeekToFirst(); it->Valid(); it->Next()) {
        ++count;
    }
    return count;
}

uint64_t RouteStore::get_fqdn_count() {
    return list_fqdns("", std::numeric_limits<uint32_t>::max()).size();
}

uint64_t RouteStore::get_vpn_count() {
    return list_vpns(std::numeric_limits<uint32_t>::max()).size();
}

uint64_t RouteStore::get_oldest_sequence() {
    if (!db_) return 0;

    std::unique_ptr<rocksdb::Iterator> it(db_->NewIterator(rocksdb::ReadOptions(), cf_changelog_));
    it->SeekToFirst();
    if (!it->Valid()) return 0;

    std::string key = it->key().ToString();
    if (key.size() != 8) return 0;

    uint64_t seq = 0;
    for (int i = 0; i < 8; ++i) {
        seq = (seq << 8) | static_cast<uint8_t>(key[i]);
    }
    return seq;
}

std::vector<RouteChange> RouteStore::get_changes_since(uint64_t sequence, uint32_t limit) {
    std::vector<RouteChange> changes;
    if (!db_) return changes;

    std::string start_key = encode_sequence_key(sequence + 1);
    std::unique_ptr<rocksdb::Iterator> it(db_->NewIterator(rocksdb::ReadOptions(), cf_changelog_));

    for (it->Seek(start_key); it->Valid(); it->Next()) {
        RouteChange change;
        if (change.ParseFromString(it->value().ToString())) {
            changes.push_back(change);
            if (limit > 0 && changes.size() >= limit) break;
        }
    }

    return changes;
}

bool RouteStore::prune_changelog(uint64_t before_sequence) {
    if (!db_) return false;

    rocksdb::WriteBatch batch;
    std::string end_key = encode_sequence_key(before_sequence);
    std::unique_ptr<rocksdb::Iterator> it(db_->NewIterator(rocksdb::ReadOptions(), cf_changelog_));

    for (it->SeekToFirst(); it->Valid(); it->Next()) {
        if (it->key().compare(end_key) >= 0) break;
        batch.Delete(cf_changelog_, it->key());
    }

    return db_->Write(rocksdb::WriteOptions(), &batch).ok();
}

bool RouteStore::prune_changelog_by_age(uint64_t hours) {
    if (!db_) return false;

    int64_t cutoff = now_micros() - (hours * 3600 * 1000000LL);  // microseconds

    rocksdb::WriteBatch batch;
    std::unique_ptr<rocksdb::Iterator> it(db_->NewIterator(rocksdb::ReadOptions(), cf_changelog_));

    for (it->SeekToFirst(); it->Valid(); it->Next()) {
        RouteChange change;
        if (change.ParseFromString(it->value().ToString())) {
            if (change.timestamp() >= cutoff) break;
            batch.Delete(cf_changelog_, it->key());
        }
    }

    return db_->Write(rocksdb::WriteOptions(), &batch).ok();
}

bool RouteStore::save_subscription(const std::string& subscription_id, const SubscribeRequest& request) {
    if (!db_) return false;

    std::string value;
    request.SerializeToString(&value);

    return db_->Put(rocksdb::WriteOptions(), cf_subscriptions_, subscription_id, value).ok();
}

std::optional<SubscribeRequest> RouteStore::get_subscription(const std::string& subscription_id) {
    if (!db_) return std::nullopt;

    std::string value;
    auto status = db_->Get(rocksdb::ReadOptions(), cf_subscriptions_, subscription_id, &value);
    if (!status.ok()) return std::nullopt;

    SubscribeRequest request;
    if (!request.ParseFromString(value)) return std::nullopt;

    return request;
}

bool RouteStore::delete_subscription(const std::string& subscription_id) {
    if (!db_) return false;
    return db_->Delete(rocksdb::WriteOptions(), cf_subscriptions_, subscription_id).ok();
}

std::vector<std::pair<std::string, SubscribeRequest>> RouteStore::list_subscriptions() {
    std::vector<std::pair<std::string, SubscribeRequest>> result;
    if (!db_) return result;

    std::unique_ptr<rocksdb::Iterator> it(db_->NewIterator(rocksdb::ReadOptions(), cf_subscriptions_));
    for (it->SeekToFirst(); it->Valid(); it->Next()) {
        SubscribeRequest request;
        if (request.ParseFromString(it->value().ToString())) {
            result.emplace_back(it->key().ToString(), request);
        }
    }

    return result;
}

std::shared_ptr<RouteStore::SyncSession> RouteStore::start_sync(const std::string& sync_id) {
    std::lock_guard<std::mutex> lock(sync_sessions_mutex_);

    auto session = std::make_shared<SyncSession>();
    session->sync_id = sync_id.empty() ? generate_uuid() : sync_id;
    sync_sessions_[session->sync_id] = session;

    return session;
}

bool RouteStore::complete_sync(std::shared_ptr<SyncSession> session, bool delete_missing) {
    if (!session || !db_) return false;

    if (delete_missing) {
        // Find and delete routes not seen during sync
        std::vector<Route> to_delete;
        iterate_routes([&](const Route& route) {
            if (session->seen_route_ids.find(route.route_id()) == session->seen_route_ids.end()) {
                to_delete.push_back(route);
            }
            return true;
        });

        for (const auto& route : to_delete) {
            delete_route_internal(route, nullptr);
        }
    }

    std::lock_guard<std::mutex> lock(sync_sessions_mutex_);
    sync_sessions_.erase(session->sync_id);

    return true;
}

void RouteStore::iterate_routes(std::function<bool(const Route&)> callback) {
    if (!db_) return;

    std::unique_ptr<rocksdb::Iterator> it(db_->NewIterator(rocksdb::ReadOptions(), cf_routes_));
    for (it->SeekToFirst(); it->Valid(); it->Next()) {
        Route route;
        if (route.ParseFromString(it->value().ToString())) {
            if (!callback(route)) break;
        }
    }
}

void RouteStore::iterate_routes_by_filter(const SubscriptionFilter& filter, std::function<bool(const Route&)> callback) {
    if (!db_) return;

    switch (filter.filter_case()) {
        case SubscriptionFilter::kDiscoveredFqdn: {
            auto routes = get_routes_by_fqdn(filter.discovered_fqdn());
            for (const auto& route : routes) {
                if (!callback(route)) return;
            }
            break;
        }
        case SubscriptionFilter::kEndpointIp: {
            auto routes = get_routes_by_endpoint(bytes_to_hex(filter.endpoint_ip()));
            for (const auto& route : routes) {
                if (!callback(route)) return;
            }
            break;
        }
        case SubscriptionFilter::kVirtualIp: {
            auto routes = get_routes_by_virtual_ip(bytes_to_hex(filter.virtual_ip()));
            for (const auto& route : routes) {
                if (!callback(route)) return;
            }
            break;
        }
        case SubscriptionFilter::kVpn: {
            auto routes = get_routes_by_vpn(filter.vpn());
            for (const auto& route : routes) {
                if (!callback(route)) return;
            }
            break;
        }
        default:
            break;
    }
}

RouteStore::BatchUpsertResult RouteStore::batch_upsert(const std::vector<std::pair<Route, ChangeType>>& updates) {
    BatchUpsertResult result;
    if (!db_ || updates.empty()) return result;

    int64_t now = now_micros();
    rocksdb::WriteBatch rb_batch;
    result.changes.reserve(updates.size());

    // cppcheck-suppress unassignedVariable
    for (const auto& [route, requested_type] : updates) {
        Route route_copy = route;

        // Generate route_id if not set
        if (route_copy.route_id().empty()) {
            route_copy.set_route_id(generate_uuid());
        }

        ChangeType actual_type = requested_type;

        if (requested_type == DELETE) {
            // Handle delete
            auto existing = get_route_by_prefix(route_copy.vpn(), route_copy.prefix());
            if (existing) {
                // Delete route from main CF
                std::string route_key = encode_route_key(existing->vpn(), existing->prefix());
                rb_batch.Delete(cf_routes_, route_key);

                // Remove indexes
                update_indexes(rb_batch, &*existing, nullptr);

                // Build change and write to changelog
                uint64_t seq = next_sequence();
                RouteChange change;
                change.set_sequence(seq);
                change.set_type(DELETE);
                *change.mutable_route() = *existing;
                change.set_timestamp(now);
                write_changelog(rb_batch, seq, DELETE, *existing);
                result.changes.push_back(std::move(change));
                ++result.deleted;
            } else {
                ++result.failed;
            }
        } else {
            // Handle add/update/upsert
            auto existing = get_route_by_prefix(route_copy.vpn(), route_copy.prefix());

            if (existing) {
                // Route exists - update
                actual_type = UPDATE;
                route_copy.set_created_at(existing->created_at());
                route_copy.set_route_id(existing->route_id());
                route_copy.set_updated_at(now);
                ++result.updated;
            } else {
                // Route doesn't exist - add
                actual_type = ADD;
                route_copy.set_created_at(now);
                route_copy.set_updated_at(now);
                ++result.added;
            }

            // Write route
            std::string route_key = encode_route_key(route_copy.vpn(), route_copy.prefix());
            std::string route_value;
            route_copy.SerializeToString(&route_value);
            rb_batch.Put(cf_routes_, route_key, route_value);

            // Update indexes
            update_indexes(rb_batch, existing ? &*existing : nullptr, &route_copy);

            // Build change and write to changelog
            uint64_t seq = next_sequence();
            RouteChange change;
            change.set_sequence(seq);
            change.set_type(actual_type);
            *change.mutable_route() = route_copy;
            change.set_timestamp(now);
            write_changelog(rb_batch, seq, actual_type, route_copy);
            result.changes.push_back(std::move(change));
        }
    }

    // Single atomic write for entire batch
    auto status = db_->Write(rocksdb::WriteOptions(), &rb_batch);
    if (!status.ok()) {
        // If batch write fails, all operations failed
        result.failed = updates.size();
        result.added = 0;
        result.updated = 0;
        result.deleted = 0;
        result.changes.clear();
    }

    return result;
}

void RouteStore::WriteBatch::add_route(const Route& route) {
    routes_to_add_.push_back(route);
}

void RouteStore::WriteBatch::update_route(const Route& route) {
    routes_to_update_.push_back(route);
}

void RouteStore::WriteBatch::delete_route(const std::string& route_id) {
    routes_to_delete_.push_back(route_id);
}

bool RouteStore::commit_batch(WriteBatch& batch, uint64_t* first_sequence) {
    if (!db_) return false;

    uint64_t seq = 0;
    bool got_first = false;

    for (const auto& route : batch.routes_to_add_) {
        uint64_t s;
        if (add_route(route, &s)) {
            if (!got_first) {
                seq = s;
                got_first = true;
            }
        }
    }

    for (const auto& route : batch.routes_to_update_) {
        uint64_t s;
        if (update_route(route, &s)) {
            if (!got_first) {
                seq = s;
                got_first = true;
            }
        }
    }

    for (const auto& route_id : batch.routes_to_delete_) {
        uint64_t s;
        if (delete_route(route_id, &s)) {
            if (!got_first) {
                seq = s;
                got_first = true;
            }
        }
    }

    if (first_sequence && got_first) {
        *first_sequence = seq;
    }

    // Clear batch
    batch.routes_to_add_.clear();
    batch.routes_to_update_.clear();
    batch.routes_to_delete_.clear();

    return true;
}

}  // namespace kepler
