#pragma once

#include "config/config.h"
#include "kepler.pb.h"

#include <rocksdb/db.h>
#include <rocksdb/options.h>
#include <rocksdb/slice.h>
#include <rocksdb/write_batch.h>

#include <memory>
#include <string>
#include <vector>
#include <optional>
#include <functional>
#include <mutex>
#include <unordered_set>
#include <atomic>

namespace kepler {

// Column family names
constexpr const char* CF_ROUTES = "routes";
constexpr const char* CF_BY_FQDN = "by_fqdn";
constexpr const char* CF_BY_ENDPOINT = "by_endpoint";
constexpr const char* CF_BY_VIRTUAL_IP = "by_virtual_ip";
constexpr const char* CF_BY_VPN = "by_vpn";
constexpr const char* CF_CHANGELOG = "changelog";
constexpr const char* CF_SUBSCRIPTIONS = "subscriptions";
constexpr const char* CF_METADATA = "metadata";

class RouteStore {
public:
    explicit RouteStore(const Config& config);
    ~RouteStore();

    // Prevent copying
    RouteStore(const RouteStore&) = delete;
    RouteStore& operator=(const RouteStore&) = delete;

    // Initialize/open the database
    bool open();
    void close();
    bool is_open() const { return db_ != nullptr; }

    // Route CRUD operations
    bool add_route(const Route& route, uint64_t* sequence = nullptr);
    bool update_route(const Route& route, uint64_t* sequence = nullptr);
    bool delete_route(const std::string& route_id, uint64_t* sequence = nullptr);
    bool delete_route_by_prefix(uint32_t vpn, const Prefix& prefix, uint64_t* sequence = nullptr);

    // Upsert: add or update (returns true if added, false if updated)
    bool upsert_route(const Route& route, bool* was_added, uint64_t* sequence = nullptr);

    // Efficient batch upsert - single RocksDB WriteBatch for all operations
    struct BatchUpsertResult {
        uint64_t added = 0;
        uint64_t updated = 0;
        uint64_t deleted = 0;
        uint64_t failed = 0;
        std::vector<RouteChange> changes;  // Return changes directly, avoid re-reading from DB
    };
    BatchUpsertResult batch_upsert(const std::vector<std::pair<Route, ChangeType>>& updates);

    // Batch operations for high throughput
    class WriteBatch {
    public:
        void add_route(const Route& route);
        void update_route(const Route& route);
        void delete_route(const std::string& route_id);

    private:
        friend class RouteStore;
        rocksdb::WriteBatch batch_;
        std::vector<Route> routes_to_add_;
        std::vector<Route> routes_to_update_;
        std::vector<std::string> routes_to_delete_;
    };

    bool commit_batch(WriteBatch& batch, uint64_t* first_sequence = nullptr);

    // Sync session management
    struct SyncSession {
        std::string sync_id;
        std::unordered_set<std::string> seen_route_ids;
        uint64_t routes_processed = 0;
    };

    std::shared_ptr<SyncSession> start_sync(const std::string& sync_id);
    bool complete_sync(std::shared_ptr<SyncSession> session, bool delete_missing);

    // Lookup operations
    std::optional<Route> get_route(const std::string& route_id);
    std::optional<Route> get_route_by_prefix(uint32_t vpn, const Prefix& prefix);

    // Index lookups (returns route IDs, then fetch routes)
    std::vector<Route> get_routes_by_fqdn(const std::string& fqdn, uint32_t limit = 0);
    std::vector<Route> get_routes_by_endpoint(const std::string& endpoint_ip_hex, uint32_t limit = 0);
    std::vector<Route> get_routes_by_virtual_ip(const std::string& virtual_ip_hex, uint32_t limit = 0);
    std::vector<Route> get_routes_by_vpn(uint32_t vpn, uint32_t limit = 0);

    // List operations
    std::vector<std::string> list_fqdns(const std::string& prefix = "", uint32_t limit = 1000, uint32_t offset = 0);
    std::vector<uint32_t> list_vpns(uint32_t limit = 1000, uint32_t offset = 0);

    // Statistics
    uint64_t get_route_count();
    uint64_t get_fqdn_count();
    uint64_t get_vpn_count();

    // Changelog operations
    uint64_t get_current_sequence() const { return current_sequence_.load(); }
    uint64_t get_oldest_sequence();
    std::vector<RouteChange> get_changes_since(uint64_t sequence, uint32_t limit = 1000);
    bool prune_changelog(uint64_t before_sequence);
    bool prune_changelog_by_age(uint64_t hours);

    // Subscription persistence
    bool save_subscription(const std::string& subscription_id, const SubscribeRequest& request);
    std::optional<SubscribeRequest> get_subscription(const std::string& subscription_id);
    bool delete_subscription(const std::string& subscription_id);
    std::vector<std::pair<std::string, SubscribeRequest>> list_subscriptions();

    // Iterate all routes (for full sync to client)
    void iterate_routes(std::function<bool(const Route&)> callback);
    void iterate_routes_by_filter(const SubscriptionFilter& filter, std::function<bool(const Route&)> callback);

private:
    // Key encoding helpers
    static std::string encode_route_key(uint32_t vpn, const Prefix& prefix);
    static std::string encode_index_key(const std::string& value, const std::string& route_id);
    static std::string encode_vpn_key(uint32_t vpn);
    static std::string encode_sequence_key(uint64_t sequence);
    static std::string bytes_to_hex(const std::string& bytes);
    static std::string hex_to_bytes(const std::string& hex);

    // Internal helpers
    bool put_route_internal(const Route& route, ChangeType change_type, uint64_t* sequence);
    bool delete_route_internal(const Route& route, uint64_t* sequence);
    void update_indexes(rocksdb::WriteBatch& batch, const Route* old_route, const Route* new_route);
    uint64_t next_sequence();
    void write_changelog(rocksdb::WriteBatch& batch, uint64_t seq, ChangeType type, const Route& route);

    Config config_;
    std::unique_ptr<rocksdb::DB> db_;
    std::vector<rocksdb::ColumnFamilyHandle*> cf_handles_;

    // Column family handle pointers (owned by cf_handles_)
    rocksdb::ColumnFamilyHandle* cf_routes_ = nullptr;
    rocksdb::ColumnFamilyHandle* cf_by_fqdn_ = nullptr;
    rocksdb::ColumnFamilyHandle* cf_by_endpoint_ = nullptr;
    rocksdb::ColumnFamilyHandle* cf_by_virtual_ip_ = nullptr;
    rocksdb::ColumnFamilyHandle* cf_by_vpn_ = nullptr;
    rocksdb::ColumnFamilyHandle* cf_changelog_ = nullptr;
    rocksdb::ColumnFamilyHandle* cf_subscriptions_ = nullptr;
    rocksdb::ColumnFamilyHandle* cf_metadata_ = nullptr;

    std::atomic<uint64_t> current_sequence_{0};
    std::mutex sync_sessions_mutex_;
    std::unordered_map<std::string, std::shared_ptr<SyncSession>> sync_sessions_;
};

}  // namespace kepler
