#include "storage/change_log.h"
#include <chrono>

namespace kepler {

ChangeLog::ChangeLog(RouteStore& store, const Config& config)
    : store_(store), config_(config) {}

ChangeLog::~ChangeLog() {
    stop();
}

void ChangeLog::start() {
    if (running_.exchange(true)) return;

    prune_thread_ = std::thread([this] { prune_loop(); });
}

void ChangeLog::stop() {
    if (!running_.exchange(false)) return;

    {
        std::lock_guard<std::mutex> lock(mutex_);
        cv_.notify_all();
    }

    if (prune_thread_.joinable()) {
        prune_thread_.join();
    }
}

std::vector<RouteChange> ChangeLog::get_changes_since(uint64_t sequence, uint32_t limit) {
    return store_.get_changes_since(sequence, limit);
}

bool ChangeLog::is_sequence_valid(uint64_t sequence) {
    uint64_t oldest = store_.get_oldest_sequence();
    return sequence >= oldest || oldest == 0;
}

void ChangeLog::prune_now() {
    store_.prune_changelog_by_age(config_.changelog_retention_hours);
}

void ChangeLog::prune_loop() {
    while (running_) {
        {
            std::unique_lock<std::mutex> lock(mutex_);
            cv_.wait_for(lock, std::chrono::seconds(config_.changelog_prune_interval_seconds),
                        [this] { return !running_.load(); });
        }

        if (!running_) break;

        prune_now();
    }
}

}  // namespace kepler
