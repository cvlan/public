#include "services/ingestion_service.h"
#include <sstream>

namespace kepler {

IngestionServiceImpl::IngestionServiceImpl(RouteManager& route_manager)
    : route_manager_(route_manager) {}

grpc::Status IngestionServiceImpl::IngestRoutes(
    grpc::ServerContext* context,
    grpc::ServerReader<RouteUpdate>* reader,
    IngestResponse* response) {

    uint64_t processed = 0;
    uint64_t added = 0;
    uint64_t updated = 0;
    uint64_t deleted = 0;
    uint64_t unchanged = 0;

    // Check if this stream is associated with a sync session
    std::string sync_id;
    {
        std::lock_guard<std::mutex> lock(sync_mutex_);
        auto it = stream_sync_sessions_.find(context->peer());
        if (it != stream_sync_sessions_.end()) {
            sync_id = it->second;
        }
    }

    RouteUpdate update;
    while (reader->Read(&update)) {
        if (context->IsCancelled()) {
            return grpc::Status(grpc::StatusCode::CANCELLED, "Client cancelled");
        }

        bool success = false;
        bool was_added = false;

        if (!sync_id.empty()) {
            // During sync, use upsert (was_added not tracked for sync operations)
            success = route_manager_.add_route_to_sync(sync_id, update.route());
        } else {
            // Normal operation
            switch (update.operation()) {
                case ChangeType::ADD:
                    success = route_manager_.add_route(update.route());
                    if (success) ++added;
                    break;
                case ChangeType::UPDATE:
                    success = route_manager_.update_route(update.route());
                    if (success) ++updated;
                    break;
                case ChangeType::DELETE:
                    if (update.route().has_prefix()) {
                        success = route_manager_.delete_route_by_prefix(
                            update.route().vpn(), update.route().prefix());
                    } else {
                        success = route_manager_.delete_route(update.route().route_id());
                    }
                    if (success) ++deleted;
                    break;
                default:
                    // Default to upsert
                    success = route_manager_.upsert_route(update.route(), &was_added);
                    if (success) {
                        if (was_added) ++added;
                        else ++updated;
                    }
                    break;
            }
        }

        if (success) {
            ++processed;
        } else {
            std::ostringstream err;
            err << "Failed to process route: vpn=" << update.route().vpn();
            response->add_errors(err.str());
        }
    }

    response->set_processed(processed);
    response->set_added(added);
    response->set_updated(updated);
    response->set_deleted(deleted);
    response->set_unchanged(unchanged);

    return grpc::Status::OK;
}

grpc::Status IngestionServiceImpl::BatchIngestRoutes(
    grpc::ServerContext* context,
    const BatchRouteUpdate* request,
    IngestResponse* response) {

    if (context->IsCancelled()) {
        return grpc::Status(grpc::StatusCode::CANCELLED, "Client cancelled");
    }

    // Build batch of updates for efficient processing
    std::vector<std::pair<Route, ChangeType>> updates;
    updates.reserve(request->updates_size());

    for (const auto& update : request->updates()) {
        ChangeType op = update.operation();
        // Default unspecified to ADD for upsert behavior
        if (op == ChangeType::CHANGE_UNSPECIFIED) {
            op = ChangeType::ADD;
        }
        updates.emplace_back(update.route(), op);
    }

    // Use efficient batch ingest (single RocksDB WriteBatch)
    auto result = route_manager_.batch_ingest(updates);

    response->set_processed(result.added + result.updated + result.deleted);
    response->set_added(result.added);
    response->set_updated(result.updated);
    response->set_deleted(result.deleted);

    if (result.failed > 0) {
        std::ostringstream err;
        err << "Failed to process " << result.failed << " routes";
        response->add_errors(err.str());
    }

    return grpc::Status::OK;
}

grpc::Status IngestionServiceImpl::StartSync(
    grpc::ServerContext* context,
    const SyncRequest* request,
    SyncResponse* response) {

    std::string sync_id = route_manager_.start_sync(request->sync_id());

    // Associate this peer with the sync session
    {
        std::lock_guard<std::mutex> lock(sync_mutex_);
        stream_sync_sessions_[context->peer()] = sync_id;
    }

    response->set_sync_id(sync_id);
    response->set_success(true);
    response->set_message("Sync session started");

    return grpc::Status::OK;
}

grpc::Status IngestionServiceImpl::CompleteSync(
    grpc::ServerContext* context,
    const SyncComplete* request,
    SyncResponse* response) {

    bool success = route_manager_.complete_sync(request->sync_id(), request->delete_missing());

    // Remove sync session association
    {
        std::lock_guard<std::mutex> lock(sync_mutex_);
        for (auto it = stream_sync_sessions_.begin(); it != stream_sync_sessions_.end(); ) {
            if (it->second == request->sync_id()) {
                it = stream_sync_sessions_.erase(it);
            } else {
                ++it;
            }
        }
    }

    response->set_sync_id(request->sync_id());
    response->set_success(success);
    response->set_message(success ? "Sync completed" : "Sync session not found");

    return grpc::Status::OK;
}

grpc::Status IngestionServiceImpl::AddRoute(
    grpc::ServerContext* context,
    const Route* request,
    RouteResponse* response) {

    uint64_t seq;
    bool success = route_manager_.add_route(*request, &seq);

    response->set_success(success);
    if (success) {
        response->set_message("Route added");
        auto route = route_manager_.get_route_by_prefix(request->vpn(), request->prefix());
        if (route) {
            *response->mutable_route() = *route;
        }
    } else {
        response->set_message("Failed to add route");
    }

    return grpc::Status::OK;
}

grpc::Status IngestionServiceImpl::UpdateRoute(
    grpc::ServerContext* context,
    const Route* request,
    RouteResponse* response) {

    uint64_t seq;
    bool success = route_manager_.update_route(*request, &seq);

    response->set_success(success);
    if (success) {
        response->set_message("Route updated");
        auto route = route_manager_.get_route_by_prefix(request->vpn(), request->prefix());
        if (route) {
            *response->mutable_route() = *route;
        }
    } else {
        response->set_message("Failed to update route (may not exist)");
    }

    return grpc::Status::OK;
}

grpc::Status IngestionServiceImpl::DeleteRoute(
    grpc::ServerContext* context,
    const DeleteRequest* request,
    RouteResponse* response) {

    bool success = false;
    Route deleted_route;

    switch (request->key_case()) {
        case DeleteRequest::kRouteId: {
            auto route = route_manager_.get_route(request->route_id());
            if (route) {
                deleted_route = *route;
                success = route_manager_.delete_route(request->route_id());
            }
            break;
        }
        case DeleteRequest::kPrefixKey: {
            auto route = route_manager_.get_route_by_prefix(
                request->prefix_key().vpn(),
                request->prefix_key().prefix());
            if (route) {
                deleted_route = *route;
                success = route_manager_.delete_route_by_prefix(
                    request->prefix_key().vpn(),
                    request->prefix_key().prefix());
            }
            break;
        }
        default:
            response->set_success(false);
            response->set_message("Invalid delete request: no key specified");
            return grpc::Status::OK;
    }

    response->set_success(success);
    if (success) {
        response->set_message("Route deleted");
        *response->mutable_route() = deleted_route;
    } else {
        response->set_message("Route not found");
    }

    return grpc::Status::OK;
}

}  // namespace kepler
