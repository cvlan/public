#include "services/lookup_service.h"
#include <sstream>
#include <iomanip>

namespace kepler {

namespace {

std::string bytes_to_hex(const std::string& bytes) {
    std::ostringstream ss;
    ss << std::hex << std::setfill('0');
    for (unsigned char c : bytes) {
        ss << std::setw(2) << static_cast<int>(c);
    }
    return ss.str();
}

}  // namespace

LookupServiceImpl::LookupServiceImpl(RouteManager& route_manager,
                                     std::chrono::steady_clock::time_point start_time)
    : route_manager_(route_manager), start_time_(start_time) {}

grpc::Status LookupServiceImpl::GetRouteByPrefix(
    grpc::ServerContext* context,
    const PrefixRequest* request,
    Route* response) {

    auto route = route_manager_.get_route_by_prefix(request->vpn(), request->prefix());
    if (!route) {
        return grpc::Status(grpc::StatusCode::NOT_FOUND, "Route not found");
    }

    *response = *route;
    return grpc::Status::OK;
}

grpc::Status LookupServiceImpl::GetRoutesByVpn(
    grpc::ServerContext* context,
    const VpnRequest* request,
    grpc::ServerWriter<Route>* writer) {

    uint32_t limit = request->limit() > 0 ? request->limit() : 0;
    auto routes = route_manager_.get_routes_by_vpn(request->vpn(), limit);

    for (const auto& route : routes) {
        if (context->IsCancelled()) {
            return grpc::Status(grpc::StatusCode::CANCELLED, "Client cancelled");
        }

        // Apply prefix filter if specified
        if (request->has_prefix_filter()) {
            // Simple prefix matching - check if route prefix starts with filter
            const auto& filter = request->prefix_filter();
            const auto& route_prefix = route.prefix();

            if (route_prefix.family() != filter.family()) continue;
            if (route_prefix.prefix_length() < filter.prefix_length()) continue;

            // Check if route prefix is within filter range
            // This is a simplified check - in production you'd want proper CIDR matching
        }

        writer->Write(route);
    }

    return grpc::Status::OK;
}

grpc::Status LookupServiceImpl::GetRoutesByFqdn(
    grpc::ServerContext* context,
    const FqdnRequest* request,
    RoutesResponse* response) {

    uint32_t limit = request->limit() > 0 ? request->limit() : 0;
    auto routes = route_manager_.get_routes_by_fqdn(request->discovered_fqdn(), limit);

    for (const auto& route : routes) {
        *response->add_routes() = route;
    }
    response->set_total_count(routes.size());

    return grpc::Status::OK;
}

grpc::Status LookupServiceImpl::GetRoutesByEndpoint(
    grpc::ServerContext* context,
    const EndpointRequest* request,
    RoutesResponse* response) {

    uint32_t limit = request->limit() > 0 ? request->limit() : 0;
    std::string endpoint_hex = bytes_to_hex(request->endpoint_ip());
    auto routes = route_manager_.get_routes_by_endpoint(endpoint_hex, limit);

    for (const auto& route : routes) {
        *response->add_routes() = route;
    }
    response->set_total_count(routes.size());

    return grpc::Status::OK;
}

grpc::Status LookupServiceImpl::GetRoutesByVirtualIp(
    grpc::ServerContext* context,
    const VirtualIpRequest* request,
    RoutesResponse* response) {

    uint32_t limit = request->limit() > 0 ? request->limit() : 0;
    std::string virtual_ip_hex = bytes_to_hex(request->virtual_ip());
    auto routes = route_manager_.get_routes_by_virtual_ip(virtual_ip_hex, limit);

    for (const auto& route : routes) {
        *response->add_routes() = route;
    }
    response->set_total_count(routes.size());

    return grpc::Status::OK;
}

grpc::Status LookupServiceImpl::ListFqdns(
    grpc::ServerContext* context,
    const ListFqdnsRequest* request,
    ListFqdnsResponse* response) {

    uint32_t limit = request->limit() > 0 ? request->limit() : 1000;
    auto fqdns = route_manager_.list_fqdns(request->prefix(), limit, request->offset());

    for (const auto& fqdn : fqdns) {
        response->add_fqdns(fqdn);
    }

    // Get total count (expensive, but necessary for pagination)
    if (request->offset() == 0 && fqdns.size() < limit) {
        response->set_total_count(fqdns.size());
    } else {
        response->set_total_count(route_manager_.get_fqdn_count());
    }

    return grpc::Status::OK;
}

grpc::Status LookupServiceImpl::ListVpns(
    grpc::ServerContext* context,
    const ListVpnsRequest* request,
    ListVpnsResponse* response) {

    uint32_t limit = request->limit() > 0 ? request->limit() : 1000;
    auto vpns = route_manager_.list_vpns(limit, request->offset());

    for (uint32_t vpn : vpns) {
        response->add_vpns(vpn);
    }

    if (request->offset() == 0 && vpns.size() < limit) {
        response->set_total_count(vpns.size());
    } else {
        response->set_total_count(route_manager_.get_vpn_count());
    }

    return grpc::Status::OK;
}

grpc::Status LookupServiceImpl::GetRoute(
    grpc::ServerContext* context,
    const RouteRequest* request,
    Route* response) {

    auto route = route_manager_.get_route(request->route_id());
    if (!route) {
        return grpc::Status(grpc::StatusCode::NOT_FOUND, "Route not found");
    }

    *response = *route;
    return grpc::Status::OK;
}

grpc::Status LookupServiceImpl::GetStats(
    grpc::ServerContext* context,
    const StatsRequest* request,
    StatsResponse* response) {

    response->set_total_routes(route_manager_.get_route_count());
    response->set_total_vpns(route_manager_.get_vpn_count());
    response->set_total_fqdns(route_manager_.get_fqdn_count());
    response->set_newest_sequence(route_manager_.get_current_sequence());
    response->set_oldest_sequence(route_manager_.get_oldest_sequence());

    auto now = std::chrono::steady_clock::now();
    auto uptime = std::chrono::duration_cast<std::chrono::seconds>(now - start_time_);
    response->set_uptime_seconds(uptime.count());

    return grpc::Status::OK;
}

}  // namespace kepler
