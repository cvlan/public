#include "services/subscription_service.h"
#include <algorithm>
#include <iterator>

namespace kepler {

SubscriptionServiceImpl::SubscriptionServiceImpl(SubscriptionManager& subscription_manager)
    : subscription_manager_(subscription_manager) {}

grpc::Status SubscriptionServiceImpl::Subscribe(
    grpc::ServerContext* context,
    const SubscribeRequest* request,
    SubscribeResponse* response) {

    std::vector<SubscriptionFilter> filters;
    filters.reserve(request->filters_size());
    std::copy(request->filters().begin(), request->filters().end(),
              std::back_inserter(filters));

    std::string subscription_id = subscription_manager_.subscribe(request->client_id(), filters);

    response->set_subscription_id(subscription_id);
    response->set_success(true);
    response->set_message("Subscription created");

    return grpc::Status::OK;
}

grpc::Status SubscriptionServiceImpl::StreamChanges(
    grpc::ServerContext* context,
    const StreamRequest* request,
    grpc::ServerWriter<StreamResponse>* writer) {

    auto sub = subscription_manager_.get_subscription(request->subscription_id());
    if (!sub) {
        return grpc::Status(grpc::StatusCode::NOT_FOUND, "Subscription not found");
    }

    // Check if sequence is valid
    uint64_t last_sequence = request->last_sequence();
    bool need_full_sync = false;

    if (last_sequence > 0 && !subscription_manager_.is_sequence_valid(last_sequence)) {
        if (request->full_sync()) {
            need_full_sync = true;
        } else {
            // Return error indicating sequence is stale
            StreamResponse error_response;
            // Note: We'd need to add error field to StreamResponse or use a different approach
            return grpc::Status(grpc::StatusCode::OUT_OF_RANGE,
                               "Sequence is stale. Request with full_sync=true for full download.");
        }
    }

    // Connect the stream
    if (!subscription_manager_.connect_stream(request->subscription_id())) {
        return grpc::Status(grpc::StatusCode::INTERNAL, "Failed to connect stream");
    }

    // Full sync if requested
    if (need_full_sync || (last_sequence == 0 && request->full_sync())) {
        subscription_manager_.start_full_sync(request->subscription_id(),
            [&](const Route& route) -> bool {
                if (context->IsCancelled()) return false;

                StreamResponse response;
                *response.mutable_full_sync_route() = route;
                response.set_full_sync_complete(false);

                return writer->Write(response);
            });

        // Send full sync complete marker
        if (!context->IsCancelled()) {
            StreamResponse complete;
            complete.set_full_sync_complete(true);
            writer->Write(complete);
        }

        // Update last_sequence to current
        last_sequence = subscription_manager_.get_subscription(request->subscription_id())
            ? 0 : last_sequence;  // Reset to catch up from current
    }

    // Catch up on any changes since last_sequence
    if (last_sequence > 0) {
        auto changes = subscription_manager_.get_filtered_changes_since(
            request->subscription_id(), last_sequence);

        for (const auto& change : changes) {
            if (context->IsCancelled()) break;

            StreamResponse response;
            *response.mutable_change() = change;
            response.set_sequence(change.sequence());

            if (!writer->Write(response)) break;
        }
    }

    // Stream live changes
    while (!context->IsCancelled()) {
        auto sc = subscription_manager_.wait_for_change(request->subscription_id(),
                                                         std::chrono::milliseconds(1000));
        if (sc) {
            StreamResponse response;
            *response.mutable_change() = sc->change;
            response.set_sequence(sc->change.sequence());

            grpc::WriteOptions options;
            options.set_no_compression();

            if (!writer->Write(response, options)) {
                break;
            }
        }

        // Check if subscription is still active
        auto current_sub = subscription_manager_.get_subscription(request->subscription_id());
        if (!current_sub || !current_sub->active) {
            break;
        }
    }

    // Disconnect stream
    subscription_manager_.disconnect_stream(request->subscription_id());

    return grpc::Status::OK;
}

grpc::Status SubscriptionServiceImpl::Unsubscribe(
    grpc::ServerContext* context,
    const UnsubscribeRequest* request,
    UnsubscribeResponse* response) {

    bool success = subscription_manager_.unsubscribe(request->subscription_id());

    response->set_success(success);
    response->set_message(success ? "Unsubscribed" : "Subscription not found");

    return grpc::Status::OK;
}

grpc::Status SubscriptionServiceImpl::GetSubscription(
    grpc::ServerContext* context,
    const GetSubscriptionRequest* request,
    SubscribeResponse* response) {

    auto sub = subscription_manager_.get_subscription(request->subscription_id());
    if (!sub) {
        response->set_success(false);
        response->set_message("Subscription not found");
        return grpc::Status::OK;
    }

    response->set_subscription_id(sub->subscription_id);
    response->set_success(true);
    response->set_message("Subscription active");

    return grpc::Status::OK;
}

}  // namespace kepler
