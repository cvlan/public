#pragma once

#include "core/route_manager.h"
#include "kepler.grpc.pb.h"

#include <grpcpp/grpcpp.h>
#include <chrono>

namespace kepler {

class LookupServiceImpl final : public RouteLookup::Service {
public:
    LookupServiceImpl(RouteManager& route_manager, std::chrono::steady_clock::time_point start_time);

    grpc::Status GetRouteByPrefix(
        grpc::ServerContext* context,
        const PrefixRequest* request,
        Route* response) override;

    grpc::Status GetRoutesByVpn(
        grpc::ServerContext* context,
        const VpnRequest* request,
        grpc::ServerWriter<Route>* writer) override;

    grpc::Status GetRoutesByFqdn(
        grpc::ServerContext* context,
        const FqdnRequest* request,
        RoutesResponse* response) override;

    grpc::Status GetRoutesByEndpoint(
        grpc::ServerContext* context,
        const EndpointRequest* request,
        RoutesResponse* response) override;

    grpc::Status GetRoutesByVirtualIp(
        grpc::ServerContext* context,
        const VirtualIpRequest* request,
        RoutesResponse* response) override;

    grpc::Status ListFqdns(
        grpc::ServerContext* context,
        const ListFqdnsRequest* request,
        ListFqdnsResponse* response) override;

    grpc::Status ListVpns(
        grpc::ServerContext* context,
        const ListVpnsRequest* request,
        ListVpnsResponse* response) override;

    grpc::Status GetRoute(
        grpc::ServerContext* context,
        const RouteRequest* request,
        Route* response) override;

    grpc::Status GetStats(
        grpc::ServerContext* context,
        const StatsRequest* request,
        StatsResponse* response) override;

private:
    RouteManager& route_manager_;
    std::chrono::steady_clock::time_point start_time_;
};

}  // namespace kepler
