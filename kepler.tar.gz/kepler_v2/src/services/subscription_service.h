#pragma once

#include "core/subscription_manager.h"
#include "kepler.grpc.pb.h"

#include <grpcpp/grpcpp.h>

namespace kepler {

class SubscriptionServiceImpl final : public RouteSubscription::Service {
public:
    explicit SubscriptionServiceImpl(SubscriptionManager& subscription_manager);

    grpc::Status Subscribe(
        grpc::ServerContext* context,
        const SubscribeRequest* request,
        SubscribeResponse* response) override;

    grpc::Status StreamChanges(
        grpc::ServerContext* context,
        const StreamRequest* request,
        grpc::ServerWriter<StreamResponse>* writer) override;

    grpc::Status Unsubscribe(
        grpc::ServerContext* context,
        const UnsubscribeRequest* request,
        UnsubscribeResponse* response) override;

    grpc::Status GetSubscription(
        grpc::ServerContext* context,
        const GetSubscriptionRequest* request,
        SubscribeResponse* response) override;

private:
    SubscriptionManager& subscription_manager_;
};

}  // namespace kepler
