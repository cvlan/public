#pragma once

#include "core/route_manager.h"
#include "kepler.grpc.pb.h"

#include <grpcpp/grpcpp.h>
#include <mutex>
#include <unordered_map>

namespace kepler {

class IngestionServiceImpl final : public RouteIngestion::Service {
public:
    explicit IngestionServiceImpl(RouteManager& route_manager);

    grpc::Status IngestRoutes(
        grpc::ServerContext* context,
        grpc::ServerReader<RouteUpdate>* reader,
        IngestResponse* response) override;

    grpc::Status BatchIngestRoutes(
        grpc::ServerContext* context,
        const BatchRouteUpdate* request,
        IngestResponse* response) override;

    grpc::Status StartSync(
        grpc::ServerContext* context,
        const SyncRequest* request,
        SyncResponse* response) override;

    grpc::Status CompleteSync(
        grpc::ServerContext* context,
        const SyncComplete* request,
        SyncResponse* response) override;

    grpc::Status AddRoute(
        grpc::ServerContext* context,
        const Route* request,
        RouteResponse* response) override;

    grpc::Status UpdateRoute(
        grpc::ServerContext* context,
        const Route* request,
        RouteResponse* response) override;

    grpc::Status DeleteRoute(
        grpc::ServerContext* context,
        const DeleteRequest* request,
        RouteResponse* response) override;

private:
    RouteManager& route_manager_;

    // Track active sync sessions per stream
    std::mutex sync_mutex_;
    std::unordered_map<std::string, std::string> stream_sync_sessions_;  // context_id -> sync_id
};

}  // namespace kepler
