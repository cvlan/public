#include "utils/metrics.h"

// Metrics is mostly header-only, this file is for any non-inline implementations
namespace kepler {

// Add any non-inline implementations here if needed

}  // namespace kepler
