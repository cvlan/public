#pragma once

#include <atomic>
#include <string>
#include <sstream>
#include <mutex>
#include <unordered_map>

namespace kepler {

class Metrics {
public:
    // Counters
    void inc_routes_added() { routes_added_.fetch_add(1, std::memory_order_relaxed); }
    void inc_routes_updated() { routes_updated_.fetch_add(1, std::memory_order_relaxed); }
    void inc_routes_deleted() { routes_deleted_.fetch_add(1, std::memory_order_relaxed); }

    void inc_lookups() { lookups_.fetch_add(1, std::memory_order_relaxed); }
    void inc_subscriptions_created() { subscriptions_created_.fetch_add(1, std::memory_order_relaxed); }
    void inc_subscriptions_removed() { subscriptions_removed_.fetch_add(1, std::memory_order_relaxed); }

    void inc_grpc_requests() { grpc_requests_.fetch_add(1, std::memory_order_relaxed); }
    void inc_grpc_errors() { grpc_errors_.fetch_add(1, std::memory_order_relaxed); }

    // Gauges
    void set_active_streams(uint64_t value) { active_streams_.store(value, std::memory_order_relaxed); }
    void set_active_syncs(uint64_t value) { active_syncs_.store(value, std::memory_order_relaxed); }

    // Get metrics in Prometheus format
    std::string get_prometheus_metrics() const {
        std::ostringstream ss;

        ss << "# HELP kepler_routes_added_total Total routes added\n";
        ss << "# TYPE kepler_routes_added_total counter\n";
        ss << "kepler_routes_added_total " << routes_added_.load(std::memory_order_relaxed) << "\n\n";

        ss << "# HELP kepler_routes_updated_total Total routes updated\n";
        ss << "# TYPE kepler_routes_updated_total counter\n";
        ss << "kepler_routes_updated_total " << routes_updated_.load(std::memory_order_relaxed) << "\n\n";

        ss << "# HELP kepler_routes_deleted_total Total routes deleted\n";
        ss << "# TYPE kepler_routes_deleted_total counter\n";
        ss << "kepler_routes_deleted_total " << routes_deleted_.load(std::memory_order_relaxed) << "\n\n";

        ss << "# HELP kepler_lookups_total Total lookup requests\n";
        ss << "# TYPE kepler_lookups_total counter\n";
        ss << "kepler_lookups_total " << lookups_.load(std::memory_order_relaxed) << "\n\n";

        ss << "# HELP kepler_subscriptions_created_total Total subscriptions created\n";
        ss << "# TYPE kepler_subscriptions_created_total counter\n";
        ss << "kepler_subscriptions_created_total " << subscriptions_created_.load(std::memory_order_relaxed) << "\n\n";

        ss << "# HELP kepler_subscriptions_removed_total Total subscriptions removed\n";
        ss << "# TYPE kepler_subscriptions_removed_total counter\n";
        ss << "kepler_subscriptions_removed_total " << subscriptions_removed_.load(std::memory_order_relaxed) << "\n\n";

        ss << "# HELP kepler_grpc_requests_total Total gRPC requests\n";
        ss << "# TYPE kepler_grpc_requests_total counter\n";
        ss << "kepler_grpc_requests_total " << grpc_requests_.load(std::memory_order_relaxed) << "\n\n";

        ss << "# HELP kepler_grpc_errors_total Total gRPC errors\n";
        ss << "# TYPE kepler_grpc_errors_total counter\n";
        ss << "kepler_grpc_errors_total " << grpc_errors_.load(std::memory_order_relaxed) << "\n\n";

        ss << "# HELP kepler_active_streams Current number of active subscription streams\n";
        ss << "# TYPE kepler_active_streams gauge\n";
        ss << "kepler_active_streams " << active_streams_.load(std::memory_order_relaxed) << "\n\n";

        ss << "# HELP kepler_active_syncs Current number of active sync sessions\n";
        ss << "# TYPE kepler_active_syncs gauge\n";
        ss << "kepler_active_syncs " << active_syncs_.load(std::memory_order_relaxed) << "\n\n";

        return ss.str();
    }

private:
    // Counters
    std::atomic<uint64_t> routes_added_{0};
    std::atomic<uint64_t> routes_updated_{0};
    std::atomic<uint64_t> routes_deleted_{0};
    std::atomic<uint64_t> lookups_{0};
    std::atomic<uint64_t> subscriptions_created_{0};
    std::atomic<uint64_t> subscriptions_removed_{0};
    std::atomic<uint64_t> grpc_requests_{0};
    std::atomic<uint64_t> grpc_errors_{0};

    // Gauges
    std::atomic<uint64_t> active_streams_{0};
    std::atomic<uint64_t> active_syncs_{0};
};

}  // namespace kepler
