# Kepler Routing Engine - Development & Investigation Summary

## Project Overview

Kepler is a high-performance C++17/20 routing engine that:
- Receives routes via gRPC
- Stores them in RocksDB
- Provides lookup and streaming subscription APIs
- Supports crash-resilient offset-based resumption

### Performance Targets
| Requirement | Target |
|-------------|--------|
| Route ingestion rate | 20,000 routes/sec |
| Update streaming rate | 20,000 updates/sec |
| CPU cores | ≤ 2 cores |
| Memory usage | ≤ 10 GB |
| Route scale | 10 million routes |

---

## Phase 1: Initial Design & Planning

### Architecture Designed
```
┌─────────────────────────────────────────────────────────────────┐
│                        Kepler Service                            │
├─────────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐   │
│  │   Ingestion  │  │    Lookup    │  │    Subscription      │   │
│  │   Service    │  │    Service   │  │    Service           │   │
│  │   (gRPC)     │  │    (gRPC)    │  │    (gRPC Streaming)  │   │
│  └──────┬───────┘  └──────┬───────┘  └──────────┬───────────┘   │
│         │                 │                      │               │
│  ┌──────┴─────────────────┴──────────────────────┴───────────┐  │
│  │                    Route Manager                           │  │
│  └──────┬─────────────────────────────────────────┬──────────┘  │
│         │                                         │              │
│  ┌──────┴──────────┐                    ┌────────┴───────────┐  │
│  │   Route Store   │                    │    Change Log      │  │
│  │   (RocksDB)     │                    │    (RocksDB CF)    │  │
│  └─────────────────┘                    └────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

### RocksDB Schema
| Column Family | Key Format | Purpose |
|---------------|------------|---------|
| `routes` | `vpn(u32)\|prefix` | Primary storage |
| `by_fqdn` | `fqdn\|route_id` | FQDN index |
| `by_endpoint` | `endpoint_ip\|route_id` | Endpoint index |
| `changelog` | `sequence (uint64)` | Change log for streaming |
| `subscriptions` | `subscription_id` | Durable subscription state |

### Protocol Buffers Defined
- `Route` - Core route with prefix, VPN, nexthop, metadata
- `RouteChange` - Change event with sequence number
- `SubscriptionFilter` - Filter by FQDN, endpoint, VPN
- gRPC services: `RouteIngestion`, `RouteLookup`, `RouteSubscription`

---

## Phase 2: Build Environment Setup

### User Request
> "Build a container for build and install tools only inside it, don't install anything on the host OS"

### Implementation
Created Docker-based build environment:
- `Dockerfile.build` - Ubuntu 24.04 with pre-built dependencies (libgrpc++-dev, librocksdb-dev)
- `scripts/build-shell.sh` - Utility to drop into containerized build environment

### Initial Issues & Fixes

**Issue 1**: Missing `#include <random>` in route_store.cpp
- Error: `std::mt19937_64` not found
- Fix: Added include

**Issue 2**: CMake conflict with gmock_main
- prometheus-cpp bundles googletest, causing conflicts
- Fix: `set(ENABLE_TESTING OFF CACHE BOOL "" FORCE)`

**Issue 3**: gRPC FetchContent too slow
- User noted: "been there a while"
- Fix: Changed to use system-installed packages via pkg-config

### Container Reuse Request
> "Use one container and attach to it if exists, don't start a new instance for every build"

Updated `build-shell.sh` to use persistent container with `docker exec`.

---

## Phase 3: CPU Usage Issue

### User Report
> "Even when nothing is happening kepler is using 7-8 cores all the time"

### Root Cause
gRPC sync server creating excessive polling threads by default.

### Fix Applied
```cpp
builder.SetSyncServerOption(grpc::ServerBuilder::SyncServerOption::NUM_CQS, 2);
builder.SetSyncServerOption(grpc::ServerBuilder::SyncServerOption::MIN_POLLERS, 1);
builder.SetSyncServerOption(grpc::ServerBuilder::SyncServerOption::MAX_POLLERS, 2);
builder.SetSyncServerOption(grpc::ServerBuilder::SyncServerOption::CQ_TIMEOUT_MSEC, 1000);
```

Also reduced RocksDB background jobs: `options.max_background_jobs = 2`

### Result
CPU usage at idle dropped to acceptable levels.

---

## Phase 4: Subscription Integration Test

### User Request
> "When I do a subscriber test there is no way to verify that updates are happening correctly. This needs an integration test. We also need to measure the latency of the update from the time kepler sees it to the time the client gets it."

### Implementation
Created `tests/integration/subscription_integration_test.cpp`:
- Creates subscription with FQDN filter
- Injects routes via ingestion API (half matching filter)
- Verifies subscriber receives correct updates
- Measures and reports latency statistics (min, max, mean, P50, P90, P99)

### Initial Bug: Subscriber Not Receiving Updates

**Symptoms**:
```
[Subscriber] Stream connected, waiting for changes...
[Ingestion] Adding 100 routes...
[Ingestion] Added 100 routes
(subscriber receives nothing)
```

**Debugging Steps**:
1. Added debug logging throughout notification chain
2. Found server was correctly pushing changes to queue
3. Found server's `writer->Write()` was succeeding
4. Discovered gRPC was buffering writes

**Fix**:
```cpp
grpc::WriteOptions options;
options.set_no_compression();  // Force immediate sending
if (!writer->Write(response, options)) {
    break;
}
```

### Result
Streaming started working. Single-client latency:
- P50: 117 µs
- P90: 1,137 µs
- P99: 3,155 µs

---

## Phase 5: Scale Testing with Preload & Multiple Clients

### User Request
> "First load 1M routes into kepler then add this 500 and do the updates. The idea is to check if it affects the latency. Next add 10 clients which need the same update and find the same for the worst case of the clients."

### Implementation

#### Added `--preload` Option
Loads N routes into database before starting test (with different FQDN so they don't match subscription filter).

#### Added `--clients` Option
Spawns N subscriber threads, all subscribing to same FQDN.

### Test Results

| Scenario | P50 | P90 | P99 |
|----------|-----|-----|-----|
| Baseline (empty DB, 1 client) | 117 µs | 1,137 µs | 3,155 µs |
| 1M routes, 1 client | 120 µs | 1,041 µs | 3,015 µs |
| 1M routes, 10 clients | 70,401 µs | 183,543 µs | 223,535 µs |

**Key Finding**: Database size has minimal impact, but 10 clients cause 400x latency increase.

---

## Phase 6: CPU Utilization Investigation

### User Observation
> "The container is using only one CPU, there are 14 available, that changes the latency math"

### Container Fix
Updated `build-shell.sh` to allocate resources:
```bash
docker run -d \
    --name "$CONTAINER_NAME" \
    --cpus="8" \
    --memory="12g" \
    ...
```

### User Follow-up
> "It's using only 100% overall, before we fixed the poll bug it was using 700%"

### gRPC Settings Adjusted
```cpp
// Increased to allow scaling under load
builder.SetSyncServerOption(NUM_CQS, 4);      // was 2
builder.SetSyncServerOption(MIN_POLLERS, 1);
builder.SetSyncServerOption(MAX_POLLERS, 8);  // was 2
```

Later increased further:
```cpp
builder.SetSyncServerOption(NUM_CQS, 8);
builder.SetSyncServerOption(MAX_POLLERS, 32);
```

### Result
Some improvement but multi-client latency remained high (~51ms P50).

---

## Phase 7: Optimization Attempts

### Attempt 1: Parallel Notification via Thread Pool

**Hypothesis**: notify_change() is serializing notifications to all subscribers.

**Change**: Added `ThreadPool` to `SubscriptionManager`, dispatch notifications asynchronously.

**Result**: Actually made latency WORSE due to thread pool overhead. **Reverted.**

### Attempt 2: Separate gRPC Channels per Client

**Hypothesis**: All client threads sharing one channel causes contention.

**Change**: Each subscriber thread creates its own gRPC channel.

**Result**: Made latency WORSE (P50: 82ms vs 51ms). **Reverted.**

### Attempt 3: Parallel Route Ingestion

**Change**: Preload routes using 8 parallel threads instead of single-threaded.

**Result**: Ingestion rate improved from ~12k to ~27k routes/sec. **Kept this change.**

---

## Phase 8: Multi-Process Testing

### User Request
> "What I would like to do is run 10 instances of client so each of them get their own gRPC channels"

### Rationale
In-process threads share resources and may have hidden contention. Real-world clients would be separate processes.

### Implementation

#### Created `subscriber_client.cpp`
Standalone subscriber process that:
- Connects to Kepler with its own gRPC channel
- Subscribes with FQDN filter
- Writes results to file when done

#### Created `run_multiprocess_test.sh`
Orchestrates multi-process test:
1. Starts Kepler server
2. Preloads routes (optional)
3. Spawns N subscriber_client processes
4. Waits for all to signal "ready"
5. Runs ingestion
6. Collects results from all clients

#### Added Ingestion-Only Mode
`--clients=0` runs ingestion without internal subscriber (for external subscribers).

### Problem Encountered

**Symptom**: Only 4 out of 10 subscriber processes receive data.

```
Client 0: 0 adds, 0 updates, 0 deletes
Client 1: 500 adds, 50 updates, 25 deletes  ✓
Client 2: 500 adds, 50 updates, 25 deletes  ✓
Client 3: 0 adds, 0 updates, 0 deletes
Client 4: 500 adds, 50 updates, 25 deletes  ✓
Client 5: 0 adds, 0 updates, 0 deletes
...
```

**Observations**:
- Exactly 4 clients receive ALL expected events
- Exactly 6 clients receive ZERO events
- Pattern varies between runs
- Increasing delay (0.5s → 2s) didn't help

---

## Phase 9: Root Cause Analysis

### Hypothesis: `stream_connected` Race Condition

The notification flow:
```
Subscribe() → adds subscription with stream_connected=false
     ↓
StreamChanges() → calls connect_stream() → sets stream_connected=true
     ↓
notify_change() → only notifies where stream_connected=true
```

**Suspected Issue**: When `notify_change()` runs, only some subscriptions have `stream_connected=true`.

### Debug Output Added
```cpp
// In notify_change()
static std::atomic<int> log_count{0};
if (log_count++ < 3) {
    std::cerr << "[notify] total_subs=" << total_subs
              << " connected=" << connected_subs
              << " matching=" << matching_subs.size() << "\n";
}
```

### Potential Causes

1. **gRPC async behavior**: `stub->StreamChanges()` returns immediately on client side, but server may not have started handler yet

2. **Race window**: Client signals "ready" before server calls `connect_stream()`

3. **Thread pool exhaustion**: Not enough gRPC threads to handle all streaming RPCs

---

## Proposed Fixes (Not Yet Implemented)

### Option 1: Server Sends Initial Message
Have server send a "connected" acknowledgment immediately after `connect_stream()`. Client waits for this before signaling ready.

### Option 2: Synchronous Subscription Verification
After Subscribe(), client calls GetSubscription() RPC to verify subscription is active.

### Option 3: Switch to Async gRPC
Replace sync server with async for better scalability and explicit control over threading.

---

## Files Created/Modified

### Core Implementation
- `src/storage/route_store.cpp` - Added `#include <random>`, reduced background jobs
- `src/core/subscription_manager.cpp` - Notification logic, debug output
- `src/core/subscription_manager.h` - Added ThreadPool (later removed)
- `src/services/subscription_service.cpp` - Added WriteOptions for immediate send
- `src/main.cpp` - gRPC thread pool settings

### Build Environment
- `Dockerfile.build` - Build container definition
- `scripts/build-shell.sh` - Container management utility

### Test Infrastructure
- `tests/integration/subscription_integration_test.cpp` - Main integration test
- `tests/integration/subscriber_client.cpp` - Standalone subscriber process
- `scripts/run_subscription_test.sh` - Single-process test runner
- `scripts/run_multiprocess_test.sh` - Multi-process test runner
- `CMakeLists.txt` - Added test targets

---

## Current Configuration

### gRPC Server Settings
```cpp
builder.SetSyncServerOption(NUM_CQS, 8);
builder.SetSyncServerOption(MIN_POLLERS, 2);
builder.SetSyncServerOption(MAX_POLLERS, 32);
builder.SetSyncServerOption(CQ_TIMEOUT_MSEC, 1000);
```

### Container Resources
```bash
--cpus="8"
--memory="12g"
```

---

## Key Learnings

1. **gRPC WriteOptions matter** - Without `set_no_compression()`, writes may be buffered
2. **Database size doesn't affect streaming latency** - RocksDB lookups are fast
3. **Thread pool overhead can hurt** - Simple synchronous code sometimes beats async
4. **Shared channels don't cause contention** - Separate channels made things worse
5. **Multi-process testing reveals real issues** - Race conditions hidden in single-process tests
6. **gRPC sync server threading is complex** - NUM_CQS, MIN/MAX_POLLERS all interact

---

## Next Steps

1. Capture server debug output to confirm `connected` count during notifications
2. Implement server-side "connected" acknowledgment message
3. Re-run multi-process test after fixing race condition
4. If still issues, consider switching to async gRPC
5. Final latency benchmarking with all fixes in place
