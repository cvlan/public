# Changelog

## [0.0.5] - 2026-01-15

### Changed
- **Timestamp Precision**: Changed from milliseconds to microseconds for accurate latency measurement
  - `route_store.cpp`: `now_millis()` → `now_micros()`
  - Latency now measured from DB injection time (`change.timestamp()`) instead of client-side timestamps

### Performance
- Single client P99 latency: ~1.2ms (1168µs)
- 10 client P99 latency: ~12.2ms (without preload)

## [0.0.4] - 2026-01-15

### Added
- **Crash Recovery Test**: New integration test proving RocksDB crash resilience
  - `crash_recovery_test` binary and `scripts/run_crash_recovery_test.sh`
  - Verifies route count, subscription recovery, stream resume, and data integrity after SIGKILL

### Fixed
- **Critical**: Multi-client subscription test regression from v0.0.2
  - Update/delete loops were iterating 2x too many times due to incorrect batch logic
  - Clients received wrong event counts (75 updates, 0 deletes instead of 50/25)
  - Fixed by correcting loop bounds in `subscription_integration_test.cpp`

### Performance
- 10 client P99 latency: ~132ms (with 1M routes preloaded)

## [0.0.3] - 2026-01-15

### Added
- **Static Analysis**: cppcheck integration for code quality
  - Added `cppcheck` and `clang-tidy` to build container
  - CMake targets: `static-analysis`, `static-analysis-full`
  - Makefile for convenient build commands
- **Project Documentation**: `CLAUDE.md` with build instructions
- **Build Improvements**: `.dockerignore`, `.clang-tidy` config

### Fixed
- Unused variables in structured bindings (`subscription_manager.cpp`)
- Dead code: unused `was_added` assignment (`ingestion_service.cpp`)
- Missing `<optional>` header (`sample_client.cpp`)
- RocksDB detection fallback for systems without pkg-config

### Changed
- Replaced raw loops with STL algorithms where appropriate
  - `std::copy` in `subscription_service.cpp`, `sample_client.cpp`
  - `std::accumulate` in `lookup_bench.cpp`
- Build container now uses Ubuntu 24.04 with static analysis tools

## [0.0.2] - 2026-01-15

### Added
- **Batch Ingestion API**: New `BatchIngestRoutes` RPC for efficient bulk route operations
  - Uses single RocksDB WriteBatch for atomic batch writes
  - 3x performance improvement for route ingestion (~25k routes/sec vs ~7.7k)
  - Supports ADD, UPDATE, DELETE operations in a single batch
- **Lookup Benchmark Tool**: `lookup_bench` for measuring route lookup latency
  - P99 lookup latency: ~100µs with 1M routes

### Changed
- `RouteStore::batch_upsert()` now returns `RouteChange` objects directly, avoiding extra DB reads
- `RouteManager::batch_ingest()` uses returned changes for subscriber notification (reduced latency)
- Fixed integration test expected count calculations for update/delete operations

### Performance
- Batch ingestion: ~25,000 routes/sec
- Single client P99 latency: ~3.8ms
- 10 client P99 latency: ~157ms (with 1M routes preloaded)
- Lookup P99 latency: ~103µs

## [0.0.1] - 2026-01-15

### Added
- Initial release of Kepler Routing Engine
- gRPC services: RouteIngestion, RouteLookup, RouteSubscription
- RocksDB storage with column families for routes and indexes
- Subscription streaming with filter support (FQDN, VPN, endpoint IP, virtual IP)
- 2-worker notification system with hash-based subscriber distribution
- CLI tool `keplerctl` for route operations and subscriptions
- Docker containerization support
