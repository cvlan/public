#include <grpcpp/grpcpp.h>
#include "kepler.grpc.pb.h"
#include <chrono>
#include <iostream>
#include <random>
#include <vector>
#include <algorithm>
#include <numeric>

using namespace kepler;

int main(int argc, char** argv) {
    std::string target = "localhost:50051";
    int num_lookups = 1000;
    
    if (argc > 1) target = argv[1];
    if (argc > 2) num_lookups = std::stoi(argv[2]);
    
    auto channel = grpc::CreateChannel(target, grpc::InsecureChannelCredentials());
    auto stub = RouteLookup::NewStub(channel);
    
    std::vector<double> latencies;
    std::mt19937 rng(42);
    std::uniform_int_distribution<uint32_t> dist(0, 999999);
    
    for (int i = 0; i < num_lookups; ++i) {
        uint32_t id = dist(rng);
        
        PrefixRequest req;
        req.set_vpn(1 + (id % 1000));
        auto* prefix = req.mutable_prefix();
        prefix->set_family(AF_IPV4);
        std::string addr(4, 0);
        addr[0] = 10;
        addr[1] = (id >> 16) & 0xFF;
        addr[2] = (id >> 8) & 0xFF;
        addr[3] = id & 0xFF;
        prefix->set_address(addr);
        prefix->set_prefix_length(24);
        
        auto start = std::chrono::steady_clock::now();
        
        grpc::ClientContext ctx;
        Route route;
        auto status = stub->GetRouteByPrefix(&ctx, req, &route);
        
        auto end = std::chrono::steady_clock::now();
        auto us = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count();
        latencies.push_back(us);
    }
    
    std::sort(latencies.begin(), latencies.end());

    double sum = std::accumulate(latencies.begin(), latencies.end(), 0.0);

    std::cout << "Lookup Latency (" << num_lookups << " lookups):\n";
    std::cout << "  Min:  " << latencies.front() << " us\n";
    std::cout << "  Mean: " << sum / latencies.size() << " us\n";
    std::cout << "  P50:  " << latencies[latencies.size() * 50 / 100] << " us\n";
    std::cout << "  P90:  " << latencies[latencies.size() * 90 / 100] << " us\n";
    std::cout << "  P99:  " << latencies[latencies.size() * 99 / 100] << " us\n";
    std::cout << "  Max:  " << latencies.back() << " us\n";
    
    return 0;
}
