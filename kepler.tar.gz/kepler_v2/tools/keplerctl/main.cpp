#include "kepler.grpc.pb.h"

#include <CLI/CLI.hpp>
#include <grpcpp/grpcpp.h>

#include <iostream>
#include <iomanip>
#include <sstream>

namespace {

std::string format_ip(const std::string& bytes) {
    if (bytes.size() == 4) {
        // IPv4
        std::ostringstream ss;
        ss << static_cast<int>(static_cast<uint8_t>(bytes[0])) << "."
           << static_cast<int>(static_cast<uint8_t>(bytes[1])) << "."
           << static_cast<int>(static_cast<uint8_t>(bytes[2])) << "."
           << static_cast<int>(static_cast<uint8_t>(bytes[3]));
        return ss.str();
    } else if (bytes.size() == 16) {
        // IPv6
        std::ostringstream ss;
        ss << std::hex << std::setfill('0');
        for (size_t i = 0; i < 16; i += 2) {
            if (i > 0) ss << ":";
            ss << std::setw(2) << static_cast<int>(static_cast<uint8_t>(bytes[i]))
               << std::setw(2) << static_cast<int>(static_cast<uint8_t>(bytes[i+1]));
        }
        return ss.str();
    }
    return "(invalid)";
}

std::string format_prefix(const kepler::Prefix& prefix) {
    std::string ip = format_ip(prefix.address());
    return ip + "/" + std::to_string(prefix.prefix_length());
}

void print_route(const kepler::Route& route) {
    std::cout << "Route ID: " << route.route_id() << "\n";
    std::cout << "  VPN: " << route.vpn() << "\n";
    std::cout << "  Prefix: " << format_prefix(route.prefix()) << "\n";
    std::cout << "  Nexthop: " << format_ip(route.nexthop()) << " (VPN " << route.nexthop_vpn() << ")\n";
    if (!route.discovered_fqdn().empty()) {
        std::cout << "  FQDN: " << route.discovered_fqdn() << "\n";
    }
    if (!route.endpoint_ip().empty()) {
        std::cout << "  Endpoint IP: " << format_ip(route.endpoint_ip()) << "\n";
    }
    if (!route.virtual_ip().empty()) {
        std::cout << "  Virtual IP: " << format_ip(route.virtual_ip()) << "\n";
    }
    if (!route.app_network_id().empty()) {
        std::cout << "  App Network ID: " << route.app_network_id() << "\n";
    }
    std::cout << "\n";
}

std::string parse_ip_to_bytes(const std::string& ip_str) {
    // Simple IPv4 parser
    std::string result;
    std::istringstream ss(ip_str);
    std::string octet;
    while (std::getline(ss, octet, '.')) {
        result.push_back(static_cast<char>(std::stoi(octet)));
    }
    return result;
}

}  // namespace

int main(int argc, char** argv) {
    CLI::App app{"keplerctl - Kepler Routing Engine CLI"};

    std::string target = "localhost:50051";
    app.add_option("-t,--target", target, "Kepler server address")->default_val("localhost:50051");

    // Status command
    auto status_cmd = app.add_subcommand("status", "Show service status");

    // Stats command
    auto stats_cmd = app.add_subcommand("stats", "Show detailed statistics");

    // List subcommands
    auto list_cmd = app.add_subcommand("list", "List resources");

    auto list_fqdns = list_cmd->add_subcommand("fqdns", "List all FQDNs");
    std::string fqdn_prefix;
    uint32_t fqdn_limit = 100;
    list_fqdns->add_option("--prefix", fqdn_prefix, "Filter FQDNs by prefix");
    list_fqdns->add_option("--limit", fqdn_limit, "Maximum results")->default_val(100);

    auto list_vpns = list_cmd->add_subcommand("vpns", "List all VPNs");
    uint32_t vpn_limit = 100;
    list_vpns->add_option("--limit", vpn_limit, "Maximum results")->default_val(100);

    // Routes subcommands
    auto routes_cmd = app.add_subcommand("routes", "Route operations");

    auto routes_get = routes_cmd->add_subcommand("get", "Get route by VPN and prefix");
    uint32_t get_vpn = 0;
    std::string get_prefix;
    routes_get->add_option("--vpn", get_vpn, "VPN ID")->required();
    routes_get->add_option("--prefix", get_prefix, "Prefix (e.g., 10.0.0.0/24)")->required();

    auto routes_by_fqdn = routes_cmd->add_subcommand("by-fqdn", "Get routes by FQDN");
    std::string fqdn;
    routes_by_fqdn->add_option("fqdn", fqdn, "FQDN to lookup")->required();

    auto routes_by_vpn = routes_cmd->add_subcommand("by-vpn", "Get routes by VPN");
    uint32_t vpn_id;
    routes_by_vpn->add_option("vpn", vpn_id, "VPN ID")->required();

    auto routes_by_endpoint = routes_cmd->add_subcommand("by-endpoint", "Get routes by endpoint IP");
    std::string endpoint_ip;
    routes_by_endpoint->add_option("ip", endpoint_ip, "Endpoint IP address")->required();

    // Subscribe command
    auto subscribe_cmd = app.add_subcommand("subscribe", "Subscribe to route changes");
    std::string sub_fqdn, sub_endpoint;
    uint32_t sub_vpn = 0;
    subscribe_cmd->add_option("--fqdn", sub_fqdn, "Subscribe to FQDN");
    subscribe_cmd->add_option("--endpoint", sub_endpoint, "Subscribe to endpoint IP");
    subscribe_cmd->add_option("--vpn", sub_vpn, "Subscribe to VPN");

    CLI11_PARSE(app, argc, argv);

    // Create gRPC channel
    auto channel = grpc::CreateChannel(target, grpc::InsecureChannelCredentials());

    if (status_cmd->parsed() || stats_cmd->parsed()) {
        auto stub = kepler::RouteLookup::NewStub(channel);
        grpc::ClientContext context;
        kepler::StatsRequest request;
        kepler::StatsResponse response;

        auto status = stub->GetStats(&context, request, &response);
        if (!status.ok()) {
            std::cerr << "Error: " << status.error_message() << std::endl;
            return 1;
        }

        std::cout << "Kepler Service Status\n";
        std::cout << "=====================\n";
        std::cout << "Uptime: " << response.uptime_seconds() << " seconds\n";
        std::cout << "Total Routes: " << response.total_routes() << "\n";
        std::cout << "Total VPNs: " << response.total_vpns() << "\n";
        std::cout << "Total FQDNs: " << response.total_fqdns() << "\n";
        std::cout << "Changelog Sequence: " << response.newest_sequence() << "\n";
        std::cout << "Oldest Sequence: " << response.oldest_sequence() << "\n";
    }
    else if (list_fqdns->parsed()) {
        auto stub = kepler::RouteLookup::NewStub(channel);
        grpc::ClientContext context;
        kepler::ListFqdnsRequest request;
        request.set_prefix(fqdn_prefix);
        request.set_limit(fqdn_limit);
        kepler::ListFqdnsResponse response;

        auto status = stub->ListFqdns(&context, request, &response);
        if (!status.ok()) {
            std::cerr << "Error: " << status.error_message() << std::endl;
            return 1;
        }

        std::cout << "FQDNs (" << response.fqdns_size() << " of " << response.total_count() << " total):\n";
        for (const auto& f : response.fqdns()) {
            std::cout << "  " << f << "\n";
        }
    }
    else if (list_vpns->parsed()) {
        auto stub = kepler::RouteLookup::NewStub(channel);
        grpc::ClientContext context;
        kepler::ListVpnsRequest request;
        request.set_limit(vpn_limit);
        kepler::ListVpnsResponse response;

        auto status = stub->ListVpns(&context, request, &response);
        if (!status.ok()) {
            std::cerr << "Error: " << status.error_message() << std::endl;
            return 1;
        }

        std::cout << "VPNs (" << response.vpns_size() << " of " << response.total_count() << " total):\n";
        for (uint32_t v : response.vpns()) {
            std::cout << "  " << v << "\n";
        }
    }
    else if (routes_get->parsed()) {
        auto stub = kepler::RouteLookup::NewStub(channel);
        grpc::ClientContext context;
        kepler::PrefixRequest request;
        request.set_vpn(get_vpn);

        // Parse prefix
        auto slash_pos = get_prefix.find('/');
        if (slash_pos != std::string::npos) {
            std::string ip = get_prefix.substr(0, slash_pos);
            int prefix_len = std::stoi(get_prefix.substr(slash_pos + 1));

            auto* prefix = request.mutable_prefix();
            prefix->set_family(kepler::AF_IPV4);
            prefix->set_address(parse_ip_to_bytes(ip));
            prefix->set_prefix_length(prefix_len);
        }

        kepler::Route response;
        auto status = stub->GetRouteByPrefix(&context, request, &response);
        if (!status.ok()) {
            std::cerr << "Error: " << status.error_message() << std::endl;
            return 1;
        }

        print_route(response);
    }
    else if (routes_by_fqdn->parsed()) {
        auto stub = kepler::RouteLookup::NewStub(channel);
        grpc::ClientContext context;
        kepler::FqdnRequest request;
        request.set_discovered_fqdn(fqdn);
        kepler::RoutesResponse response;

        auto status = stub->GetRoutesByFqdn(&context, request, &response);
        if (!status.ok()) {
            std::cerr << "Error: " << status.error_message() << std::endl;
            return 1;
        }

        std::cout << "Routes for FQDN '" << fqdn << "' (" << response.routes_size() << " routes):\n\n";
        for (const auto& route : response.routes()) {
            print_route(route);
        }
    }
    else if (routes_by_vpn->parsed()) {
        auto stub = kepler::RouteLookup::NewStub(channel);
        grpc::ClientContext context;
        kepler::VpnRequest request;
        request.set_vpn(vpn_id);
        request.set_limit(100);

        std::cout << "Routes in VPN " << vpn_id << ":\n\n";
        auto reader = stub->GetRoutesByVpn(&context, request);
        kepler::Route route;
        int count = 0;
        while (reader->Read(&route)) {
            print_route(route);
            count++;
        }

        auto status = reader->Finish();
        if (!status.ok()) {
            std::cerr << "Error: " << status.error_message() << std::endl;
            return 1;
        }
        std::cout << "Total: " << count << " routes\n";
    }
    else if (routes_by_endpoint->parsed()) {
        auto stub = kepler::RouteLookup::NewStub(channel);
        grpc::ClientContext context;
        kepler::EndpointRequest request;
        request.set_endpoint_ip(parse_ip_to_bytes(endpoint_ip));
        kepler::RoutesResponse response;

        auto status = stub->GetRoutesByEndpoint(&context, request, &response);
        if (!status.ok()) {
            std::cerr << "Error: " << status.error_message() << std::endl;
            return 1;
        }

        std::cout << "Routes for endpoint IP '" << endpoint_ip << "' (" << response.routes_size() << " routes):\n\n";
        for (const auto& route : response.routes()) {
            print_route(route);
        }
    }
    else if (subscribe_cmd->parsed()) {
        auto sub_stub = kepler::RouteSubscription::NewStub(channel);

        // Create subscription
        grpc::ClientContext sub_context;
        kepler::SubscribeRequest sub_request;
        sub_request.set_client_id("keplerctl-" + std::to_string(getpid()));

        if (!sub_fqdn.empty()) {
            auto* filter = sub_request.add_filters();
            filter->set_discovered_fqdn(sub_fqdn);
            std::cout << "Subscribing to FQDN: " << sub_fqdn << "\n";
        }
        if (!sub_endpoint.empty()) {
            auto* filter = sub_request.add_filters();
            filter->set_endpoint_ip(parse_ip_to_bytes(sub_endpoint));
            std::cout << "Subscribing to endpoint: " << sub_endpoint << "\n";
        }
        if (sub_vpn > 0) {
            auto* filter = sub_request.add_filters();
            filter->set_vpn(sub_vpn);
            std::cout << "Subscribing to VPN: " << sub_vpn << "\n";
        }

        if (sub_request.filters_size() == 0) {
            std::cerr << "Error: At least one filter (--fqdn, --endpoint, or --vpn) is required\n";
            return 1;
        }

        kepler::SubscribeResponse sub_response;
        auto status = sub_stub->Subscribe(&sub_context, sub_request, &sub_response);
        if (!status.ok()) {
            std::cerr << "Error subscribing: " << status.error_message() << std::endl;
            return 1;
        }

        std::cout << "Subscription ID: " << sub_response.subscription_id() << "\n";
        std::cout << "Streaming changes (Ctrl+C to stop)...\n\n";

        // Stream changes
        grpc::ClientContext stream_context;
        kepler::StreamRequest stream_request;
        stream_request.set_subscription_id(sub_response.subscription_id());
        stream_request.set_last_sequence(0);

        auto reader = sub_stub->StreamChanges(&stream_context, stream_request);
        kepler::StreamResponse change;

        while (reader->Read(&change)) {
            if (change.has_change()) {
                const auto& c = change.change();
                std::string type;
                switch (c.type()) {
                    case kepler::ADD: type = "ADD"; break;
                    case kepler::UPDATE: type = "UPDATE"; break;
                    case kepler::DELETE: type = "DELETE"; break;
                    default: type = "UNKNOWN"; break;
                }
                std::cout << "[" << c.sequence() << "] " << type << "\n";
                print_route(c.route());
            } else if (change.has_full_sync_route()) {
                std::cout << "[FULL_SYNC]\n";
                print_route(change.full_sync_route());
            }
            if (change.full_sync_complete()) {
                std::cout << "[Full sync complete]\n\n";
            }
        }

        auto stream_status = reader->Finish();
        if (!stream_status.ok()) {
            std::cerr << "Stream ended: " << stream_status.error_message() << std::endl;
        }
    }
    else {
        std::cout << app.help() << std::endl;
    }

    return 0;
}
